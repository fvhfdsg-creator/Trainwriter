"""Metric model: search-volume estimation, keyword difficulty, intent, opportunity scoring.

Everything is a documented estimate derived from the live signals we actually collected - the
`explain` payload travels with each topic so the UI can show exactly why a number is what it is.
"""
from __future__ import annotations

import math
import re

from . import util

INTENT_MODS = {
    "transactional": ["buy", "price", "cost", "coupon", "discount", "near me", "booking", "book",
                      "deal", "deals", "quote", "rental", "for sale", "signup", "sign up", "order",
                      "ticket", "tickets", "apply", "loan", "insurance quote"],
    "commercial": ["best", "top ", "review", "reviews", " vs ", "versus", "compared", "comparison",
                   "alternative", "alternatives", "rated", "tested", "ranking", "cheapest", "worth"],
    "informational": ["how", "what", "why", "when", "where", "guide", "tutorial", "explained", "tips",
                      "ideas", "meaning", "definition", "examples", "checklist", "for beginners",
                      "calculator", "work", "works", "safe", "benefits", "vs"],
    "navigational": ["login", "log in", "sign in", "website", "official", "portal", "dashboard", "app",
                     "download", "status", "contact", "phone number"],
    "news": ["dead", "died", "dies", "arrested", "charged", "crash", "shooting", "fired", "resigns",
             "announces", "announced", "launches", "launched", "unveils", "breaks", "recall", "outage",
             "attack", "verdict", "indicted", "wins", "won", "loses", "lost", "storm", "earthquake"],
}

INTENT_WEIGHT = {"commercial": 1.14, "informational": 1.06, "transactional": 1.03, "navigational": 0.82, "news": 0.70}
INTENT_LABEL = {"commercial": "Comparison / buyer intent", "informational": "How-to / explain",
                "transactional": "Transactional", "navigational": "Brand / navigational", "news": "News spike"}

CPC_BASE = {"money": 3.1, "health": 2.6, "travel": 1.7, "ai-tech": 2.0}
AUTHORITY_DOMAINS = {"wikipedia.org", "nature.com", "nih.gov", "who.int", "reuters.com", "apnews.com",
                     "bbc.com", "bbc.co.uk", "nytimes.com", "investor.gov", "irs.gov", "sec.gov",
                     "fda.gov", "cdc.gov", "ed.gov", "sciencedirect.com", "acm.org", "ieee.org",
                     "github.com", "stackoverflow.com", "pypi.org", "arxiv.org", "-ft.com", "wsj.com",
                     "bloomberg.com", "theguardian.com"}


# --------------------------------------------------------------------- intent
def classify_intent(term: str, context: str = "") -> tuple[str, list[str]]:
    t = " " + util.normalize_term(term) + " "
    c = " " + util.normalize_term(context)[:400] + " "
    hits: dict[str, list[str]] = {}
    for intent, mods in INTENT_MODS.items():
        hits[intent] = [m for m in mods if m in t]
    best = max(INTENT_WEIGHT, key=lambda k: (len(hits[k]), -list(INTENT_MODS).index(k)))
    if not any(hits.values()):
        words = util.content_words(term)
        if len(words) <= 2:
            best, hits["navigational"] = "navigational", ["short head term"]
        elif re.search(r"\b(20\d\d)\b", t):
            best, hits["news"] = "news", ["dated event"]
        else:
            best, hits["informational"] = "informational", ["question-shaped long tail"]
    elif best in ("informational", "commercial") and any(m in c for m in INTENT_MODS["news"]):
        hits[best].append("(mixed with news framing)")
    return best, hits[best]


# --------------------------------------------------------------------- volume
def estimate_volume(daily_candidates: list[tuple[str, int, float]], suggest_count: int,
                     coverage_items: int, age_hours: float) -> dict:
    """daily_candidates: [(source, daily_estimate, weight)] -> blended monthly search volume."""
    parts, wsum, vsum = {}, 0.0, 0.0
    for name, val, w in daily_candidates:
        if not val or val <= 0:
            continue
        # weight recent signals more; decay stale ones
        decay = 1.0 if age_hours < 36 else (0.75 if age_hours < 96 else 0.5)
        w *= decay
        parts[name] = {"daily": int(val), "weight": round(w, 3)}
        vsum += val * w
        wsum += w
    blended_daily = (vsum / wsum) if wsum else None

    if blended_daily is None:
        # cold start: derive from demand breadth (suggestions) + press coverage
        blended_daily = max(6.0, min(400.0, suggest_count * 9.0 + coverage_items * 22.0))
        parts["derived"] = {"daily": round(blended_daily, 1),
                            "weight": 1.0, "note": "autocomplete breadth + coverage count (no direct volume source)"}
        wsum = wsum or 1.0
    for k in parts:
        parts[k].setdefault("share", round(parts[k]["weight"] / wsum, 2))

    query_family = 1.0 + 0.18 * math.log2(1 + max(0, suggest_count))
    coverage_boost = 1.0 + min(0.25, coverage_items * 0.04)
    peak_decay = 0.85 if any(k in parts for k in ("volume_daily_hint", "google_trends")) else 1.0
    monthly = int(round(blended_daily * 30.4 * peak_decay * query_family * coverage_boost, -1))
    monthly = max(10, min(1_500_000, monthly))
    return {
        "volume_month": monthly,
        "volume_daily": int(round(blended_daily * query_family)),
        "components": parts,
        "query_family_multiplier": round(query_family, 2),
        "coverage_boost": round(coverage_boost, 2),
        "formula": "monthly = Σ(daily_src × w)/Σw × 30.4 × (1 + 0.42·log2(1+suggestions)) × coverage_boost",
    }


# --------------------------------------------------------------------- difficulty
def keyword_difficulty(*, term: str, volume: int, intent: str, suggest_count: int,
                       question_suggests: int, longtail_share: float, authority_share: float,
                       coverage_items: int, median_age_h: float, exact_article: bool,
                       competitor_words: float) -> dict:
    norm = util.normalize_term(term)
    words = len(norm.split())

    # 1. content supply: how much fresh writing already targets this exact phrase
    supply = util.clamp(coverage_items * 7.5, 0, 24)

    # 2. authority load: share of top coverage from domains a blog can't outrank
    authority = util.clamp(authority_share * 26, 0, 26)

    # 3. head-term tax: 1-2 word queries with big volume are the hardest SERPs
    head = 0.0
    if words <= 2:
        head += 9
    elif words == 3:
        head += 4
    head += util.clamp(math.log10(max(volume, 1)) * 3.0 - 8.0, 0, 14)
    if exact_article:
        head += 5  # an entity article owns position 1

    # 4. long-tail opening (reduces difficulty): rich suggestion space = findable angles
    opening = -util.clamp(suggest_count * 0.9 + question_suggests * 1.4, 0, 16)

    # 5. intent hardness
    intent_adj = {"commercial": 8, "transactional": 10, "navigational": 6, "informational": -4, "news": -8}[intent]

    # 6. freshness gap: stale SERPs (nobody updated in months) are softer
    freshness = -util.clamp((median_age_h - 96) / 96 * 6.0, 0, 10) if median_age_h else 6.0

    # 7. competitor depth: thin articles in the SERP = weaker content to beat
    depth = util.clamp((competitor_words - 900) / 900 * 8.0, -4, 8)

    raw = 30 + supply + authority + head + opening + intent_adj + freshness + depth
    if words >= 5:
        raw -= 5
    score = int(round(util.clamp(raw, 4, 96)))
    tier = ("very hard" if score >= 82 else "hard" if score >= 66 else "moderate" if score >= 48
            else "easy" if score >= 30 else "very easy")
    return {
        "difficulty": score, "tier": tier,
        "kd_parts": {"base": 30, "content_supply": round(supply, 1), "authority_load": round(authority, 1),
                     "head_term_tax": round(head, 1), "longtail_relief": round(opening, 1),
                     "intent_adjust": intent_adj, "freshness_gap": round(freshness, 1),
                     "competitor_depth": round(depth, 1)},
        "explain": f"{words} words, {intent} intent, {coverage_items} fresh competing items, "
                   f"{suggest_count} autocomplete variants ({question_suggests} questions), "
                   f"{round(authority_share*100)}% authoritative domains.",
    }


# --------------------------------------------------------------------- velocity
def velocity(series: list[dict], history: list[dict], age_hours: float | None) -> dict:
    vals = [s.get("v") or s.get("views", 0) for s in series] if series else []
    slope = util.slope([float(v) for v in vals]) if len(vals) >= 4 else 0.0
    scan_delta = 0.0
    if len(history) >= 2:
        a, b = history[-2]["volume"] or 1, history[-1]["volume"] or 1
        scan_delta = (b - a) / max(a, 1)
    combined = util.clamp(0.65 * slope + 0.35 * scan_delta, -1.0, 6.0)
    if abs(combined) < 0.05 and age_hours:
        combined = util.clamp(0.25 * math.exp(-age_hours / 40), -1, 6)  # freshness-only proxy
    label = velocity_label(combined)
    return {"velocity": round(combined, 4), "velocity_label": label,
            "series_slope": round(slope, 4), "scan_delta": round(scan_delta, 4)}


def velocity_label(v: float | None) -> str:
    """Velocity is relative growth per day (0.45 = +45%/day), shared by the API and the writer."""
    v = v or 0
    return ("spiking" if v > 0.45 else "rising" if v > 0.15 else "stable" if v > -0.10 else "cooling")


# --------------------------------------------------------------------- opportunity
def opportunity(*, volume: int, difficulty: int, velocity_v: float, intent: str,
                coverage_items: int, suggest_count: int, corroboration: int) -> dict:
    vol_score = util.clamp(math.log10(max(volume, 1)) / math.log10(60_000) * 100, 0, 100)
    kd_score = 100 - difficulty
    vel_score = util.clamp((velocity_v + 0.2) / 1.6 * 100, 0, 100)
    depth_score = util.clamp(min(suggest_count, 14) * 5 + corroboration * 8, 0, 100)
    raw = 0.34 * vol_score + 0.28 * kd_score + 0.22 * vel_score + 0.16 * depth_score
    raw *= INTENT_WEIGHT.get(intent, 1.0)
    if coverage_items == 0:
        raw *= 0.94  # no press at all can mean no demand, not no competition
    score = int(round(util.clamp(raw, 0, 99)))
    label = ("Momentum pick" if score >= 74 else "Quick win" if score >= 58
             else "Needs an angle" if score >= 42 else "Pass for now")
    return {"opportunity": score, "opportunity_label": label,
            "opportunity_parts": {"demand": round(vol_score, 1), "rankability": round(kd_score, 1),
                                  "velocity": round(vel_score, 1), "query_depth": round(depth_score, 1),
                                  "intent_weight": INTENT_WEIGHT.get(intent, 1.0)},
            "intent_label": INTENT_LABEL.get(intent, intent)}


def cpc_estimate(niche_slug: str, intent: str, volume: int) -> float:
    base = CPC_BASE.get(niche_slug, 1.6)
    mult = {"transactional": 1.5, "commercial": 1.3, "informational": 0.85, "navigational": 0.6, "news": 0.5}[intent]
    val = base * mult * (0.75 + 0.25 * math.log10(max(volume, 10)))
    return round(min(max(val, 0.05), 42.0), 2)
