"""Default niche definitions. Seeds are head terms; include/exclude shape relevance scoring."""
from __future__ import annotations

DEFAULT_NICHES = [
    dict(
        name="AI & Future Tech", slug="ai-tech", color="#7c5cff",
        seed_keywords=["ai agents", "llm", "openai", "generative ai", "ai coding", "inference", "multimodal", "rag"],
        include_terms="""ai model llm gpt agent agents chip gpu claude gemini openai anthropic nvidia
            automation inference fine tune fine-tuning dataset benchmark voice robot robotics startup
            coding assistant chatbot safety regulation chip datacenter""".split(),
        exclude_terms="""celebrity recipe horoscope election football cricket mortgage weather
            lottery royal""".split(),
        sources=["google_trends", "google_news", "hackernews", "wikipedia_top", "github"],
        min_opportunity=55, min_volume=400, max_difficulty=70, word_target=1150,
    ),
    dict(
        name="Personal Finance", slug="money", color="#22c07a",
        seed_keywords=["savings account", "index fund", "credit score", "mortgage rates", "inflation", "retirement"],
        include_terms="""rate rates savings investing investor stocks stock bond etf index fund
            money market certificate retirement 401k ira tax irs credit card loan mortgage inflation
            dividend portfolio broker fees fee yield interest""".split(),
        exclude_terms=["football", "movie", "recipe", "celebrity", "stadium", "jersey"],
        sources=["google_trends", "google_news", "wikipedia_top"],
        min_opportunity=58, min_volume=500, max_difficulty=66, word_target=1200,
    ),
    dict(
        name="Health & Fitness", slug="health", color="#ff7a59",
        seed_keywords=["longevity", "sleep", "protein", "strength training", "glp-1", "walking"],
        include_terms="""sleep protein muscle training workout exercise longevity diet health patients
            trial calories recovery walking running gym bp blood glucose supplement coach fitness
            weight""".split(),
        exclude_terms=["election", "senate", "stock", "mortgage", "movie", "festival"],
        sources=["google_trends", "google_news", "wikipedia_top"],
        min_opportunity=58, min_volume=600, max_difficulty=72, word_target=1100,
    ),
    dict(
        name="Travel", slug="travel", color="#2ea8ff",
        seed_keywords=["cheap flights", "travel insurance", "digital nomad visa", "airport", "itinerary"],
        include_terms="""flight flights airport airline hotel resort visa passport train rail cruise
            itinerary travel tourism destination beach season weather closure tourists""".split(),
        exclude_terms=["stock", "mortgage", "election", "football", "quarterly"],
        sources=["google_trends", "google_news", "wikipedia_top"],
        min_opportunity=55, min_volume=400, max_difficulty=70, word_target=1000,
    ),
]
