"""TrendWriter - trend monitor + SEO auto-drafter (stdlib only)."""
__version__ = "1.0.0"
