"""HTTP layer: JSON API + the dashboard static files, on stdlib only (no framework, no deps)."""
from __future__ import annotations

import json
import os
import re
import threading
import traceback
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import db, metrics, pipeline, sources, util, writer
from .pipeline import DEFAULT_SETTINGS, Scheduler, ensure_defaults, get_settings, run_scan, set_settings

WEB_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "web")
ROUTES: list[tuple[str, re.Pattern, str]] = []
_scan_lock = threading.Lock()
scheduler = Scheduler()


def route(method: str, pattern: str):
    def deco(fn):
        ROUTES.append((method, re.compile("^" + pattern + "$"), fn.__name__))
        return fn
    return deco


# --------------------------------------------------------------------- serialisers
def _json_loads(val, default):
    try:
        return json.loads(val) if isinstance(val, str) else (val or default)
    except (json.JSONDecodeError, TypeError):
        return default


def topic_row(r: dict, deep: bool = False) -> dict:
    out = {"id": r["id"], "term": r["term"], "niche_id": r["niche_id"], "intent": r["intent"],
           "volume_month": r["volume_month"], "volume_daily": r["volume_daily"], "difficulty": r["difficulty"],
           "opportunity": r["opportunity"], "velocity": r["velocity"], "label": r["score_label"],
           "cpc": r["cpc"], "status": r["status"], "first_seen": r["first_seen"], "last_seen": r["last_seen"],
           "seen_count": r["seen_count"], "cluster_id": r.get("cluster_id"), "angle": r.get("angle"),
           "sources": _json_loads(r["sources"], []), "kd": _json_loads(r["kd_parts"], {}),
           "signals": _json_loads(r["signals"], {}),
           "draft_id": db.one("SELECT id FROM drafts WHERE topic_id=? ORDER BY id DESC LIMIT 1", (r["id"],))}
    out["draft_id"] = out["draft_id"]["id"] if out.get("draft_id") else None
    if deep:
        out["evidence"] = _json_loads(r["evidence"], [])
        out["series"] = _json_loads(r["series"], [])
        out["history"] = _json_loads(r["history"], [])
        out["keywords"] = db.rows("SELECT keyword,kind,volume,difficulty,cpc,position FROM keywords "
                                  "WHERE topic_id=? ORDER BY position LIMIT 40", (r["id"],))
    return out


def draft_row(r: dict, deep: bool = False) -> dict:
    out = {"id": r["id"], "topic_id": r["topic_id"], "niche_id": r["niche_id"], "title": r["title"],
           "slug": r["slug"], "meta_description": r["meta_description"], "focus_keyword": r["focus_keyword"],
           "word_count": r["word_count"], "reading_time": r["reading_time"], "readability": r["readability"],
           "keyword_density": r["keyword_density"], "seo_score": r["seo_score"], "status": r["status"],
           "writer": r["writer"], "llm_model": r["llm_model"], "created_at": r["created_at"],
           "published_at": r["published_at"], "updated_at": r["updated_at"],
           "file_md": r.get("file_md"), "file_html": r.get("file_html"),
           "secondary": _json_loads(r["secondary_keywords"], []), "audit": _json_loads(r["audit"], [])}
    if deep:
        out["markdown"] = r["markdown"]
        out["html"] = r["html"]
        out["json_ld"] = _json_loads(r["json_ld"], {})
    return out


def niche_row(r: dict) -> dict:
    n = dict(r)
    for k in ("seed_keywords", "include_terms", "exclude_terms", "sources", "regions"):
        n[k] = _json_loads(n.get(k), [])
    counts = db.one("SELECT COUNT(*) AS topics, SUM(opportunity>=min_opportunity) AS qualifying,"
                    " MAX(last_seen) AS last FROM topics t JOIN niches k ON k.id=t.niche_id WHERE k.id=?", (r["id"],)) or {}
    n["topic_count"] = counts.get("topics") or 0
    n["qualifying_count"] = counts.get("qualifying") or 0
    n["draft_count"] = db.one("SELECT COUNT(*) AS n FROM drafts WHERE niche_id=?", (r["id"],))["n"]
    n["published_count"] = db.one("SELECT COUNT(*) AS n FROM drafts WHERE niche_id=? AND status='published'",
                                  (r["id"],))["n"]
    return n


def safe_settings(st: dict) -> dict:
    st = json.loads(json.dumps(st))
    key = st.get("llm", {}).get("api_key") or ""
    st["llm"]["api_key_set"] = bool(key)
    st["llm"]["api_key_hint"] = (key[:4] + "…" + key[-4:]) if len(key) > 10 else ("" if not key else "set")
    st["llm"]["api_key"] = ""
    return st


# --------------------------------------------------------------------- handlers
@route("GET", r"/api/state")
def api_state(h, q, body):
    st = get_settings()
    stats = db.one("SELECT (SELECT COUNT(*) FROM topics) AS topics,"
                   " (SELECT COUNT(*) FROM topics WHERE opportunity>=58) AS quick_wins,"
                   " (SELECT COUNT(*) FROM topics WHERE status='new') AS fresh,"
                   " (SELECT COUNT(*) FROM drafts) AS drafts,"
                   " (SELECT COUNT(*) FROM drafts WHERE status='draft') AS pending,"
                   " (SELECT COUNT(*) FROM drafts WHERE status='published') AS published,"
                   " (SELECT COALESCE(SUM(volume_month),0) FROM topics) AS reach,"
                   " (SELECT COUNT(*) FROM scans) AS scans")
    last = db.one("SELECT * FROM scans ORDER BY id DESC LIMIT 1")
    if last:
        last["source_health"] = _json_loads(last["source_health"], [])
        last.pop("detail", None)
    niche_rows = [niche_row(n) for n in db.rows("SELECT * FROM niches ORDER BY id")]
    top = [topic_row(r) for r in db.rows("SELECT * FROM topics ORDER BY opportunity DESC LIMIT 40")]
    return 200, {"stats": stats, "settings": safe_settings(st), "scheduler": {"running": scheduler.running,
            "next_run": scheduler.next_run, "enabled": bool(st.get("enabled")), "cadence_min": st["cadence_min"]},
            "niches": niche_rows, "last_scan": last, "top_topics": top,
            "recent_drafts": [draft_row(r) for r in db.rows("SELECT * FROM drafts ORDER BY id DESC LIMIT 8")],
            "now": util.now_iso()}


@route("GET", r"/api/topics")
def api_topics(h, q, body):
    where, args = ["1=1"], []
    if q.get("niche"):
        where.append("t.niche_id=?"); args.append(q["niche"])
    if q.get("status"):
        where.append("t.status=?"); args.append(q["status"])
    if q.get("q"):
        where.append("(t.term LIKE ? OR t.score_label LIKE ? OR t.intent LIKE ?)")
        args += [f"%{q['q']}%"] * 3
    sort = {"volume": "t.volume_month DESC", "difficulty": "t.difficulty ASC", "age": "t.first_seen DESC",
            "velocity": "t.velocity DESC", "opportunity": "t.opportunity DESC"}.get(q.get("sort", "opportunity"),
                                                                                     "t.opportunity DESC")
    rows = db.rows(f"SELECT t.* FROM topics t WHERE {' AND '.join(where)} ORDER BY {sort} LIMIT ?",
                   (*args, min(int(q.get("limit", 100)), 400)))
    return 200, {"topics": [topic_row(r, deep=bool(q.get("deep"))) for r in rows], "count": len(rows)}


@route("GET", r"/api/topics/(?P<tid>\d+)")
def api_topic(h, q, body, tid):
    r = db.one("SELECT * FROM topics WHERE id=?", (int(tid),))
    if not r:
        return 404, {"error": "topic not found"}
    out = topic_row(r, deep=True)
    out["niche"] = db.one("SELECT id,name,slug,color,word_target FROM niches WHERE id=?", (r["niche_id"],))
    out["scan_sources"] = _json_loads(r["sources"], [])
    out["draft"] = (draft_row(db.one("SELECT * FROM drafts WHERE topic_id=? ORDER BY id DESC LIMIT 1", (r["id"],)))
                    if out["draft_id"] else None)
    siblings = db.rows("SELECT * FROM topics WHERE cluster_id IS NOT NULL AND cluster_id=? AND id!=? "
                       "ORDER BY opportunity DESC LIMIT 6", (out["cluster_id"] or r["id"], r["id"]))
    out["cluster"] = [topic_row(s) for s in siblings]
    return 200, out


@route("POST", r"/api/scan")
def api_scan(h, q, body):
    if not _scan_lock.acquire(blocking=False):
        return 409, {"error": "a scan is already running"}
    niche_ids = (body or {}).get("niche_ids")

    def worker():
        try:
            run_scan(trigger="manual", niche_filter=niche_ids)
        except Exception as exc:  # noqa: BLE001
            db.log_event("error", f"manual scan failed: {type(exc).__name__}: {exc}",
                         {"trace": traceback.format_exc()[-800:]})
        finally:
            _scan_lock.release()

    threading.Thread(target=worker, daemon=True).start()
    return 202, {"started": True, "note": "scan running in background; poll /api/scans"}


@route("GET", r"/api/scans")
def api_scans(h, q, body):
    rows = db.rows("SELECT * FROM scans ORDER BY id DESC LIMIT ?", (min(int(q.get("limit", 25)), 100),))
    for r in rows:
        r["source_health"] = _json_loads(r["source_health"], [])
    return 200, {"scans": rows, "running": _scan_lock.locked()}


@route("POST", r"/api/sources/test")
def api_sources_test(h, q, body):
    out = []
    for name in get_settings()["sources"]:
        try:
            if name == "google_trends":
                rec = sources.guarded(name, sources.google_trends_rss, "US")
            elif name == "google_news":
                rec = sources.guarded(name, sources.google_news_rss, "ai agents", "US", 8)
            elif name == "hackernews":
                rec = sources.guarded(name, sources.hackernews, None, 48, 10, 8)
            elif name == "wikipedia_top":
                rec = sources.guarded(name, sources.wikipedia_top_views, "en", 1, 20)
            elif name == "github":
                rec = sources.guarded(name, sources.github_search, "ai agent", 30, 6)
            elif name == "reddit":
                rec = sources.guarded(name, sources.reddit_hot, "artificial", 8)
            else:
                rec = {"source": name, "ok": False, "error": "unknown source", "items": 0, "ms": 0}
        except Exception as exc:  # noqa: BLE001
            rec = {"source": name, "ok": False, "error": str(exc), "items": 0, "ms": 0}
        rec.pop("_items", None)
        out.append(rec)
    sug = sources.google_suggest("ai agents", extra=("how", "best"))
    return 200, {"sources": out, "autocomplete_sample": sug[:8]}


@route("GET", r"/api/search")
def api_search(h, q, body):
    term = (q.get("keyword") or "").strip()
    if not term:
        return 400, {"error": "keyword required"}
    niche = db.one("SELECT * FROM niches WHERE slug=?", (q.get("niche"),)) or db.one("SELECT * FROM niches ORDER BY id LIMIT 1")
    res = pipeline.analyze_keyword(term, niche)
    return 200, res


@route("POST", r"/api/search/draft")
def api_search_draft(h, q, body):
    term = ((body or {}).get("keyword") or "").strip()
    if not term:
        return 400, {"error": "keyword required"}
    nid = (body or {}).get("niche_id")
    niche = db.one("SELECT * FROM niches WHERE id=?", (int(nid),)) if nid else db.one("SELECT * FROM niches ORDER BY id LIMIT 1")
    tid = pipeline.store_keyword_topic(term, niche)
    d = pipeline.create_draft(tid, trigger="manual")
    if not d:
        return 500, {"error": "draft failed to generate"}
    return 201, {"draft": draft_row(d, deep=True), "topic": topic_row(db.one("SELECT * FROM topics WHERE id=?", (tid,)), True)}


@route("GET", r"/api/drafts")
def api_drafts(h, q, body):
    where, args = ["1=1"], []
    if q.get("status"):
        where.append("d.status=?"); args.append(q["status"])
    if q.get("niche"):
        where.append("d.niche_id=?"); args.append(q["niche"])
    rows = db.rows(f"SELECT d.* FROM drafts d WHERE {' AND '.join(where)} ORDER BY d.id DESC LIMIT ?",
                   (*args, min(int(q.get("limit", 100)), 300)))
    out = []
    for r in rows:
        d = draft_row(r)
        t = db.one("SELECT term, volume_month, difficulty, opportunity, intent FROM topics WHERE id=?", (r["topic_id"],))
        d["topic"] = t
        d["niche"] = db.one("SELECT name,slug,color FROM niches WHERE id=?", (r["niche_id"],))
        out.append(d)
    return 200, {"drafts": out, "count": len(out)}


@route("GET", r"/api/drafts/(?P<did>\d+)")
def api_draft(h, q, body, did):
    r = db.one("SELECT * FROM drafts WHERE id=?", (int(did),))
    if not r:
        return 404, {"error": "draft not found"}
    out = draft_row(r, deep=True)
    out["topic"] = db.one("SELECT * FROM topics WHERE id=?", (r["topic_id"],)) if r["topic_id"] else None
    out["niche"] = db.one("SELECT name,slug,color,word_target FROM niches WHERE id=?", (r["niche_id"],))
    out["keywords"] = db.rows("SELECT keyword,kind,volume,difficulty,cpc FROM keywords WHERE topic_id=? ORDER BY position LIMIT 20",
                             (r["topic_id"],)) if r["topic_id"] else []
    return 200, out


@route("POST", r"/api/drafts")
def api_create_draft(h, q, body):
    tid = (body or {}).get("topic_id")
    if not tid:
        return 400, {"error": "topic_id required"}
    if _scan_lock.locked():
        return 409, {"error": "scan in progress, try in a moment"}
    d = pipeline.create_draft(int(tid), trigger="manual")
    return (201, {"draft": draft_row(d, deep=True)}) if d else (500, {"error": "could not draft this topic"})


@route("POST", r"/api/drafts/(?P<did>\d+)/regenerate")
def api_regenerate(h, q, body, did):
    d = db.one("SELECT * FROM drafts WHERE id=?", (int(did),))
    if not d:
        return 404, {"error": "draft not found"}
    if not d["topic_id"]:
        return 400, {"error": "draft has no linked topic"}
    db.run("DELETE FROM drafts WHERE id=?", (d["id"],))
    db.run("UPDATE topics SET status='watching' WHERE id=?", (d["topic_id"],))
    nd = pipeline.create_draft(d["topic_id"], trigger="manual-regenerate")
    return 201, {"draft": draft_row(nd, deep=True)}


@route("PATCH", r"/api/drafts/(?P<did>\d+)")
def api_patch_draft(h, q, body, did):
    d = db.one("SELECT * FROM drafts WHERE id=?", (int(did),))
    if not d:
        return 404, {"error": "draft not found"}
    body = body or {}
    allowed = {"title", "meta_description", "markdown", "status", "slug", "focus_keyword"}
    fields = {k: v for k, v in body.items() if k in allowed and v is not None}
    if not fields:
        return 400, {"error": "nothing to update", "allowed": sorted(allowed)}
    if "markdown" in fields or "title" in fields or "meta_description" in fields:
        md = fields.get("markdown", d["markdown"])
        title = fields.get("title", d["title"])
        meta = fields.get("meta_description", d["meta_description"])
        score, checks, stats = writer.audit(md, title, meta, fields.get("focus_keyword", d["focus_keyword"]))
        fields.update({"seo_score": score, "audit": json.dumps(checks), "word_count": stats["word_count"],
                       "readability": stats["readability"], "keyword_density": stats["keyword_density"],
                       "reading_time": stats["reading_time"]})
        topic = db.one("SELECT * FROM topics WHERE id=?", (d["topic_id"],)) if d["topic_id"] else None
        niche = db.one("SELECT * FROM niches WHERE id=?", (d["niche_id"],))
        faq = writer._faq_from_md(md)
        ld = writer.json_ld(title, d["slug"], meta, faq, (niche or {}).get("name", ""), d["created_at"] or util.now_iso(),
                            [k["keyword"] for k in db.rows("SELECT keyword FROM keywords WHERE topic_id=? LIMIT 8",
                                                           (d["topic_id"],))] if topic else [], f"{title} chart")
        fields["html"] = writer.render_html(md, {"title": title, "meta_description": meta, "slug": d["slug"],
                                                "niche": (niche or {}).get("name", ""), "date": d["created_at"] or util.now_iso(),
                                                "json_ld": ld, "keywords": []}, (niche or {}).get("color", "#7c5cff"))
        fields["json_ld"] = json.dumps(ld)
    fields["updated_at"] = util.now_iso()
    sets = ",".join(f"{k}=?" for k in fields)
    db.run(f"UPDATE drafts SET {sets} WHERE id=?", (*fields.values(), int(did)))
    if fields.get("status") == "published":
        return 200, {"draft": draft_row(pipeline.publish_draft(int(did)), deep=True)}
    return 200, {"draft": draft_row(db.one("SELECT * FROM drafts WHERE id=?", (int(did),)), deep=True)}


@route("POST", r"/api/drafts/(?P<did>\d+)/publish")
def api_publish(h, q, body, did):
    out = pipeline.publish_draft(int(did))
    return (200, {"draft": draft_row(out)}) if out else (404, {"error": "draft not found"})


@route("DELETE", r"/api/drafts/(?P<did>\d+)")
def api_delete_draft(h, q, body, did):
    d = db.one("SELECT * FROM drafts WHERE id=?", (int(did),))
    if not d:
        return 404, {"error": "draft not found"}
    db.run("DELETE FROM drafts WHERE id=?", (int(did),))
    if d["topic_id"]:
        db.run("UPDATE topics SET status='watching' WHERE id=?", (d["topic_id"],))
    db.log_event("delete", f"Deleted draft #{did}")
    return 200, {"deleted": int(did)}


@route("POST", r"/api/topics/(?P<tid>\d+)/status")
def api_topic_status(h, q, body, tid):
    status = (body or {}).get("status")
    if status not in {"new", "watching", "drafted", "published", "dismissed", "stale"}:
        return 400, {"error": "bad status"}
    db.run("UPDATE topics SET status=? WHERE id=?", (status, int(tid)))
    return 200, {"ok": True}


@route("GET", r"/api/niches")
def api_niches(h, q, body):
    return 200, {"niches": [niche_row(n) for n in db.rows("SELECT * FROM niches ORDER BY id")]}


@route("POST", r"/api/niches")
def api_new_niche(h, q, body):
    b = body or {}
    if not b.get("name") or not b.get("seed_keywords"):
        return 400, {"error": "name and seed_keywords are required"}
    slug = util.slugify(b.get("slug") or b["name"], 30)
    if db.one("SELECT id FROM niches WHERE slug=?", (slug,)):
        slug = f"{slug}-{db.one('SELECT COUNT(*) AS n FROM niches')['n']}"
    nid = db.run("INSERT INTO niches(name,slug,seed_keywords,include_terms,exclude_terms,sources,regions,"
                 "min_opportunity,min_volume,max_difficulty,auto_draft,word_target,cadence_min,color,created_at,updated_at)"
                 " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                 (b["name"], slug, json.dumps(b["seed_keywords"]), json.dumps(b.get("include_terms", [])),
                  json.dumps(b.get("exclude_terms", [])), json.dumps(b.get("sources", [])),
                  json.dumps(b.get("regions", ["US"])), int(b.get("min_opportunity", 55)), int(b.get("min_volume", 400)),
                  int(b.get("max_difficulty", 70)), 1 if b.get("auto_draft", True) else 0,
                  int(b.get("word_target", 1100)), int(b.get("cadence_min", 0)), b.get("color", "#4ad3c1"),
                  util.now_iso(), util.now_iso()))
    db.log_event("niche", f"Added niche {b['name']}")
    return 201, {"niche": niche_row(db.one("SELECT * FROM niches WHERE id=?", (nid,)))}


@route("PUT", r"/api/niches/(?P<nid>\d+)")
def api_put_niche(h, q, body, nid):
    b = body or {}
    cols = {"name": str, "min_opportunity": int, "min_volume": int, "max_difficulty": int, "word_target": int,
            "cadence_min": int, "color": str, "enabled": lambda v: 1 if v else 0, "auto_draft": lambda v: 1 if v else 0}
    json_cols = {"seed_keywords": list, "include_terms": list, "exclude_terms": list, "sources": list, "regions": list}
    fields = {}
    for k, cast in {**cols, **json_cols}.items():
        if k in b:
            fields[k] = json.dumps(cast(b[k])) if k in json_cols else cast(b[k])
    if not fields:
        return 400, {"error": "no editable fields supplied"}
    fields["updated_at"] = util.now_iso()
    db.run(f"UPDATE niches SET {','.join(f'{k}=?' for k in fields)} WHERE id=?", (*fields.values(), int(nid)))
    run_scan(trigger="niche-update", niche_filter=[int(nid)]) if b.get("rescan") else None
    return 200, {"niche": niche_row(db.one("SELECT * FROM niches WHERE id=?", (int(nid),)))}


@route("DELETE", r"/api/niches/(?P<nid>\d+)")
def api_del_niche(h, q, body, nid):
    db.run("DELETE FROM niches WHERE id=?", (int(nid),))
    db.run("DELETE FROM topics WHERE niche_id=?", (int(nid),))
    db.run("DELETE FROM drafts WHERE niche_id=?", (int(nid),))
    return 200, {"deleted": int(nid)}


@route("GET", r"/api/settings")
def api_get_settings(h, q, body):
    return 200, {"settings": safe_settings(get_settings()), "defaults": DEFAULT_SETTINGS}


@route("POST", r"/api/settings")
def api_put_settings(h, q, body):
    patch = {k: v for k, v in (body or {}).items() if k in DEFAULT_SETTINGS}
    st = set_settings(patch) if patch else get_settings()
    if "cadence_min" in patch:
        scheduler.next_run = None
    db.log_event("settings", "Settings updated", {"keys": sorted(patch)})
    return 200, {"settings": safe_settings(st)}


@route("POST", r"/api/scheduler")
def api_scheduler(h, q, body):
    action = (body or {}).get("action")
    if action == "pause":
        set_settings({"enabled": False})
    elif action == "resume":
        set_settings({"enabled": True})
        scheduler.next_run = None
    elif action == "trigger":
        scheduler.trigger_now()
    else:
        return 400, {"error": "action must be pause|resume|trigger"}
    return 200, {"action": action, "enabled": bool(get_settings()["enabled"]), "next_run": scheduler.next_run}


@route("GET", r"/api/logs")
def api_logs(h, q, body):
    return 200, {"events": db.rows("SELECT * FROM events ORDER BY id DESC LIMIT ?", (min(int(q.get("limit", 60)), 300),))}


@route("GET", r"/api/export/(?P<did>\d+)\.(?P<fmt>md|html|json)")
def api_export(h, q, body, did, fmt):
    d = db.one("SELECT * FROM drafts WHERE id=?", (int(did),))
    if not d:
        return 404, {"error": "not found"}
    if fmt == "md":
        body_text = d["markdown"]
        ctype, disp = "text/markdown; charset=utf-8", f"attachment; filename={d['slug']}.md"
    elif fmt == "html":
        body_text = d["html"]
        ctype, disp = "text/html; charset=utf-8", "inline" if q.get("view") == "1" else f"attachment; filename={d['slug']}.html"
    else:
        body_text = json.dumps({"draft": draft_row(d, deep=True),
                                "topic": db.one("SELECT * FROM topics WHERE id=?", (d["topic_id"],))},
                              indent=1, default=str)
        ctype, disp = "application/json", f"attachment; filename={d['slug']}.json"
    h.send_response(200)
    h.send_header("Content-Type", ctype)
    h.send_header("Content-Disposition", disp)
    h.send_header("Content-Length", str(len(body_text.encode())))
    h.end_headers()
    return None, body_text.encode()


@route("GET", r"/api/preview/(?P<did>\d+)")
def api_preview(h, q, body, did):
    d = db.one("SELECT * FROM drafts WHERE id=?", (int(did),))
    if not d:
        return 404, {"error": "not found"}
    return api_export(h, {"view": "1"}, None, did, "html")


@route("GET", r"/api/feed\.xml")
def api_feed(h, q, body):
    rows = db.rows("SELECT * FROM drafts WHERE status IN ('published','reviewed') ORDER BY id DESC LIMIT 25")
    site = (get_settings().get("site") or {}).get("domain", "https://example.com").rstrip("/")
    items = []
    for r in rows:
        items.append("<item><title>{}</title><link>{}/preview/{}</link><guid>{}/preview/{}</guid>"
                     "<description>{}</description><pubDate>{}</pubDate></item>".format(
                         util.html.escape(r["title"]), site, r["id"], site, r["id"],
                         util.html.escape(r["meta_description"] or ""),
                         (r["published_at"] or r["created_at"]).replace("+00:00", "Z")))
    xml = ('<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel><title>TrendWriter published feed</title>'
           f'<link>{site}</link><description>Auto-drafted SEO articles</description>' + "".join(items) +
           "</channel></rss>")
    payload = xml.encode()
    h.send_response(200)
    h.send_header("Content-Type", "application/rss+xml; charset=utf-8")
    h.send_header("Content-Length", str(len(payload)))
    h._cors()
    h.end_headers()
    return None, payload


@route("POST", r"/api/reset")
def api_reset(h, q, body):
    for t in ("topics", "keywords", "drafts", "scans", "events"):
        db.run(f"DELETE FROM {t}")
    db.log_event("system", "Data cleared (niches and settings kept)")
    return 200, {"ok": True}


# --------------------------------------------------------------------- server
MIME = {".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8",
        ".css": "text/css; charset=utf-8", ".svg": "image/svg+xml", ".json": "application/json",
        ".ico": "image/x-icon", ".png": "image/png"}


class Handler(BaseHTTPRequestHandler):
    server_version = "TrendWriter/1.0"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):  # quieter console
        if os.environ.get("TW_VERBOSE"):
            super().log_message(fmt, *args)

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,PATCH,PUT,DELETE,OPTIONS")

    def _send(self, code, payload, ctype="application/json"):
        if isinstance(payload, (dict, list)):
            data = json.dumps(payload, default=str).encode()
        elif isinstance(payload, bytes):
            data = payload
        else:
            data = str(payload).encode()
        self.send_response(code)
        self.send_header("Content-Type", f"{ctype}; charset=utf-8" if ctype.startswith("text") else ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self._cors()
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _body(self):
        length = int(self.headers.get("Content-Length") or 0)
        if not length:
            return None
        raw = self.rfile.read(length)
        try:
            return json.loads(raw.decode())
        except (json.JSONDecodeError, UnicodeDecodeError):
            return {"_raw": raw.decode("utf-8", "replace")}

    def _dispatch(self, method):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        q = {k: v[0] for k, v in urllib.parse.parse_qs(parsed.query).items()}
        if method == "OPTIONS":
            self.send_response(204)
            self._cors()
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        if not path.startswith("/api/"):
            return self._static(path)
        for m, pat, fname in ROUTES:
            if m != method:
                continue
            match = pat.match(path)
            if not match:
                continue
            try:
                code, payload = getattr(self.server.api, fname)(self, q, self._body() if method in ("POST", "PATCH", "PUT") else None,
                                                                 **match.groupdict())
            except Exception as exc:  # noqa: BLE001
                db.log_event("error", f"{method} {path} -> {type(exc).__name__}: {exc}",
                             {"trace": traceback.format_exc()[-800:]})
                code, payload = 500, {"error": f"{type(exc).__name__}: {exc}",
                                      "trace": traceback.format_exc().splitlines()[-3:]}
            if code is None:  # handler already wrote headers; stream the raw payload
                if payload:
                    try:
                        self.wfile.write(payload)
                    except (BrokenPipeError, ConnectionResetError):
                        pass
                return
            return self._send(code, payload)
        return self._send(404, {"error": f"no route for {method} {path}"})

    def _static(self, path):
        if path in ("/", "/index.html"):
            path = "/index.html"
        full = os.path.normpath(os.path.join(WEB_DIR, path.lstrip("/")))
        if not full.startswith(WEB_DIR) or not os.path.isfile(full):
            return self._send(404, {"error": "not found", "path": path})
        with open(full, "rb") as fh:
            data = fh.read()
        self.send_response(200)
        self.send_header("Content-Type", MIME.get(os.path.splitext(full)[1], "application/octet-stream"))
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def do_GET(self):
        self._dispatch("GET")

    def do_POST(self):
        self._dispatch("POST")

    def do_PATCH(self):
        self._dispatch("PATCH")

    def do_PUT(self):
        self._dispatch("PUT")

    def do_DELETE(self):
        self._dispatch("DELETE")

    def do_OPTIONS(self):
        self._dispatch("OPTIONS")


class App(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, addr, api_module):
        super().__init__(addr, Handler)
        self.api = api_module


def create_server(host: str = "0.0.0.0", port: int = 8000) -> App:
    import sys

    ensure_defaults()
    return App((host, port), sys.modules[__name__])


def serve(host: str = "0.0.0.0", port: int = 8000, start_scheduler: bool = True) -> None:
    srv = create_server(host, port)
    if start_scheduler:
        scheduler.start()
    db.log_event("system", f"Serving on http://{host}:{port}")
    print(f"TrendWriter up on http://{host}:{port}  (data: {db.DATA_DIR})", flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        scheduler.stop()
        srv.shutdown()
