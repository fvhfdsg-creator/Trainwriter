"""Live signal fetchers. Everything here is keyless and network-tolerant: each fetcher either
returns candidate items or raises, and `guarded` turns that into a health record so one dead
source can never break a scan."""
from __future__ import annotations

import json
import re
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from urllib.parse import quote, urlencode

from . import util
from .util import http_json, http_text

TIMEOUT = 9.0
NEWS_TAG = re.compile(r"<!\[CDATA\[|\]\]>")


def guarded(name: str, fn, *args, **kwargs) -> dict:
    t0 = datetime.now(timezone.utc)
    try:
        items = fn(*args, **kwargs)
        return {"source": name, "ok": True, "items": len(items), "count": len(items), "error": None,
                "ms": int((datetime.now(timezone.utc) - t0).total_seconds() * 1000), "_items": items}
    except Exception as exc:  # noqa: BLE001 - source failure must not kill the scan
        return {"source": name, "ok": False, "items": 0, "count": 0, "error": f"{type(exc).__name__}: {exc}",
                "ms": int((datetime.now(timezone.utc) - t0).total_seconds() * 1000), "_items": []}


def _clean_title(title: str) -> str:
    t = NEWS_TAG.sub("", title or "").strip()
    t = re.sub(r"\s*[-|–—]\s*[A-Za-z0-9 .,'&-]{2,32}$", "", t)  # " - Reuters"
    return re.sub(r"\s+", " ", t)


def _iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).replace(microsecond=0).isoformat()


# --------------------------------------------------------------------- Google Trends
def google_trends_rss(region: str = "US") -> list[dict]:
    url = f"https://trends.google.com/trending/rss?geo={quote(region)}"
    raw = http_text(url, timeout=TIMEOUT)
    root = ET.fromstring(raw)
    HT = "{https://trends.google.com/daily/rss/}"
    out = []
    for item in root.iter("item"):
        title = (item.findtext("title") or "").strip()
        if not title:
            continue
        traffic = util.parse_traffic(item.findtext(f"{HT}approx_traffic"))
        pub = item.findtext("pubDate")
        age_h = 12.0
        if pub:
            try:
                dt = datetime.strptime(pub[:25].strip(), "%a, %d %b %Y %H:%M:%S").replace(tzinfo=timezone.utc)
                age_h = max(0.1, (datetime.now(timezone.utc) - dt).total_seconds() / 3600)
            except ValueError:
                pass
        news = []
        for n in item.findall(f"{HT}news_item_title"):
            news.append(n.text or "")
        urls = [u.text for u in item.findall(f"{HT}news_item_url") if u.text]
        out.append({
            "term": title, "title": title, "source": "google_trends", "region": region,
            "published": _iso(datetime.now(timezone.utc) - timedelta(hours=age_h)),
            "age_hours": round(age_h, 1), "raw_volume": traffic, "volume_daily_hint": traffic,
            "score_raw": (traffic or 500),
            "evidence": {"title": news[0] if news else f"Google Trends ({region})", "url": urls[0] if urls else url,
                         "source": "google_trends", "metric": f"~{util.human_int(traffic)}/day trending searches"},
        })
    return out


# --------------------------------------------------------------------- Google News RSS
def google_news_rss(query: str, region: str = "US", limit: int = 24) -> list[dict]:
    lang = "en"
    ceid = f"{lang}-{region}"
    url = ("https://news.google.com/rss/search?"
           + urlencode({"q": f"{query} when:7d", "hl": f"{lang}-{region}", "gl": region, "ceid": ceid}))
    raw = http_text(url, timeout=TIMEOUT)
    root = ET.fromstring(raw)
    out = []
    for item in list(root.iter("item"))[:limit]:
        title = _clean_title(item.findtext("title") or "")
        link = (item.findtext("link") or "").strip()
        pub = item.findtext("pubDate") or ""
        desc = re.sub(r"<[^>]+>", " ", item.findtext("description") or "")
        desc = NEWS_TAG.sub("", util.html.unescape(desc)).strip()
        age_h = 48.0
        try:
            dt = datetime.strptime(pub[:25].strip(), "%a, %d %b %Y %H:%M:%S")
            age_h = max(0.2, (datetime.now(timezone.utc) - dt.replace(tzinfo=timezone.utc)).total_seconds() / 3600)
        except ValueError:
            pass
        if not title:
            continue
        out.append({
            "term": title, "title": title, "snippet": desc[:400], "url": link,
            "source": "google_news", "region": region, "published": _iso(datetime.now(timezone.utc) - timedelta(hours=age_h)),
            "age_hours": round(age_h, 1), "raw_volume": None, "score_raw": max(1.0, 120 / (age_h + 3)),
            "evidence": {"title": title, "url": link, "source": "google_news",
                         "metric": f"covered {round(age_h)}h ago"},
        })
    return out


# --------------------------------------------------------------------- Wikipedia
def wikipedia_top_views(lang: str = "en", day_offset: int = 1, limit: int = 60) -> list[dict]:
    d = datetime.now(timezone.utc) - timedelta(days=day_offset)
    url = ("https://wikimedia.org/api/rest_v1/metrics/pageviews/top/"
           f"{quote(lang)}.wikipedia/all-access/{d.year:04d}/{d.month:02d}/{d.day:02d}")
    data = http_json(url, timeout=TIMEOUT)
    arts = data["items"][0]["articles"][:limit]
    out = []
    for i, a in enumerate(arts):
        views = int(a.get("views") or 0)
        out.append({
            "term": a["article"].replace("_", " "), "title": a["article"].replace("_", " "),
            "source": "wikipedia_top", "rank": i + 1, "raw_volume": views, "views_daily": views,
            "published": _iso(d), "age_hours": 24.0 * day_offset, "score_raw": views,
            "evidence": {"title": f"Wikipedia most-read: {a['article'].replace('_',' ')}",
                         "url": f"https://{lang}.wikipedia.org/wiki/{quote(a['article'])}",
                         "source": "wikipedia_top", "metric": f"{util.human_int(views)} views on {d.isoformat()}"},
        })
    return out


def wikipedia_article_series(title: str, days: int = 21, lang: str = "en") -> dict:
    """Daily pageviews for one article -> genuine time series for velocity + sparkline."""
    end = datetime.now(timezone.utc) - timedelta(days=1)
    start = end - timedelta(days=days - 1)
    art = re.sub(r"\s+", "_", title.strip())
    url = ("https://wikimedia.org/api/rest_v1/metrics/pageviews/per-article/"
           f"{quote(lang)}.wikipedia/all-access/user/{quote(art, safe='')}/daily/"
           f"{start.strftime('%Y%m%d')}/{end.strftime('%Y%m%d')}")
    try:
        data = http_json(url, timeout=TIMEOUT)
    except Exception:
        return {}
    series = []
    for it in data.get("items", []):
        try:
            series.append({"d": str(it["timestamp"])[:8], "views": int(it["views"])})
        except (KeyError, ValueError, TypeError):
            continue
    if not series:
        return {}
    views = [s["views"] for s in series]
    recent = views[-3:] or views
    prior = views[-10:-3] or views[: max(1, len(views) - 3)]
    avg = sum(views) / len(views)
    growth = (sum(recent) / len(recent)) / (sum(prior) / len(prior) or 1) - 1
    return {
        "title": art.replace("_", " "), "article_url": f"https://{lang}.wikipedia.org/wiki/{quote(art)}",
        "series": [{"d": s["d"], "v": s["views"]} for s in series], "avg_daily": int(avg),
        "peak_daily": max(views), "latest_daily": views[-1],
        "growth_3v7": round(growth, 4), "spike": round((max(views) / (avg or 1)), 2),
        "first_view": views[0], "last_view": views[-1],
    }


def wikipedia_search(term: str, limit: int = 5, lang: str = "en") -> dict:
    url = (f"https://{lang}.wikipedia.org/w/api.php?format=json&action=query&list=search&srlimit={limit}"
           f"&srsearch={quote(term)}&srprop=snippet")
    data = http_json(url, timeout=TIMEOUT, ttl=600)
    hits = data.get("query", {}).get("search", []) or []
    out = []
    for h in hits:
        out.append({"title": h.get("title", ""), "snippet": re.sub(r"<[^>]+>", "", h.get("snippet", "")),
                    "wordcount": h.get("wordcount", 0),
                    "url": f"https://{lang}.wikipedia.org/wiki/{quote(h.get('title','').replace(' ','_'))}"})
    exact = any(util.normalize_term(h["title"]) == util.normalize_term(term) for h in out)
    return {"results": out, "total_hits": int(data.get("query", {}).get("searchInfo", {}).get("totalHits", len(out)) or len(out)),
            "has_exact_article": exact}


def duckduckgo_instant(term: str) -> dict:
    url = "https://api.duckduckgo.com/?" + urlencode({"q": term, "format": "json", "no_html": 1, "skip_disambig": 1})
    try:
        data = http_json(url, timeout=7)
    except Exception:
        return {"has_answer": False, "domains": []}
    related = []
    for t in data.get("RelatedTopics", [])[:8]:
        if "Topics" in t:
            for s in t["Topics"][:4]:
                related.append(s)
        else:
            related.append(t)
    domains = []
    for r in related:
        u = r.get("FirstURL") or ""
        m = re.match(r"https?://([^/]+)", u)
        if m:
            domains.append(m.group(1))
    return {"has_answer": bool(data.get("AbstractText")), "abstract": (data.get("AbstractText") or "")[:600],
            "heading": data.get("Heading") or "", "answer_type": data.get("AnswerType") or "",
            "related": [{"text": re.sub(r"\s+-\s+\S+$", "", r.get("Text", "")), "url": r.get("FirstURL", "")} for r in related[:6]],
            "domains": domains}


# --------------------------------------------------------------------- autocomplete
def google_suggest(term: str, hl: str = "en", gl: str = "us", extra: tuple[str, ...] = ()) -> list[str]:
    """Live query space around a term; `extra` prefixes produce question long-tails."""
    out: list[str] = []
    seen = set()
    queries = [term] + [f"{p} {term}".strip() for p in extra]
    for q in queries:
        url = ("https://suggestqueries.google.com/complete/search?client=firefox&hl="
               f"{quote(hl)}&gl={quote(gl)}&q={quote(q)}")
        try:
            data = http_json(url, timeout=6)
        except Exception:
            continue
        for s in (data[1] if isinstance(data, list) and len(data) > 1 else [])[:12]:
            s = re.sub(r"\s+", " ", str(s)).strip()
            if s and s.lower() not in seen:
                seen.add(s.lower())
                out.append(s)
    return out


# --------------------------------------------------------------------- Hacker News / GitHub / Reddit
def hackernews(query: str | None = None, hours: int = 48, min_points: int = 15, limit: int = 30) -> list[dict]:
    params = {"tags": "story", "hitsPerPage": limit,
              "numericFilters": f"created_at_i>{int((datetime.now(timezone.utc)-timedelta(hours=hours)).timestamp())},points>={min_points}"}
    if query:
        params["query"] = query
    data = http_json("https://hn.algolia.com/api/v1/search_by_date?" + urlencode(params), timeout=TIMEOUT)
    out = []
    for h in data.get("hits", []):
        title = _clean_title(h.get("title") or h.get("story_title") or "")
        if not title:
            continue
        pts, comments = int(h.get("points") or 0), int(h.get("num_comments") or 0)
        created = datetime.fromisoformat(str(h["created_at"]).replace("Z", "+00:00")[:19]).replace(tzinfo=timezone.utc)
        age_h = max(0.1, (datetime.now(timezone.utc) - created).total_seconds() / 3600)
        out.append({
            "term": title, "title": title, "url": h.get("url") or f"https://news.ycombinator.com/item?id={h.get('objectID')}",
            "source": "hackernews", "points": pts, "comments": comments, "hn_id": h.get("objectID"),
            "published": h["created_at"], "age_hours": round(age_h, 1), "raw_volume": None,
            "score_raw": (pts + comments * 1.5) / (age_h + 6),
            "evidence": {"title": title, "url": f"https://news.ycombinator.com/item?id={h.get('objectID')}",
                         "source": "hackernews", "metric": f"{pts} points / {comments} comments in {round(age_h)}h"},
        })
    return out


def github_search(query: str, days: int = 30, limit: int = 15) -> list[dict]:
    since = (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%d")
    params = {"q": f"{query} created:>{since} stars:>25", "sort": "stars", "order": "desc", "per_page": limit}
    data = http_json("https://api.github.com/search/repositories?" + urlencode(params), timeout=TIMEOUT)
    out = []
    for r in data.get("items", [])[:limit]:
        desc = _clean_title(r.get("description") or "")
        out.append({
            "term": r["name"].replace("-", " ").replace("_", " "), "title": f"{r['name']}: {desc}"[:180],
            "url": r.get("html_url"), "source": "github", "stars": r.get("stargazers_count", 0),
            "published": r.get("created_at"), "age_hours": 240.0, "raw_volume": None,
            "score_raw": (r.get("stargazers_count", 0) ** 0.5) / 2,
            "evidence": {"title": f"GitHub: {r['name']}", "url": r.get("html_url", ""), "source": "github",
                         "metric": f"{util.human_int(r.get('stargazers_count', 0))} stars in {days}d"},
        })
    return out


def reddit_hot(subreddit: str, limit: int = 20) -> list[dict]:
    url = f"https://www.reddit.com/r/{quote(subreddit)}/hot.json?" + urlencode({"limit": limit, "raw_json": 1})
    data = http_json(url, timeout=TIMEOUT, headers={"Accept": "application/json"})
    out = []
    for c in data.get("data", {}).get("children", []):
        d = c.get("data", {})
        if d.get("stickied") or not d.get("title"):
            continue
        age_h = max(0.1, (datetime.now(timezone.utc) - datetime.fromtimestamp(d.get("created_utc", 0), timezone.utc)).total_seconds() / 3600)
        ratio = float(d.get("upvote_ratio") or 1)
        out.append({
            "term": _clean_title(d["title"]), "title": _clean_title(d["title"]), "url": "https://reddit.com" + d.get("permalink", ""),
            "source": "reddit", "subreddit": subreddit, "ups": d.get("ups", 0), "comments": d.get("num_comments", 0),
            "published": _iso(datetime.fromtimestamp(d.get("created_utc", 0), timezone.utc)),
            "age_hours": round(age_h, 1), "raw_volume": None,
            "score_raw": (int(d.get("ups", 0)) * ratio) / (age_h + 6),
            "evidence": {"title": _clean_title(d["title"]), "url": "https://reddit.com" + d.get("permalink", ""),
                         "source": "reddit", "metric": f"r/{subreddit}: {util.human_int(d.get('ups', 0))} upvotes"},
        })
    return out


# --------------------------------------------------------------------- offline simulation
_SIM = {
    "ai-tech": [
        ("local llm inference on a laptop", "runai", 7400), ("ai agent framework comparison", "buildstack", 4300),
        ("rag evaluation metrics", "vectorworks", 2600), ("voice ai receptionist for clinics", "voxloop", 1900),
        ("prompt caching cost savings", "tokprice", 1500), ("open weights model licensing", "opnsrc", 1200),
    ],
    "money": [
        ("high yield savings account rates today", "ratewatch", 12800), ("money market vs cd ladder", "bankguide", 6100),
        ("s&p 500 index fund fees compared", "fundlab", 8600), ("how to lower taxable brokerage drag", "taxwise", 3200),
        ("TIPS inflation-linked bonds explained", "treasury101", 2400),
    ],
    "health": [
        ("zone 2 vs hiit for fat loss", "cardiolab", 5200), ("sleep consistency and glucose", "circadia", 3800),
        ("protein per meal for muscle retention", "strengthmed", 6600), ("creatine dosing for older adults", "sarcopenia", 2900),
        ("walking cadence and blood pressure", "steplab", 4100),
    ],
    "travel": [
        ("cheapest month to book atlantis flights", "fairfinder", 2100), ("digital nomad visa paperwork", "nomadvault", 3400),
        ("bag policy loopholes on budget airlines", "carryononly", 4800), ("rail pass vs point-to-point tickets", "raileurope", 2600),
        ("airport lounge day pass value", "loungecalc", 1800),
    ],
}


def simulate(niche_slug: str, limit: int = 10) -> list[dict]:
    import random

    rng = random.Random(f"{niche_slug}-{datetime.now(timezone.utc).strftime('%Y-%m-%d-%H')}")
    pool = _SIM.get(niche_slug, _SIM["ai-tech"])
    out = []
    for i, (term, sub, vol) in enumerate(pool[:limit]):
        jitter = rng.uniform(0.85, 1.25)
        daily = int(vol * jitter / 30)
        out.append({
            "term": term, "title": term, "source": "simulated", "region": "SIM",
            "published": _iso(datetime.now(timezone.utc) - timedelta(hours=rng.uniform(2, 40))),
            "age_hours": round(rng.uniform(2, 40), 1), "raw_volume": daily, "volume_daily_hint": daily,
            "score_raw": daily, "simulated": True,
            "evidence": {"title": f"[simulated] {term}", "url": "", "source": "simulated",
                         "metric": f"~{util.human_int(daily)}/day baseline"},
        })
    return out
