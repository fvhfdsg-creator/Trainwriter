"""Shared helpers: HTTP with cache/retries, number parsing, text metrics, tiny markdown."""
from __future__ import annotations

import html
import json
import math
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

UA = "TrendWriter/1.0 (SEO research bot; +local-dashboard)"

# ---------------------------------------------------------------- HTTP + cache
_cache: dict[str, tuple[float, object]] = {}
_cache_lock = threading.Lock()


def cache_clear() -> None:
    with _cache_lock:
        _cache.clear()


def http_text(url: str, timeout: float = 8.0, ttl: float = 0.0, headers: dict | None = None) -> str:
    """GET a URL as text. ttl>0 enables a process-local response cache."""
    if ttl > 0:
        with _cache_lock:
            hit = _cache.get(url)
            if hit and (time.time() - hit[0]) < ttl:
                return hit[1]  # type: ignore[return-value]

    req = urllib.request.Request(url, headers={"User-Agent": UA, **(headers or {})})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = resp.read().decode("utf-8", "replace")

    if ttl > 0:
        with _cache_lock:
            _cache[url] = (time.time(), data)
    return data


def http_json(url: str, timeout: float = 8.0, ttl: float = 0.0, headers: dict | None = None):
    raw = http_text(url, timeout=timeout, ttl=ttl, headers=headers)
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:  # some endpoints answer JSONP-ish payloads
        stripped = raw.strip()
        if stripped.endswith(")"):
            stripped = stripped[stripped.index("(") + 1 : -1]
        return json.loads(stripped or "{}")


def http_post_json(url: str, payload: dict, timeout: float = 90.0, headers: dict | None = None):
    body = json.dumps(payload).encode()
    req = urllib.request.Request(
        url,
        data=body,
        method="POST",
        headers={"Content-Type": "application/json", "User-Agent": UA, **(headers or {})},
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8", "replace"))


# ---------------------------------------------------------------- numbers/text
def parse_traffic(text) -> int | None:
    """'+200' / '10,000+' / '2K+' / '1.4M' -> int (midpoint of the bucket)."""
    if text is None:
        return None
    s = str(text).strip().lower().replace(",", "").replace("+", "").replace("~", "")
    m = re.match(r"^([\d.]+)\s*([kmb]?)", s)
    if not m:
        return None
    mult = {"": 1, "k": 1_000, "m": 1_000_000, "b": 1_000_000_000}[m.group(2)]
    try:
        val = int(float(m.group(1)) * mult)
    except ValueError:
        return None
    if val and not re.search(r"[\d.]\s*$", s):  # bucket floor like "2K+" -> use midpoint of the order
        val = int(val * 1.5)
    return val or None


def human_int(n) -> str:
    if n is None:
        return "—"
    n = int(n)
    if n >= 1_000_000:
        return f"{n/1_000_000:.1f}M".replace(".0M", "M")
    if n >= 1_000:
        return f"{n/1_000:.1f}K".replace(".0K", "K")
    return str(n)


def clamp(v, lo=0.0, hi=100.0) -> float:
    return max(lo, min(hi, v))


def slugify(text: str, max_len: int = 70) -> str:
    s = re.sub(r"[^a-z0-9\s-]", "", (text or "").lower()).strip()
    s = re.sub(r"[\s_-]+", "-", s).strip("-")
    return (s[:max_len].rstrip("-")) or "untitled"


STOPWORDS = set(
    """a an the and or but if then than that this these those of to in on for with without at by from as
    is are was were be been being do does did doing it its it's what when where why how who whom which
    my your his her our their their i you he she we they me him them""".split()
)


def normalize_term(text: str) -> str:
    s = re.sub(r"[^a-z0-9\s&'+-]", " ", (text or "").lower())
    s = re.sub(r"\s+", " ", s).strip()
    return s


def content_words(text: str) -> list[str]:
    return [w for w in normalize_term(text).split() if len(w) > 2 and w not in STOPWORDS]


def tokens(text: str) -> set[str]:
    return set(content_words(text))


ACRONYMS = {"llm", "llms", "ai", "gpt", "api", "apis", "cpu", "gpu", "nvidia", "rag", "tips", "irs", "etf",
            "cd", "cds", "gdp", "seo", "app", "apps", "vpn", "saas", "ml", "it", "ux", "bp", "glp-1", "vo2",
            "401k", "hipaa", "fda", "url", "sdk", "us", "uk", "hn", "reddit", "github", "openai", "chatgpt"}


def titlecase_keyword(text: str) -> str:
    small = {"a", "an", "and", "as", "at", "but", "by", "for", "in", "of", "on", "or", "the", "to", "with"}
    parts = re.sub(r"\s+", " ", (text or "").strip()).split(" ")
    out = []
    for i, p in enumerate(parts):
        if re.search(r"[A-Z]{2,}", p):  # acronyms / brand casing preserved
            out.append(p)
        elif p.lower() in ACRONYMS and len(p) <= 5:
            out.append(p.upper() if p.lower() not in {"openai", "github", "reddit", "nvidia"} else p.capitalize())
        elif i and p.lower() in small:
            out.append(p.lower())
        else:
            out.append(p[:1].upper() + p[1:])
    return " ".join(out)


VOWELS = "aeiouy"


def syllables(word: str) -> int:
    w = re.sub(r"[^a-z]", "", word.lower())
    if not w:
        return 0
    count, prev = 0, False
    for ch in w:
        cur = ch in VOWELS
        if cur and not prev:
            count += 1
        prev = cur
    if w.endswith("e") and count > 1:
        count -= 1
    return max(1, count)


def flesch_reading_ease(text: str) -> float:
    sentences = [s for s in re.split(r"[.!?]+\s", re.sub(r"\s+", " ", text.strip())) if len(s) > 20]
    words = re.findall(r"[A-Za-z']+", text)
    if not sentences or not words:
        return 0.0
    syl = sum(syllables(w) for w in words)
    score = 206.835 - 1.015 * (len(words) / len(sentences)) - 84.6 * (syl / len(words))
    return round(clamp(score, -50, 120), 1)


def word_count(text: str) -> int:
    return len(re.findall(r"[A-Za-z0-9''\-]+", text))


def relative_time(dt_iso: str | None) -> str:
    if not dt_iso:
        return "never"
    try:
        dt = datetime.fromisoformat(dt_iso)
    except ValueError:
        return dt_iso
    delta = (datetime.now(timezone.utc) - dt).total_seconds()
    if delta < 0:
        delta = 0
    for limit, unit in ((90, "s"), (5_400, "m"), (129_600, "h"), (2_592_000, "d")):
        if delta < limit:
            div = {"s": 1, "m": 60, "h": 3600, "d": 86400}[unit]
            n = int(delta / div)
            return f"{max(n, 1)}{unit}" if unit != "s" and n >= 1 else ("just now" if n < 2 else f"{n}s")
    return dt[:10]


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def days_ago(n: int) -> datetime:
    return datetime.now(timezone.utc) - timedelta(days=n)


def slope(values: list[float]) -> float:
    """Least-squares slope, normalised by the mean -> relative daily growth rate."""
    n = len(values)
    if n < 3:
        return 0.0
    xs = list(range(n))
    mx, my = sum(xs) / n, sum(values) / n
    denom = sum((x - mx) ** 2 for x in xs) or 1e-9
    s = sum((x - mx) * (y - my) for x, y in zip(xs, values)) / denom
    return s / (abs(my) or 1.0)


# ---------------------------------------------------------------- markdown
_LIST_ITEM = re.compile(r"^\s*[-*]\s+(.*)$")
_NUM_ITEM = re.compile(r"^\s*\d+[.)]\s+(.*)$")
_TABLE_SEP = re.compile(r"^\s*\|?[\s:|-]+\|?\s*$")


_REF_DEF = re.compile(r'^\[([a-zA-Z0-9_-]{1,12})\]:\s*(\S+)\s*(?:".*"|\'.*\')?\s*$')


def _resolve_refs(md: str) -> tuple[str, dict]:
    """Turn `[text][ref]` + `[ref]: url` definitions into inline links before block parsing."""
    refs: dict[str, str] = {}
    kept = []
    for line in (md or "").splitlines():
        m = _REF_DEF.match(line.strip())
        if m:
            refs[m.group(1).lower()] = m.group(2)
            continue
        kept.append(line)
    body = "\n".join(kept)
    body = re.sub(r"\[([^\]]+)\]\[([a-zA-Z0-9_-]{1,12})\]",
                  lambda mm: f"[{mm.group(1)}]({refs.get(mm.group(2).lower(), '#')})", body)
    return body, refs


def _inline_html(text: str) -> str:
    t = html.escape(text, quote=False)
    t = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", t)
    t = re.sub(r"(?<![\w*])\*(?![\s*])([^*]+?)\*(?![\w*])", r"<em>\1</em>", t)
    t = re.sub(r"`([^`]+?)`", r"<code>\1</code>", t)
    t = re.sub(r"\[([^\]]+)\]\(([^)\s]+)\)", r'<a href="\2">\1</a>', t)
    return t


def _split_row(line: str) -> list[str]:
    return [c.strip() for c in line.strip().strip("|").split("|")]


def md_to_html(md: str) -> str:
    """Dependency-free markdown subset -> HTML: h1-h3, ul/ol, tables, bold, italic, links, code, quotes, hr."""
    md, _ = _resolve_refs(md)
    lines = (md or "").splitlines()
    out: list[str] = []
    i = 0
    para: list[str] = []
    buf: list[str] = []
    buf_tag = "ul"

    def flush_list():
        nonlocal buf
        if buf:
            out.append(f"<{buf_tag}>" + "".join(f"<li>{_inline_html(x)}</li>" for x in buf) + f"</{buf_tag}>")
            buf = []

    def flush_para():
        nonlocal para
        if para:
            out.append("<p>" + _inline_html(" ".join(para)) + "</p>")
            para = []

    while i < len(lines):
        line = lines[i].rstrip()
        stripped = line.strip()
        if not stripped:
            flush_list(); flush_para(); i += 1; continue
        if stripped.startswith("|") and i + 1 < len(lines) and _TABLE_SEP.match(lines[i + 1]) and "|" in lines[i + 1]:
            flush_list(); flush_para()
            head = _split_row(stripped)
            j, body = i + 2, []
            while j < len(lines) and lines[j].strip().startswith("|"):
                body.append(_split_row(lines[j].strip()))
                j += 1
            table = ["<table><thead><tr>"]
            table += [f"<th>{_inline_html(c)}</th>" for c in head]
            table.append("</tr></thead><tbody>")
            for r in body:
                r = r + [""] * (len(head) - len(r))
                table.append("<tr>" + "".join(f"<td>{_inline_html(c)}</td>" for c in r[: len(head)]) + "</tr>")
            table.append("</tbody></table>")
            out.append("".join(table))
            i = j
            continue
        m = re.match(r"^(#{1,3})\s+(.*)$", line)
        if m:
            flush_list(); flush_para()
            lvl = len(m.group(1))
            anchor = slugify(m.group(2), 60)
            out.append(f'<h{lvl} id="{anchor}">{_inline_html(m.group(2))}</h{lvl}>')
            i += 1
            continue
        if stripped in ("---", "***"):
            flush_list(); flush_para(); out.append("<hr>"); i += 1; continue
        if line.startswith("> "):
            flush_list()
            quote = []
            while i < len(lines) and lines[i].startswith(">"):
                quote.append(lines[i].lstrip("> ").strip())
                i += 1
            out.append(f"<blockquote>{_inline_html(' '.join(quote))}</blockquote>")
            continue
        m = _LIST_ITEM.match(line)
        if m:
            flush_para()
            if buf and buf_tag != "ul":
                flush_list()
            buf_tag, _ = "ul", buf.append(m.group(1))
            i += 1
            continue
        m = _NUM_ITEM.match(line)
        if m:
            flush_para()
            if buf and buf_tag != "ol":
                flush_list()
            buf_tag, _ = "ol", buf.append(m.group(1))
            i += 1
            continue
        flush_list()
        para.append(stripped)
        i += 1

    flush_list(); flush_para()
    return "\n".join(out)


def headings_text(md: str) -> str:
    md, _ = _resolve_refs(md)
    return md


def heading_count(md: str, level: int | None = None) -> int:
    pat = r"^(#{1,6})\s" if level is None else rf"^{'#'*level}\s"
    return len([1 for line in md.splitlines() if re.match(pat, line)])


def headings(md: str) -> list[dict]:
    res = []
    for line in md.splitlines():
        m = re.match(r"^(#{2,3})\s+(.*)$", line)
        if m:
            text = m.group(2).strip()
            res.append({"level": len(m.group(1)), "text": text, "id": slugify(text, 60)})
    return res


def fmt_pct(v, digits: int = 0) -> str:
    return "—" if v is None else f"{v * 100:.{digits}f}%"


def est_reading_time(words: int) -> int:
    return max(1, math.ceil(words / 225))
