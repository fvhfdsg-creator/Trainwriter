"""SQLite storage. One short-lived connection per call keeps the background scheduler and HTTP threads safe."""
from __future__ import annotations

import json
import os
import sqlite3
import threading
from contextlib import contextmanager

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.environ.get("TRENDWRITER_DATA", os.path.join(ROOT, "data"))
DB_PATH = os.path.join(DATA_DIR, "app.db")
PUB_DIR = os.environ.get("TRENDWRITER_PUB") or os.path.join(ROOT, "published")
_init_lock = threading.Lock()
_ready = False

SCHEMA = """
CREATE TABLE IF NOT EXISTS niches(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  seed_keywords TEXT NOT NULL DEFAULT '[]',   -- head terms that define the niche
  include_terms TEXT NOT NULL DEFAULT '[]',   -- boost / relevance vocabulary
  exclude_terms TEXT NOT NULL DEFAULT '[]',
  sources TEXT NOT NULL DEFAULT '[]',         -- [] = all enabled sources
  regions TEXT NOT NULL DEFAULT '["US"]',
  min_opportunity INTEGER NOT NULL DEFAULT 55,
  min_volume INTEGER NOT NULL DEFAULT 400,
  max_difficulty INTEGER NOT NULL DEFAULT 68,
  auto_draft INTEGER NOT NULL DEFAULT 1,
  word_target INTEGER NOT NULL DEFAULT 1100,
  cadence_min INTEGER NOT NULL DEFAULT 0,     -- 0 = inherit global cadence
  enabled INTEGER NOT NULL DEFAULT 1,
  color TEXT NOT NULL DEFAULT '#7c5cff',
  created_at TEXT, updated_at TEXT
);

CREATE TABLE IF NOT EXISTS topics(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  uid TEXT UNIQUE NOT NULL,                   -- stable hash of normalised term
  niche_id INTEGER NOT NULL,
  term TEXT NOT NULL,
  normalized TEXT NOT NULL,
  dupe_key TEXT,
  intent TEXT,                                -- informational|commercial|transactional|navigational
  volume_month INTEGER NOT NULL DEFAULT 0,    -- estimated monthly searches
  volume_daily INTEGER NOT NULL DEFAULT 0,
  difficulty INTEGER NOT NULL DEFAULT 50,
  opportunity INTEGER NOT NULL DEFAULT 0,
  velocity REAL NOT NULL DEFAULT 0,           -- relative daily growth from own history + series
  score_label TEXT,
  cpc REAL,
  sources TEXT NOT NULL DEFAULT '[]',
  signals TEXT NOT NULL DEFAULT '{}',         -- per-component numbers (transparency)
  kd_parts TEXT NOT NULL DEFAULT '{}',
  evidence TEXT NOT NULL DEFAULT '[]',        -- [{title,url,source,metric}] real citations
  series TEXT NOT NULL DEFAULT '[]',          -- daily volumes for sparkline
  status TEXT NOT NULL DEFAULT 'watching',    -- new|watching|drafted|published|dismissed|stale
  cluster_id INTEGER,
  angle TEXT,
  first_seen TEXT, last_seen TEXT, seen_count INTEGER NOT NULL DEFAULT 1,
  history TEXT NOT NULL DEFAULT '[]',         -- [{t,volume,difficulty}] from each scan
  UNIQUE(niche_id, normalized)
);

CREATE TABLE IF NOT EXISTS keywords(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  topic_id INTEGER NOT NULL,
  keyword TEXT NOT NULL,
  kind TEXT NOT NULL,                         -- primary|longtail|question|related
  volume INTEGER, difficulty INTEGER, cpc REAL, position INTEGER
);

CREATE TABLE IF NOT EXISTS drafts(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  topic_id INTEGER,
  niche_id INTEGER,
  title TEXT NOT NULL,
  slug TEXT,
  meta_description TEXT,
  focus_keyword TEXT,
  secondary_keywords TEXT NOT NULL DEFAULT '[]',
  markdown TEXT NOT NULL,
  html TEXT,
  json_ld TEXT,
  word_count INTEGER, reading_time INTEGER, readability REAL,
  keyword_density REAL, seo_score INTEGER, audit TEXT NOT NULL DEFAULT '[]',
  status TEXT NOT NULL DEFAULT 'draft',       -- draft|reviewed|scheduled|published|archived
  writer TEXT,                                -- offline|llm
  llm_model TEXT,
  file_md TEXT, file_html TEXT,
  created_at TEXT, updated_at TEXT, published_at TEXT
);

CREATE TABLE IF NOT EXISTS scans(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  started_at TEXT, finished_at TEXT, duration_s REAL,
  trigger TEXT, status TEXT,                  -- running|ok|error
  topics_found INTEGER DEFAULT 0, topics_new INTEGER DEFAULT 0, drafts_created INTEGER DEFAULT 0,
  source_health TEXT NOT NULL DEFAULT '[]',
  detail TEXT, error TEXT
);

CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  t TEXT, kind TEXT, message TEXT, data TEXT
);

CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY, v TEXT);

CREATE INDEX IF NOT EXISTS idx_topics_score ON topics(opportunity DESC);
CREATE INDEX IF NOT EXISTS idx_topics_dupe ON topics(niche_id, dupe_key);
CREATE INDEX IF NOT EXISTS idx_topics_niche ON topics(niche_id);
CREATE INDEX IF NOT EXISTS idx_kw_topic ON keywords(topic_id);
CREATE INDEX IF NOT EXISTS idx_drafts_topic ON drafts(topic_id);
"""


def connect() -> sqlite3.Connection:
    os.makedirs(DATA_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=20, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=15000")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


@contextmanager
def db():
    global _ready
    if not _ready:
        with _init_lock:
            if not _ready:
                c = connect()
                c.executescript(SCHEMA)
                c.commit()
                c.close()
                _ready = True
    conn = connect()
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def rows(sql: str, args: tuple = ()) -> list[dict]:
    with db() as c:
        return [dict(r) for r in c.execute(sql, args).fetchall()]


def one(sql: str, args: tuple = ()):
    with db() as c:
        r = c.execute(sql, args).fetchone()
        return dict(r) if r else None


def run(sql: str, args: tuple = ()):
    with db() as c:
        cur = c.execute(sql, args)
        return cur.lastrowid


def get_setting(key: str, default=None):
    r = one("SELECT v FROM kv WHERE k=?", (key,))
    if not r:
        return default
    try:
        return json.loads(r["v"])
    except json.JSONDecodeError:
        return default


def set_setting(key: str, value) -> None:
    run("INSERT INTO kv(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v", (key, json.dumps(value)))


def log_event(kind: str, message: str, data: dict | None = None) -> None:
    from .util import now_iso

    run("INSERT INTO events(t,kind,message,data) VALUES(?,?,?,?)",
        (now_iso(), kind, message, json.dumps(data or {})))
    try:  # keep the log bounded
        run("DELETE FROM events WHERE id < (SELECT MAX(id) FROM events) - 800")
    except sqlite3.Error:
        pass
