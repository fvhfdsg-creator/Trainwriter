"""The scan pipeline: sources -> candidate terms -> keyword intelligence -> metrics -> topic store
-> automatic drafts for topics that clear the niche thresholds."""
from __future__ import annotations

import os
import re
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone

from . import db, metrics, sources, util, writer
from .niches_default import DEFAULT_NICHES
from .util import human_int, normalize_term, now_iso

DEFAULT_SETTINGS = {
    "cadence_min": 30,
    "enabled": True,
    "live_sources": True,
    "sources": ["google_trends", "google_news", "hackernews", "wikipedia_top", "github"],
    "optional_sources": {"reddit": "reddit.com returns 403 to unauthenticated bots - enable only behind a proxy"},
    "regions": ["US"],
    "news_window_hours": 48,
    "max_topics_per_scan": 6,
    "stale_days": 6,
    "fallback_to_sim": True,
    "llm": {"enabled": False, "api_base": "https://api.openai.com/v1", "model": "gpt-4o-mini",
            "api_key": "", "temperature": 0.6, "max_tokens": 1800, "timeout": 90},
    "site": {"name": "TrendWriter Lab", "domain": "https://example.com", "author": "TrendWriter Editorial Desk"},
}

NOISE = set("""watch live update updates report reports says say said new after amid why what when how will does
can vs near latest breaking video photo pics here there this that with from for into over under about today
tonight tomorrow back again still yet now more most less fewer all some many much both each every no not and or
but if then than his her their our your its they them him them she you we i me us one two three first second
year years time day days week weeks month months man woman people person company companies year-old""".split())


def ensure_defaults() -> None:
    if db.one("SELECT COUNT(*) AS n FROM niches")["n"] == 0:
        for n in DEFAULT_NICHES:
            import json

            db.run(
                "INSERT INTO niches(name,slug,seed_keywords,include_terms,exclude_terms,sources,regions,"
                "min_opportunity,min_volume,max_difficulty,auto_draft,word_target,color,created_at,updated_at)"
                " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (n["name"], n["slug"], json.dumps(n["seed_keywords"]), json.dumps(n["include_terms"]),
                 json.dumps(n["exclude_terms"]), json.dumps(n.get("sources", [])), json.dumps(n.get("regions", ["US"])),
                 n.get("min_opportunity", 55), n.get("min_volume", 400), n.get("max_difficulty", 68),
                 1 if n.get("auto_draft", True) else 0, n.get("word_target", 1100),
                 n.get("color", "#7c5cff"), now_iso(), now_iso()),
            )
    if db.get_setting("settings") is None:
        db.set_setting("settings", DEFAULT_SETTINGS)


def get_settings() -> dict:
    cur = db.get_setting("settings", {}) or {}
    merged = {**DEFAULT_SETTINGS, **cur}
    merged["llm"] = {**DEFAULT_SETTINGS["llm"], **(cur.get("llm") or {})}
    merged["site"] = {**DEFAULT_SETTINGS["site"], **(cur.get("site") or {})}
    return merged


def set_settings(patch: dict) -> dict:
    cur = get_settings()
    for key, val in patch.items():
        if key in ("llm", "site") and isinstance(val, dict):
            cur[key] = {**cur[key], **val}
        elif key in cur:
            cur[key] = val
    db.set_setting("settings", cur)
    return cur


# --------------------------------------------------------------------- candidate mining
def relevance(title: str, niche: dict) -> tuple[float, list[str]]:
    nt = " " + normalize_term(title) + " "
    seed_hits = [s for s in niche["seed_list"] if s and s in nt]
    inc_hits = [w for w in set(niche["include_list"]) if len(w) > 3 and w in nt]
    exc_hits = [w for w in niche["exclude_list"] if w in nt]
    score = 1.4 * len(seed_hits) + 0.5 * len(inc_hits) - 2.2 * len(exc_hits)
    return score, (["seed:" + s for s in seed_hits[:3]] + inc_hits[:5] + (["EXCLUDE:" + e for e in exc_hits[:2]]))


def extract_phrases(title: str, niche: dict, max_phrases: int = 3) -> list[str]:
    """Salient n-grams of a headline that carry the niche vocabulary -> keyword candidates."""
    words = re.findall(r"[A-Za-z0-9''&.+-]+", title)
    out = []
    for n in (2, 3, 4, 5):
        for i in range(0, max(0, len(words) - n + 1)):
            w = words[i:i + n]
            norm = " ".join(x.lower().strip(".") for x in w)
            toks = norm.split()
            if any(t in NOISE or len(t) < 3 for t in toks):
                continue
            if n < 3 and not any(t in niche["include_set"] or t in niche["seed_set"] for t in toks):
                continue
            hits = sum(1 for t in toks if t in niche["include_set"] or t in niche["seed_set"])
            if hits == 0:
                continue
            if norm in [o for o, _ in out]:
                continue
            out.append((norm, hits * 2 + n * 0.35))
    out.sort(key=lambda p: -p[1])
    return [p for p, _ in out[:max_phrases]]


def _collect_candidates(niche: dict, pool: list[dict], settings: dict) -> dict[str, dict]:
    """Group raw items into candidate topics keyed by normalised phrase."""
    cands: dict[str, dict] = {}
    explicit = {"google_trends", "wikipedia_top", "simulated"}
    for it in pool:
        rel, why = relevance(it.get("title") or it.get("term") or "", niche)
        if rel <= 0:
            continue
        phrases = [normalize_term(it["term"])] if it["source"] in explicit else extract_phrases(it["title"], niche)
        for phrase in phrases:
            if not (2 <= len(phrase.split()) <= 7) or len(phrase) < 7:
                continue
            c = cands.setdefault(phrase, {"term": phrase, "items": [], "relevance": 0.0, "why": set(),
                                          "volume_daily": [], "sources": set(), "evidence": [], "best": 0.0,
                                          "age_min": 1e9})
            c["items"].append(it)
            c["relevance"] += rel
            c["why"].update(why)
            c["sources"].add(it["source"])
            c["best"] += float(it.get("score_raw") or 1)
            c["age_min"] = min(c["age_min"], float(it.get("age_hours") or 48))
            if it.get("volume_daily_hint"):
                c["volume_daily"].append(("google_trends" if it["source"] == "google_trends" else "search_hint",
                                          int(it["volume_daily_hint"]),
                                          1.0 if it["source"] == "google_trends" else 0.6))
            if it.get("views_daily"):
                c["volume_daily"].append(("wikipedia_views", int(it["views_daily"]), 0.7))
            if len(c["evidence"]) < 6:
                c["evidence"].append(it["evidence"])
    for c in cands.values():
        c["why"] = sorted(c["why"])
        c["sources"] = sorted(c["sources"])
        seen, ev = set(), []
        for e in c["evidence"]:
            if e["title"] not in seen:
                seen.add(e["title"])
                ev.append(e)
        c["evidence"] = ev
    return cands


def enrich_keyword(term: str, region: str = "US", live: bool = True) -> dict:
    """Live query-space pull for one term: autocomplete + Wikipedia + DuckDuckGo."""
    info: dict = {"suggestions": [], "wiki": {}, "ddg": {}, "series": {}}
    if not live:
        return info
    info["suggestions"] = sources.google_suggest(term, gl=region.lower(), extra=("how", "why", "best"))
    try:
        info["wiki"] = sources.wikipedia_search(term, limit=5)
    except Exception:
        pass
    try:
        info["ddg"] = sources.duckduckgo_instant(term)
    except Exception:
        pass
    exact = (info["wiki"].get("results") or [{}])[0].get("title", "") if info["wiki"].get("results") else ""
    if exact and (normalize_term(exact) in normalize_term(term) or normalize_term(term) in normalize_term(exact)):
        try:
            info["series"] = sources.wikipedia_article_series(exact, days=21) or {}
        except Exception:
            pass
    return info


# --------------------------------------------------------------------- scoring + store
def _score_candidate(niche: dict, cand: dict, info: dict, settings: dict) -> dict:
    term = cand["term"]
    items = cand["items"]
    sug = info.get("suggestions") or []
    sug_own = [s for s in sug if normalize_term(term) in normalize_term(s)]
    questions = [s for s in sug_own if re.match(r"^(how|why|what|when|where|who|is|can|do|does|should)", s.lower())]
    cover = len(items)
    ages = sorted(float(i.get("age_hours") or 48) for i in items)
    median_age = ages[len(ages) // 2] if ages else 48.0
    newest = min(ages) if ages else 48.0
    auth_domains = (info.get("ddg") or {}).get("domains") or []
    authority_share = (sum(1 for d in auth_domains if any(k in d for k in metrics.AUTHORITY_DOMAINS)) / len(auth_domains)) \
        if auth_domains else (0.45 if (info.get("wiki") or {}).get("has_exact_article") else 0.2)
    comp_words = sum(int(r.get("wordcount") or 900) for r in (info.get("wiki") or {}).get("results", [])[:5]) / \
        max(1, len((info.get("wiki") or {}).get("results", [])[:5]))

    series = (info.get("series") or {}).get("series") or []
    if series and not cand["volume_daily"]:
        avg_daily = (info["series"].get("avg_daily") or 0)
        cand["volume_daily"] = [("wikipedia_series", int(avg_daily), 0.9)]
    intent_pre = metrics.classify_intent(term)[0]
    vol = metrics.estimate_volume(cand["volume_daily"], len(sug_own), cover, cand["age_min"])
    if intent_pre == "news":
        # a Google Trends spike is a one-day peak, not a monthly average
        vol["volume_month"] = max(30, int(vol["volume_month"] * 0.3))
        vol["spike_decay"] = 0.3
    kd = metrics.keyword_difficulty(
        term=term, volume=vol["volume_month"], intent=metrics.classify_intent(term)[0],
        suggest_count=len(sug_own), question_suggests=len(questions),
        longtail_share=len(questions) / max(1, len(sug_own)), authority_share=authority_share,
        coverage_items=cover, median_age_h=median_age,
        exact_article=bool((info.get("wiki") or {}).get("has_exact_article")), competitor_words=comp_words)
    hist_last = db.rows("SELECT history FROM topics WHERE niche_id=? AND normalized=?", (niche["id"], term))
    history = []
    if hist_last:
        try:
            history = list(reversed([__import__("json").loads(r["history"]) for r in hist_last])[0])
        except Exception:
            history = []
    vel = metrics.velocity(series, history + [{"volume": vol["volume_month"]}], cand["age_min"])
    opp = metrics.opportunity(volume=vol["volume_month"], difficulty=kd["difficulty"], velocity_v=vel["velocity"],
                              intent=metrics.classify_intent(term)[0], coverage_items=cover,
                              suggest_count=len(sug_own), corroboration=len(cand["sources"]))
    freshness_bonus = 6 if newest < 30 else 0
    opp["opportunity"] = int(util.clamp(opp["opportunity"] + freshness_bonus, 0, 99))
    return {"term": term, "volume": vol, "kd": kd, "vel": vel, "opp": opp, "cover": cover,
            "suggestions": sug, "sug_own": sug_own, "questions": questions, "newest": newest,
            "median_age": median_age, "authority_share": authority_share, "series": series,
            "info": info, "history": history}


def subkeyword_metrics(base_term: str, kw_norm: str, base_volume: int, base_diff: int, niche_slug: str) -> dict:
    """Per-long-tail volume/difficulty/cpc, derived from the head term's measured numbers."""
    gap = max(0, len(kw_norm.split()) - len(base_term.split()))
    jitter = 0.72 + (abs(hash(kw_norm)) % 55) / 100.0
    volume = max(10, int(base_volume * max(0.035, 0.34 ** gap) * jitter))
    difficulty = int(util.clamp(base_diff - min(26, gap * 7), 4, 96))
    kind = "question" if re.match(r"^(how|why|what|when|where|who|can|is|do|does|should)", kw_norm) else "longtail"
    intent = metrics.classify_intent(kw_norm)[0]
    return {"volume": volume, "difficulty": difficulty, "kind": kind, "intent": intent,
            "cpc": metrics.cpc_estimate(niche_slug, intent, volume)}


def _keyword_rows(topic_id: int, term: str, scored: dict) -> None:
    db.run("DELETE FROM keywords WHERE topic_id=?", (topic_id,))
    v, d = scored["volume"]["volume_month"], scored["kd"]["difficulty"]
    db.run("INSERT INTO keywords(topic_id,keyword,kind,volume,difficulty,cpc,position) VALUES(?,?,?,?,?,?,?)",
           (topic_id, term, "primary", v, d, scored["cpc"], 0))
    seen = {normalize_term(term)}
    idx = 1
    for s in scored["suggestions"][:26]:
        n = normalize_term(s)
        if n in seen or abs(len(n) - len(term)) > 34:
            continue
        seen.add(n)
        sub = subkeyword_metrics(term, n, v, d, scored["niche_slug"])
        db.run("INSERT INTO keywords(topic_id,keyword,kind,volume,difficulty,cpc,position) VALUES(?,?,?,?,?,?,?)",
               (topic_id, s, sub["kind"], sub["volume"], sub["difficulty"], sub["cpc"], idx))
        idx += 1


def upsert_topic(niche: dict, cand: dict, scored: dict, scan_id: int) -> int | None:
    import json

    term, v = cand["term"], scored["volume"]
    dupe = " ".join(sorted(term.split()))
    existing = db.one("SELECT * FROM topics WHERE niche_id=? AND (dupe_key=? OR normalized=?)",
                      (niche["id"], dupe, term))
    history = list((json.loads(existing["history"]) if existing else []))
    history.append({"t": now_iso(), "volume": v["volume_month"], "difficulty": scored["kd"]["difficulty"],
                    "opportunity": scored["opp"]["opportunity"]})
    history = history[-30:]
    intent, why = metrics.classify_intent(term, " ".join(i.get("title", "") for i in cand["items"][:3]))
    signals = {"suggest_count": len(scored["sug_own"]), "suggest_total": len(scored["suggestions"]),
               "question_suggests": len(scored["questions"]), "coverage_items": scored["cover"],
               "newest_h": scored["newest"], "median_age_h": scored["median_age"],
               "authority_share": round(scored["authority_share"], 3), "corroborating_sources": cand["sources"],
               "relevance": round(cand["relevance"], 2), "why_matched": cand["why"][:6],
               "wiki_exact": bool(scored["info"]["wiki"].get("has_exact_article")),
               "ddg_answer": bool(scored["info"]["ddg"].get("has_answer")),
               "wiki_total_hits": scored["info"]["wiki"].get("total_hits"),
               "volume_formula": v["formula"], "volume_parts": v["components"],
               "query_family": v["query_family_multiplier"], "coverage_boost": v["coverage_boost"],
               "kd_tier": scored["kd"]["tier"], "intent_label": scored["opp"]["intent_label"],
               "opportunity_parts": scored["opp"]["opportunity_parts"]}
    common = dict(term=term.capitalize() if len(term) < 4 else term, normalized=term, dupe_key=dupe, intent=intent,
                  volume_month=v["volume_month"], volume_daily=v["volume_daily"],
                  difficulty=scored["kd"]["difficulty"], opportunity=scored["opp"]["opportunity"],
                  velocity=scored["vel"]["velocity"], score_label=scored["opp"]["opportunity_label"],
                  cpc=scored["cpc"], sources=json.dumps(cand["sources"]),
                  signals=json.dumps(signals),
                  kd_parts=json.dumps({**scored["kd"]["kd_parts"], "tier": scored["kd"]["tier"],
                                       "explain": scored["kd"]["explain"]}),
                  evidence=json.dumps(cand["evidence"]), series=json.dumps(scored["series"][-21:]),
                  last_seen=now_iso(), history=json.dumps(history), seen_count=(existing["seen_count"] + 1) if existing else 1)
    if existing:
        sets = ",".join(f"{k}=?" for k in common)
        db.run(f"UPDATE topics SET {sets} WHERE id=?", (*common.values(), existing["id"]))
        _keyword_rows(existing["id"], term, scored)
        return None
    cols = ["uid", "niche_id", "status", "first_seen", *common.keys()]
    vals = [util.slugify(term, 40)[:34] + "-" + str(abs(hash(term)) % 9973), niche["id"], "new", now_iso(),
            *common.values()]
    db.run(f"INSERT INTO topics({','.join(cols)}) VALUES({','.join('?' * len(cols))})", tuple(vals))
    topic_id = db.one("SELECT id FROM topics WHERE niche_id=? AND (dupe_key=? OR normalized=?)",
                      (niche["id"], dupe, term))["id"]
    scored["cpc"] = metrics.cpc_estimate(niche["slug"], intent, v["volume_month"])
    _keyword_rows(topic_id, term, scored)
    return topic_id


def _collapse_health(health: list[dict]) -> list[dict]:
    """One row per source family, with the aggregate item count - keeps the status panel readable."""
    agg: dict[str, dict] = {}
    for h in health:
        family = h["source"].split(":")[0].split(" (")[0]
        a = agg.setdefault(family, {"source": family, "ok": False, "count": 0, "ms": 0, "checks": 0, "error": None})
        a["count"] += h.get("count") or 0
        a["ms"] += h.get("ms") or 0
        a["checks"] += 1
        if h.get("ok"):
            a["ok"] = True
        elif not a["error"]:
            a["error"] = h.get("error")
    out = []
    for a in agg.values():
        a["ms"] = a["ms"] // max(1, a["checks"])
        a["items"] = a["count"]
        a["calls"] = a.pop("checks")
        if a["count"] == 0 and a["ok"]:
            a["ok"], a["error"] = False, "reachable but nothing matched the niches"
        out.append(a)
    return sorted(out, key=lambda x: (not x["ok"], x["source"]))


def cluster_topics(niche_id: int) -> None:
    """Group topics sharing a head term into clusters so the writer can cross-link them."""
    import json

    topics = db.rows("SELECT id, normalized FROM topics WHERE niche_id=? AND status!='stale' ORDER BY opportunity DESC",
                     (niche_id,))
    assigned = {}
    for t in topics:
        if t["id"] in assigned:
            continue
        toks = util.tokens(t["normalized"])
        group = [t["id"]]
        for o in topics:
            if o["id"] in assigned or o["id"] == t["id"]:
                continue
            ot = util.tokens(o["normalized"])
            inter = len(toks & ot)
            if inter and inter / max(1, min(len(toks), len(ot))) >= 0.6:
                group.append(o["id"])
        for gid in group:
            assigned[gid] = t["id"]
    for tid, cid in assigned.items():
        db.run("UPDATE topics SET cluster_id=? WHERE id=?", (cid, tid))


# --------------------------------------------------------------------- drafting
def related_published(niche_id: int, exclude_topic: int | None, limit: int = 3) -> list[dict]:
    """Already-live posts in the same niche - used for real internal links inside new drafts."""
    rows = db.rows("SELECT d.id, d.title, d.niche_id, n.name AS niche FROM drafts d "
                   "LEFT JOIN niches n ON n.id=d.niche_id WHERE d.niche_id=? AND d.status IN ('published','reviewed') "
                   "ORDER BY d.updated_at DESC LIMIT 12", (niche_id,))
    keep = [r for r in rows if r["id"] not in _draft_ids_of(exclude_topic)]
    return keep[:limit]


def _draft_ids_of(topic_id: int | None) -> set[int]:
    if not topic_id:
        return set()
    return {r["id"] for r in db.rows("SELECT id FROM drafts WHERE topic_id=?", (topic_id,))}


def create_draft(topic_id: int, settings: dict | None = None, trigger: str = "auto") -> dict | None:
    import json

    settings = settings or get_settings()
    topic = db.one("SELECT * FROM topics WHERE id=?", (topic_id,))
    if not topic:
        return None
    niche = db.one("SELECT * FROM niches WHERE id=?", (topic["niche_id"],))
    if not niche:
        return None
    niche = _hydrate_niche(niche)
    for j in ("signals", "kd_parts", "evidence", "series"):
        topic[j] = json.loads(topic[j] or "{}") if j != "evidence" else json.loads(topic[j] or "[]")
    topic["sources"] = json.loads(topic["sources"] or "[]")
    keywords = db.rows("SELECT * FROM keywords WHERE topic_id=? ORDER BY position", (topic_id,))
    kw = [{"keyword": k["keyword"], "kind": k["kind"], "volume": k["volume"], "difficulty": k["difficulty"],
           "cpc": k["cpc"], "intent_label": metrics.opportunity(
               volume=k["volume"] or 1, difficulty=k["difficulty"] or 50, velocity_v=0,
               intent=intent_of(k["keyword"]), coverage_items=0, suggest_count=0,
               corroboration=0)["intent_label"]} for k in keywords]
    brief = writer.build_brief(topic, niche, kw, topic["evidence"],
                              related_published(niche["id"], topic_id))
    llm = settings.get("llm") or {}
    md, meta, writer_kind, err = None, None, "offline", None
    if llm.get("enabled") and llm.get("api_key"):
        out = writer.compose_llm(brief, llm)
        if out:
            md, meta, writer_kind = out[0], out[1], "llm"
    if md is None:
        md, meta = writer.compose_offline(brief)
    seo_score, checks, stats = writer.audit(md, meta["title"], meta["meta_description"], topic["term"])
    slug = util.slugify(meta["title"], 68)
    if db.one("SELECT id FROM drafts WHERE slug=?", (slug,)):
        slug = f"{slug}-{datetime.now(timezone.utc).strftime('%m%d%H%M')}"
    ld = writer.json_ld(meta["title"], slug, meta["meta_description"], meta["faq"], niche["name"],
                        topic["first_seen"] or now_iso(),
                        [k["keyword"] for k in kw[:8]], f"{meta['title']} - trend data chart")
    site = settings.get("site") or {}
    html_doc = writer.render_html(md, {**meta, "slug": slug, "niche": niche["name"],
                                      "date": topic["first_seen"] or now_iso(),
                                      "json_ld": ld, "keywords": [k["keyword"] for k in kw[:8]]}, niche["color"])
    draft_id = db.run(
        "INSERT INTO drafts(topic_id,niche_id,title,slug,meta_description,focus_keyword,secondary_keywords,markdown,"
        "html,json_ld,word_count,reading_time,readability,keyword_density,seo_score,audit,status,writer,llm_model,"
        "created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (topic_id, niche["id"], meta["title"], slug, meta["meta_description"], topic["term"],
         json.dumps([k["keyword"] for k in kw[:10]]), md, html_doc, json.dumps(ld), stats["word_count"],
         stats["reading_time"], stats["readability"], stats["keyword_density"], seo_score, json.dumps(checks),
         "draft", writer_kind, llm.get("model") if writer_kind == "llm" else None, now_iso(), now_iso()))
    db.run("UPDATE topics SET status='drafted' WHERE id=?", (topic_id,))
    db.log_event("draft", f"Drafted '{topic['term']}' ({seo_score}/100 SEO)", {"draft_id": draft_id, "trigger": trigger})
    return db.one("SELECT * FROM drafts WHERE id=?", (draft_id,))


def intent_of(kw: str) -> str:
    return metrics.classify_intent(kw)[0]


def _hydrate_niche(row: dict) -> dict:
    import json

    n = dict(row)
    for k in ("seed_keywords", "include_terms", "exclude_terms", "sources", "regions"):
        n[k] = json.loads(n.get(k) or "[]")
    n["seed_list"] = [normalize_term(s) for s in n["seed_keywords"]]
    n["include_list"] = [w for w in n["include_terms"]]
    n["seed_set"] = set()
    for s in n["seed_list"]:
        n["seed_set"].update(s.split())
    n["include_set"] = set(n["include_list"]) | n["seed_set"]
    n["exclude_list"] = [w for w in n["exclude_terms"]]
    return n


# --------------------------------------------------------------------- scan
def run_scan(trigger: str = "manual", niche_filter: list[int] | None = None) -> dict:
    import json

    started = datetime.now(timezone.utc)
    settings = get_settings()
    scan_id = db.run("INSERT INTO scans(started_at,trigger,status) VALUES(?,?,?)", (now_iso(), trigger, "running"))
    health: list[dict] = []
    found = new = drafted = 0
    error = None
    try:
        niches = db.rows("SELECT * FROM niches WHERE enabled=1" + (" AND id IN (%s)" % ",".join("?" * len(niche_filter))
                                                                    if niche_filter else ""), tuple(niche_filter or []))
        enabled_sources = set(settings["sources"])
        pool: dict[str, list[dict]] = defaultdict(list)

        if settings["live_sources"]:
            for region in settings["regions"][:3]:
                for fn, name, args in (
                    (sources.google_trends_rss, "google_trends", (region,)),
                    (sources.wikipedia_top_views, "wikipedia_top", ("en",)),
                ):
                    if name not in enabled_sources:
                        continue
                    rec = sources.guarded(f"{name}:{region}", fn, *args)
                    pool[name] += rec.pop("_items")
                    health.append(rec)
            if "hackernews" in enabled_sources:
                rec = sources.guarded("hackernews", sources.hackernews, None, settings["news_window_hours"], 10, 40)
                pool["hackernews"] += rec.pop("_items")
                health.append(rec)
            if "github" in enabled_sources:
                rec = sources.guarded("github", sources.github_search, "ai agents", 30, 12)
                pool["github"] += rec.pop("_items")
                health.append(rec)
            for n in niches:
                niche = _hydrate_niche(n)
                for seed in niche["seed_keywords"][: settings["max_topics_per_scan"]]:
                    if "google_news" in enabled_sources:
                        for region in settings["regions"][:2]:
                            rec = sources.guarded(f"google_news:{niche['slug']}", sources.google_news_rss, seed, region, 16)
                            pool["google_news"] += rec.pop("_items")
                            rec["source"] = f"google_news ({seed[:18]})"
                            health.append(rec)
                    if "reddit" in enabled_sources:
                        rec = sources.guarded(f"reddit:{niche['slug']}", sources.reddit_hot, niche["slug"], 12)
                        pool["reddit"] += rec.pop("_items")
                        rec["source"] = f"reddit r/{niche['slug']}"
                        health.append(rec)

        # score every candidate term per niche, in parallel where network is used
        tasks = []
        for n in niches:
            niche = _hydrate_niche(n)
            items = [it for srcs in pool.values() for it in srcs]
            if settings["fallback_to_sim"] and not items:
                items = sources.simulate(niche["slug"], 10)
                health.append({"source": f"simulated ({niche['slug']})", "ok": True, "items": len(items),
                               "count": len(items), "ms": 0, "error": "live sources unavailable - simulated fallback"})
            cands = _collect_candidates(niche, items, settings)
            ranked = sorted(cands.values(), key=lambda c: -(c["relevance"] + 0.6 * (c["best"] ** 0.35)))
            picked = ranked[: settings["max_topics_per_scan"]]
            found += len(picked)
            for c in picked:
                tasks.append((niche, c))

        with ThreadPoolExecutor(max_workers=5) as ex:
            infos = list(ex.map(lambda t: enrich_keyword(t[1]["term"], settings["regions"][0],
                                                        live=bool(settings.get("live_sources"))), tasks))

        for (niche, cand), info in zip(tasks, infos):
            scored = _score_candidate(niche, cand, info, settings)
            scored["niche_slug"] = niche["slug"]
            scored["cpc"] = metrics.cpc_estimate(niche["slug"], intent_of(cand["term"]), scored["volume"]["volume_month"])
            tid = upsert_topic(niche, cand, scored, scan_id)
            if tid:
                new += 1
                if niche["auto_draft"] and _passes(niche, scored):
                    if create_draft(tid, settings, trigger="auto"):
                        drafted += 1
                elif niche["auto_draft"]:
                    db.log_event("watch", f"Watching '{cand['term']}' - below threshold",
                                 {"opportunity": scored["opp"]["opportunity"], "niche": niche["slug"]})

        for n in niches:
            cluster_topics(n["id"])
        cutoff = (datetime.now(timezone.utc) - timedelta(days=settings["stale_days"])).isoformat()
        db.run("UPDATE topics SET status='stale' WHERE status IN ('new','watching') AND last_seen < ?", (cutoff,))
    except Exception as exc:  # noqa: BLE001
        import traceback

        error = f"{type(exc).__name__}: {exc}"
        db.log_event("error", f"Scan failed: {error}", {"trace": traceback.format_exc()[-900:]})
    finally:
        dur = (datetime.now(timezone.utc) - started).total_seconds()
        health = _collapse_health(health)
        db.run("UPDATE scans SET finished_at=?, duration_s=?, status=?, topics_found=?, topics_new=?,"
               " drafts_created=?, source_health=?, detail=?, error=? WHERE id=?",
               (now_iso(), round(dur, 1), "error" if error else "ok", found, new, drafted,
                json.dumps(health, default=str)[:16000], f"{found} candidates, {new} new topics, {drafted} drafts",
                error, scan_id))
    return db.one("SELECT * FROM scans WHERE id=?", (scan_id,))


def _passes(niche: dict, scored: dict) -> bool:
    v = scored["volume"]["volume_month"]
    return (scored["opp"]["opportunity"] >= niche["min_opportunity"] and v >= niche["min_volume"]
            and scored["kd"]["difficulty"] <= niche["max_difficulty"])


# --------------------------------------------------------------------- publishing
def publish_draft(draft_id: int) -> dict:
    import json

    d = db.one("SELECT * FROM drafts WHERE id=?", (draft_id,))
    if not d:
        return {}
    out_dir = db.PUB_DIR
    os.makedirs(out_dir, exist_ok=True)
    md_path = os.path.join(out_dir, f"{d['slug']}.md")
    html_path = os.path.join(out_dir, f"{d['slug']}.html")
    json_path = os.path.join(out_dir, f"{d['slug']}.json")
    niche_row = db.one("SELECT name FROM niches WHERE id=?", (d["niche_id"],)) or {"name": ""}
    front = "\n".join([
        "---", f"title: {json.dumps(d['title'])}", f"slug: {d['slug']}",
        f"date: {d['published_at'] or now_iso()[:10]}", f"description: {json.dumps(d['meta_description'])}",
        f"keywords: {json.dumps(json.loads(d['secondary_keywords'] or '[]')[:6])}",
        f"focus_keyword: {d['focus_keyword']}", "niche: " + json.dumps(niche_row["name"]),
        f"seo_score: {d['seo_score']}", "status: published", "---", ""])
    with open(md_path, "w", encoding="utf-8") as fh:
        fh.write(front + "\n" + d["markdown"] + "\n")
    with open(html_path, "w", encoding="utf-8") as fh:
        fh.write(d["html"] or "")
    with open(json_path, "w", encoding="utf-8") as fh:
        json.dump({"id": d["id"], "title": d["title"], "slug": d["slug"], "meta_description": d["meta_description"],
                   "focus_keyword": d["focus_keyword"], "json_ld": json.loads(d["json_ld"] or "{}"),
                   "audit": json.loads(d["audit"] or "[]"), "markdown": d["markdown"]}, fh, indent=1)
    db.run("UPDATE drafts SET status='published', published_at=?, updated_at=?, file_md=?, file_html=? WHERE id=?",
           (now_iso(), now_iso(), md_path, html_path, draft_id))
    if d["topic_id"]:
        db.run("UPDATE topics SET status='published' WHERE id=?", (d["topic_id"],))
    db.log_event("publish", f"Published {d['slug']} to published/", {"draft_id": d["id"]})
    return db.one("SELECT * FROM drafts WHERE id=?", (draft_id,))


# --------------------------------------------------------------------- ad-hoc keyword intel
def _probe_coverage(term: str, settings: dict, region: str = "US") -> list[dict]:
    """Live coverage for an arbitrary keyword (news + HN + wiki) so on-demand lookups use real data."""
    items: list[dict] = []
    if not settings.get("live_sources"):
        return items
    for fn, args in ((sources.google_news_rss, (term, region, 10)),
                     (sources.hackernews, (term, 24 * 30, 5, 10)),
                     (sources.wikipedia_top_views, ("en", 1, 40))):
        try:
            items += fn(*args)
        except Exception:  # noqa: BLE001
            continue
    nt = normalize_term(term)
    toks = util.tokens(term)
    return [i for i in items if nt in normalize_term(i.get("title", "")) or (toks and len(toks & util.tokens(i.get("title", ""))) >= max(1, len(toks) - 1))][:12]


def analyze_keyword(term: str, niche_row: dict | None) -> dict:
    import json

    settings = get_settings()
    niche = _hydrate_niche(niche_row or db.one("SELECT * FROM niches ORDER BY id LIMIT 1") or {})
    term_n = normalize_term(term)
    region = (niche.get("regions") or settings["regions"])[0]
    info = enrich_keyword(term_n, region, live=bool(settings.get("live_sources")))
    items = _probe_coverage(term_n, settings, region)
    cand = {"term": term_n, "items": items, "relevance": 3.0, "why": ["manual lookup"], "volume_daily": [],
            "sources": sorted({i["source"] for i in items} | ({"google_suggest"} if info["suggestions"] else set())),
            "evidence": [i["evidence"] for i in items[:6]], "best": 0.0, "age_min": min([float(i.get("age_hours") or 48) for i in items], default=48.0)}
    for i in items:
        if i.get("volume_daily_hint"):
            cand["volume_daily"].append(("google_trends", int(i["volume_daily_hint"]), 1.0))
        if i.get("views_daily"):
            cand["volume_daily"].append(("wikipedia_views", int(i["views_daily"]), 0.7))
    scored = _score_candidate(niche, cand, info, settings)
    scored["niche_slug"] = niche.get("slug", "generic")
    scored["cpc"] = metrics.cpc_estimate(niche.get("slug", ""), intent_of(term_n), scored["volume"]["volume_month"])
    kws = []
    seen = {term_n}
    for s in (scored["suggestions"] or [])[:22]:
        n = normalize_term(s)
        if n in seen or not n:
            continue
        seen.add(n)
        sub = subkeyword_metrics(term_n, n, scored["volume"]["volume_month"], scored["kd"]["difficulty"],
                                 niche.get("slug", ""))
        kws.append({"keyword": s, **{k: sub[k] for k in ("kind", "volume", "difficulty", "cpc", "intent")}})
    opp, vol, kd, vel = scored["opp"], scored["volume"], scored["kd"], scored["vel"]
    return {"term": term, "normalized": term_n, "niche": {"id": niche.get("id"), "name": niche.get("name"),
            "slug": niche.get("slug")}, "live": bool(settings.get("live_sources")),
            "volume_month": vol["volume_month"], "volume_daily": vol["volume_daily"],
            "volume_components": vol["components"], "query_family_multiplier": vol["query_family_multiplier"],
            "coverage_boost": vol["coverage_boost"], "volume_formula": vol["formula"],
            "difficulty": kd["difficulty"], "kd_tier": kd["tier"], "kd_parts": kd["kd_parts"], "explain": kd["explain"],
            "opportunity": opp["opportunity"], "label": opp["opportunity_label"], "opportunity_parts": opp["opportunity_parts"],
            "intent": metrics.classify_intent(term_n)[0], "intent_label": opp["intent_label"],
            "velocity": vel["velocity"], "velocity_label": vel["velocity_label"],
            "longtails": [{"kw": k["keyword"], "kind": k["kind"], "volume": k["volume"], "difficulty": k["difficulty"],
                           "cpc": k["cpc"], "position": i + 1} for i, k in enumerate(kws)],
            "keywords": kws, "suggestions": scored["suggestions"], "questions": scored["questions"],
            "evidence": cand["evidence"], "coverage_items": scored["cover"], "coverage_count": scored["cover"],
            "cpc": scored["cpc"], "sources": cand["sources"],
            "signals": {"suggest_count": len(scored["sug_own"]), "coverage_items": scored["cover"],
                        "authority_share": round(scored["authority_share"], 3),
                        "newest_h": scored["newest"], "median_age_h": scored["median_age"],
                        "wiki_exact": bool(scored["info"]["wiki"].get("has_exact_article")),
                        "wiki_total_hits": scored["info"]["wiki"].get("total_hits"),
                        "ddg_abstract": (scored["info"]["ddg"].get("abstract") or "")[:400],
                        "volume_formula": scored["volume"]["formula"]},
            "series": scored["series"], "wiki": scored["info"]["wiki"], "ddg": scored["info"]["ddg"],
            "topic_id": (db.one("SELECT id FROM topics WHERE niche_id=? AND normalized=?",
                               (niche.get("id"), term_n)) or {}).get("id"),
            "scanned_at": now_iso()}


def store_keyword_topic(term: str, niche_row: dict | None) -> int:
    """Turn an ad-hoc lookup into a tracked topic so the queue and charts include it."""
    import json

    settings = get_settings()
    niche = _hydrate_niche(niche_row or db.one("SELECT * FROM niches ORDER BY id LIMIT 1"))
    term_n = normalize_term(term)
    dupe = " ".join(sorted(term_n.split()))
    existing = db.one("SELECT id FROM topics WHERE niche_id=? AND (dupe_key=? OR normalized=?)", (niche["id"], dupe, term_n))
    if existing:
        return existing["id"]
    region = (niche.get("regions") or settings["regions"])[0]
    info = enrich_keyword(term_n, region, live=bool(settings.get("live_sources")))
    items = _probe_coverage(term_n, settings, region)
    cand = {"term": term_n, "items": items, "relevance": 3.0, "why": ["manual keyword"], "volume_daily": [],
            "sources": sorted({i["source"] for i in items} or ["manual"]), "evidence": [i["evidence"] for i in items[:6]],
            "best": 0.0, "age_min": min([float(i.get("age_hours") or 48) for i in items], default=48.0)}
    for i in items:
        if i.get("volume_daily_hint"):
            cand["volume_daily"].append(("google_trends", int(i["volume_daily_hint"]), 1.0))
        if i.get("views_daily"):
            cand["volume_daily"].append(("wikipedia_views", int(i["views_daily"]), 0.7))
    scored = _score_candidate(niche, cand, info, settings)
    scored["niche_slug"] = niche["slug"]
    scored["cpc"] = metrics.cpc_estimate(niche["slug"], intent_of(term_n), scored["volume"]["volume_month"])
    tid = upsert_topic(niche, cand, scored, db.run("INSERT INTO scans(started_at,trigger,status,detail) VALUES(?,?,?,?)",
                                                    (now_iso(), "keyword", "ok", f"manual keyword {term_n}")) or 0)
    return tid or db.one("SELECT id FROM topics WHERE niche_id=? AND (dupe_key=? OR normalized=?)",
                         (niche["id"], dupe, term_n))["id"]


# --------------------------------------------------------------------- scheduler
class Scheduler:
    """Background loop: scans on the configured cadence, reacts to Settings changes live."""

    def __init__(self):
        import threading

        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self.next_run: float | None = None

    def start(self):
        import threading

        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True, name="scan-scheduler")
        self._thread.start()

    def stop(self):
        self._stop.set()

    def trigger_now(self):
        self.next_run = 0.0

    @property
    def running(self) -> bool:
        return bool(self._thread and self._thread.is_alive() and not self._stop.is_set())

    def _loop(self):
        import time

        ensure_defaults()
        self.next_run = 0.0  # first scan shortly after boot
        while not self._stop.is_set():
            st = get_settings()
            cadence = max(5, int(st.get("cadence_min") or 30)) * 60
            if st.get("enabled"):
                if self.next_run is None or time.time() >= self.next_run:
                    try:
                        run_scan(trigger="scheduler")
                    except Exception as exc:  # noqa: BLE001
                        db.log_event("error", f"scheduler: {type(exc).__name__}: {exc}")
                    finally:
                        self.next_run = time.time() + cadence
            else:
                self.next_run = None
            self._stop.wait(10)


scheduler = Scheduler()
