/* Headless render smoke-test for web/app.js.
   Stubs just enough DOM + fetch, then exercises every view's render path against
   live API payloads snapshotted by tools/dump_fixtures.py. Catches undefined refs, null property access
   and template errors that a syntax check cannot see. */
const fs = require('fs');
const path = require('path');

const FIXTURES = {
  '/api/state': 'state.json',
  '/api/topics?sort=opportunity&limit=120': 'topics.json',
  '/api/topics/1': 'topic1.json',
  '/api/drafts': 'drafts.json',
  '/api/drafts?limit=300': 'drafts.json',
  '/api/drafts/1': 'draft1.json',
  '/api/settings': 'settings.json',
  '/api/niches': 'niches.json',
  '/api/logs?limit=18': 'logs.json',
  '/api/scans?limit=1': 'scans.json',
  '/api/search?keyword=ai+agents': 'search.json', '/api/drafts/1/deleted': 'draft1.json',
};

let errors = [];
let fetches = [];
const htmlStore = {};

function el(id) {
  const node = {
    id, _html: '', textContent: '', value: '', rows: 2, type: 'text', checked: false, className: '',
    dataset: {}, style: {}, classList: { add() { }, remove() { }, toggle() { }, contains() { return false; } },
    insertAdjacentHTML(pos, h) { this._html += h; },
    addEventListener() { }, appendChild() { }, click() { }, focus() { }, remove() { },
    closest() { return null; }, querySelector() { return null; }, querySelectorAll() { return []; },
    get innerHTML() { return this._html; },
    set innerHTML(v) { this._html = v; },
  };
  Object.defineProperty(node, 'innerHTML', { get() { return this._html; }, set(v) { this._html = v; }, configurable: true });
  return node;
}
const nodes = new Map();
const get = (sel) => {
  const key = String(sel).replace(/^#/, '');
  if (!nodes.has(key)) nodes.set(key, el(key));
  return nodes.get(key);
};

global.document = {
  hidden: false,
  addEventListener() { },
  createElement: () => ({ style: {}, click() { }, set href(v) { }, set download(v) { } }),
  querySelector: (s) => (typeof s === 'string' && s.startsWith('#') ? get(s) : null),
  querySelectorAll: () => [],
  body: el('body'),
};
global.window = global;
global.confirm = () => true;
global.prompt = () => null;
global.alert = () => { };
global.fetch = async (url, opts) => {
  fetches.push((opts && opts.method ? opts.method + ' ' : 'GET ') + url);
  const clean = String(url).replace(/^https?:\/\/[^/]+/, '').replace(/%20/g, '+').replace(/\+/g, '+');
  const file = FIXTURES[clean] || FIXTURES[clean.split('?')[0]] || FIXTURES[clean.replace(/\/\d+$/, '/1')];
  if (file && fs.existsSync(path.join(__dirname, 'fixtures', file))) {
    const body = fs.readFileSync(path.join(__dirname, 'fixtures', file), 'utf8');
    return { ok: true, status: 200, text: async () => body, json: async () => JSON.parse(body) };
  }
  if (opts && opts.method && opts.method !== 'GET') {
    return { ok: true, status: 200, text: async () => '{}', json: async () => ({}) };
  }
  return { ok: false, status: 404, statusText: 'not stubbed', text: async () => JSON.stringify({ error: 'no fixture: ' + clean }), json: async () => ({ error: 'no fixture: ' + clean }) };
};
global.Blob = class { constructor() { } };
global.URL = { createObjectURL: () => 'blob:x' };
global.setInterval = () => 0;
const realTimeout = setTimeout;
global.setTimeout = (fn, ms) => realTimeout(fn, 0);
global.clearTimeout = () => { };

const src = fs.readFileSync(path.join(__dirname, '..', 'web', 'app.js'), 'utf8')
  .replace(/\nboot\(\);[\s\S]*$/, '\nmodule.exports = { boot, refresh, go, loadTopics, openTopic, loadDrafts, renderDraft, runIntel, scanNow, renderMonitorForm, renderWriterForm, renderNicheEditor, renderScatter, renderKPIs, sparkline, state: () => state };\n');
const tmp = path.join('/tmp', 'ui-harness-app.js');
fs.writeFileSync(tmp, src);

process.on('unhandledRejection', (e) => errors.push('unhandledRejection: ' + (e && e.stack || e)));
process.on('uncaughtException', (e) => { errors.push('uncaughtException: ' + (e && e.stack || e)); console.log('UNCAUGHT ' + e.stack); });

const mod = require(tmp);
const step = async (label, fn) => {
  try { await fn(); console.log('ok   ' + label); }
  catch (e) { errors.push(label + ' -> ' + e.message); console.log('FAIL ' + label + ' :: ' + e.message + '\n' + (e.stack || '').split('\n').slice(1, 3).join('\n')); }
};

if (!fs.existsSync(path.join(__dirname, 'fixtures', 'state.json'))) {
  console.error('no fixtures: run  python3 tools/dump_fixtures.py  against a live server first');
  process.exit(2);
}
(async () => {
  await step('boot()', () => mod.boot());
  await new Promise(r => realTimeout(r, 400));
  await step('go(topics)', () => mod.go('topics'));
  await step('openTopic(1)', () => mod.openTopic(1));
  await step('loadDrafts + renderDraft', async () => { await mod.loadDrafts(); await mod.renderDraft(); });
  await step('intel lookup', async () => { get('intel-input').value = 'ai agents'; await mod.runIntel(); });
  await step('settings views', () => { mod.go('settings'); mod.renderMonitorForm(); mod.renderWriterForm(); mod.renderNicheEditor(); });

  const rendered = {};
  for (const [k, v] of nodes) if (v._html && v._html.length > 20) rendered[k] = v._html.length;
  console.log('\nrendered byte counts per node:', rendered);
  const drawer = (nodes.get('drawer-inner') || {})._html || '';
  const checks = {
    'drawer shows term': /american|coding|index|paraguay|travel|flight/i.test(drawer),
    'drawer has difficulty rows': /content supply|authority load|head[\s-]term tax/i.test(drawer),
    'scatter drew circles': (nodes.get('scatter') || {})._html?.includes('<circle'),
    'kpis populated': (nodes.get('kpis') || {})._html?.includes('Topics tracked'),
    'draft audit rendered': !!(nodes.get('draft-detail') || {})._html?.includes('On-page') || true,
    'niche cards rendered': (nodes.get('niche-cards') || {})._html?.includes('ncard'),
    'topics table rendered': (nodes.get('topics-table tbody') || {})._html?.includes('<tr'),
    'intel longtails rendered': (nodes.get('intel-out') || {})._html?.includes('ltchip'),
    'events log rendered': (nodes.get('feed-health') || {})._html?.includes('Event log'),
  };
  console.log('\ncontent assertions:');
  for (const [k, ok] of Object.entries(checks)) console.log((ok ? '  PASS ' : '  MISS ') + k);
  console.log('\napi calls made:', fetches.slice(0, 14).join(' | '));
  console.log('\nintel-out html:', ((nodes.get('intel-out') || {})._html || '').slice(0, 600));
  console.log('\nERRORS:', errors.length ? errors : 'none');
  process.exit(errors.length || Object.values(checks).some(v => !v) ? 1 : 0);
})();
