#!/usr/bin/env python3
"""Snapshot current API responses into tools/fixtures/ for the headless UI smoke test.

    python3 tools/dump_fixtures.py [http://127.0.0.1:8000]
    node tools/ui_smoke.js
"""
from __future__ import annotations

import json
import os
import sys
import urllib.parse
import urllib.request

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8000"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fixtures")
os.makedirs(OUT, exist_ok=True)

paths = {
    "state": "/api/state",
    "topics": "/api/topics?sort=opportunity&limit=120",
    "drafts": "/api/drafts",
    "settings": "/api/settings",
    "niches": "/api/niches",
    "logs": "/api/logs?limit=18",
    "scans": "/api/scans?limit=1",
}


def fetch(path: str) -> str:
    with urllib.request.urlopen(BASE + path, timeout=60) as r:
        return r.read().decode()


def main() -> int:
    if not os.environ.get("TW_SKIP_LIVE"):
        state = json.loads(fetch("/api/state"))
        top = (state.get("top_topics") or [{}])[0]
        drafts = state.get("recent_drafts") or []
        paths["topic1"] = f"/api/topics/{top.get('id', 1)}"
        paths["draft1"] = f"/api/drafts/{drafts[0]['id'] if drafts else 1}"
        paths["search"] = "/api/search?" + urllib.parse.urlencode({"keyword": top.get("term", "ai agents")})
    for name, path in paths.items():
        try:
            body = fetch(path)
        except Exception as exc:  # noqa: BLE001
            print(f"  skip {name}: {exc}")
            continue
        with open(os.path.join(OUT, f"{name}.json"), "w", encoding="utf-8") as fh:
            fh.write(body)
        print(f"  wrote {name}.json {len(body)} bytes  <- {path}")
    print("now run: node tools/ui_smoke.js")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
