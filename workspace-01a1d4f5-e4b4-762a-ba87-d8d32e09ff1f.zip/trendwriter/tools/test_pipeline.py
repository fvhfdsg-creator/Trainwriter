#!/usr/bin/env python3
"""End-to-end regression check for the shipped code paths (no network needed).

Runs a simulated scan, asserts every metric is in range, generates + audits + publishes a draft,
edits it through the API, and checks the export endpoints. Exits non-zero with a message on failure.

    python3 tools/test_pipeline.py
"""
from __future__ import annotations

import json
import os
import shutil
import sys
import tempfile
import threading
import urllib.error
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TMP = tempfile.mkdtemp(prefix="tw-test-")
os.environ["TRENDWRITER_DATA"] = TMP
os.environ["TRENDWRITER_PUB"] = os.path.join(TMP, "published")
os.environ.setdefault("TRENDWRITER_QUIET", "1")
sys.path.insert(0, ROOT)

from trendwriter import api, db, metrics, pipeline, sources, util, writer  # noqa: E402

CHECKS: list[tuple[str, bool, str]] = []


def check(name: str, cond, detail: str = "") -> None:
    CHECKS.append((name, bool(cond), str(detail)[:160]))


def main() -> int:
    try:
        def faq_ok(draft_row):
            graph = json.loads(draft_row["json_ld"]).get("@graph", [])
            f = next((g for g in graph if g.get("@type") == "FAQPage"), None)
            return bool(f and len(f.get("mainEntity", [])) >= 2)

        # ---------- 1. bootstrap + simulated scan
        pipeline.ensure_defaults()
        pipeline.set_settings({"live_sources": False, "sources": [], "cadence_min": 30})
        check("niches seeded", db.one("SELECT COUNT(*) AS n FROM niches")["n"] == 4)
        res = pipeline.run_scan(trigger="test")
        check("scan ok", res["status"] == "ok", res["error"])
        topics = db.rows("SELECT * FROM topics")
        check("topics created", len(topics) >= 8, f"{len(topics)}")
        for t in topics:
            ok = (10 <= t["volume_month"] <= 1_500_000 and 4 <= t["difficulty"] <= 96
                  and 0 <= t["opportunity"] <= 99 and t["intent"] in
                  {"informational", "commercial", "transactional", "navigational", "news"})
            check(f"metrics in range: {t['term'][:26]}", ok, f"vol={t['volume_month']} kd={t['difficulty']}")
            break
        check("keywords captured", db.one("SELECT COUNT(*) AS n FROM keywords")["n"] >= len(topics),
              "one primary row per topic at minimum")
        drafts = db.rows("SELECT * FROM drafts")
        check("auto-drafting ran", len(drafts) >= 1, f"{len(drafts)} drafts")

        # ---------- 2. draft content quality
        d = db.one("SELECT * FROM drafts ORDER BY seo_score DESC LIMIT 1")
        md = d["markdown"]
        check("has H1", md.startswith("# "))
        check("has data table", "|---" in md)
        check("has FAQ block", "Frequently asked questions" in md)
        check("has key takeaways", "Key takeaways" in md)
        check("no raw None in body", "None" not in md)
        check("word count in range", 700 <= d["word_count"] <= 2600, d["word_count"])
        check("readability computed", 20 <= (d["readability"] or 0) <= 90, d["readability"])
        check("density computed", 0.1 <= (d["keyword_density"] or 0) <= 4.0, d["keyword_density"])
        audit = json.loads(d["audit"])
        check("audit has 13 checks", len(audit) == 13, len(audit))
        passed = sum(1 for c in audit if c["ok"])
        check("seo score matches audit", d["seo_score"] == round(100 * passed / len(audit)),
              f"{d['seo_score']} vs {passed}/{len(audit)}")
        ld = json.loads(d["json_ld"])
        graph = ld.get("@graph", [])
        check("article schema present", any(g.get("@type") == "Article" for g in graph))
        faq = next((g for g in graph if g.get("@type") == "FAQPage"), None)
        check("faq schema present", faq is not None and len(faq["mainEntity"]) >= 3)
        check("faq answers non-empty", faq and all(len(a["acceptedAnswer"]["text"].strip()) > 40 for a in faq["mainEntity"]))
        check("html rendered", "<h2" in (d["html"] or "") and "<table>" in (d["html"] or ""))
        check("meta description length", 100 <= len(d["meta_description"] or "") <= 160, len(d["meta_description"] or ""))

        # ---------- 3. publish writes the artefacts to disk
        pub = pipeline.publish_draft(d["id"])
        check("status published", pub["status"] == "published")
        for pth in (pub["file_md"], pub["file_html"]):
            check(f"file exists {os.path.basename(pth)}", os.path.isfile(pth) and os.path.getsize(pth) > 500)
        with open(pub["file_md"], encoding="utf-8") as fh:
            front = fh.read()
        check("front matter written", front.startswith("---") and "seo_score:" in front)
        check("topic marked published", db.one("SELECT status FROM topics WHERE id=?", (d["topic_id"],))["status"] == "published")

        # ---------- 4. internal links appear in later drafts of the same niche
        second = None
        for row in db.rows("SELECT id,status FROM topics WHERE status='watching' AND niche_id=? LIMIT 1", (d["niche_id"],)):
            second = pipeline.create_draft(row["id"])
            break
        if second:
            check("cross-linking to published post", "/preview/" in (second["markdown"] or ""),
                  "internal link expected once a post is live")
            check("re-audit reflects links", json.loads(second["audit"])[8]["ok"], json.loads(second["audit"])[8])

        # ---------- 5. metric maths
        vol = metrics.estimate_volume([("google_trends", 1000, 1.0)], 8, 3, 12)
        check("volume blend deterministic", vol["volume_month"] > 1000 and vol["components"]["google_trends"]["daily"] == 1000)
        cold = metrics.estimate_volume([], 6, 2, 10)
        check("cold-start fallback yields volume", cold["volume_month"] > 0)
        easy = metrics.keyword_difficulty(term="how to fix a squeaky door hinge at home", volume=320, intent="informational",
                                         suggest_count=14, question_suggests=9, longtail_share=.6, authority_share=0.0,
                                         coverage_items=0, median_age_h=800, exact_article=False, competitor_words=300)
        hard = metrics.keyword_difficulty(term="mortgage rates", volume=90_000, intent="commercial", suggest_count=1,
                                         question_suggests=0, longtail_share=0, authority_share=.9, coverage_items=9,
                                         median_age_h=2, exact_article=True, competitor_words=2400)
        check("long-tail easier than head term", easy["difficulty"] < hard["difficulty"],
              f"{easy['difficulty']} vs {hard['difficulty']}")
        opp_hi = metrics.opportunity(volume=8000, difficulty=22, velocity_v=1.4, intent="commercial",
                                    coverage_items=2, suggest_count=10, corroboration=3)
        opp_lo = metrics.opportunity(volume=8000, difficulty=88, velocity_v=-0.4, intent="navigational",
                                    coverage_items=30, suggest_count=2, corroboration=1)
        check("opportunity rewards rankability", opp_hi["opportunity"] > opp_lo["opportunity"] + 15,
              f"{opp_hi['opportunity']} vs {opp_lo['opportunity']}")
        v5 = metrics.velocity([{"v": 10}, {"v": 20}, {"v": 34}, {"v": 55}], [], 5)
        check("velocity labels", v5["velocity_label"] in ("rising", "spiking") and v5["velocity"] > 0.2, v5)
        check("velocity handles decline", metrics.velocity([{"v": 90}, {"v": 60}, {"v": 35}, {"v": 12}], [], 5)["velocity_label"] == "cooling")

        # ---------- 6. formatters
        check("markdown lists merge", util.md_to_html("- a\n- b").count("<ul>") == 1)
        check("markdown table renders", "<td>x</td>" in util.md_to_html("| a |\n|---|\n| x |"))
        check("parse_traffic buckets", sources.util.parse_traffic("10K+") == 15000 and util.parse_traffic("250") == 250)
        check("slugify ascii", util.slugify("AI Agents: What's Next?!") == "ai-agents-whats-next",
              util.slugify("AI Agents: What's Next?!"))


        # ---------- 9. LLM writer path against a stub OpenAI-compatible endpoint
        from http.server import BaseHTTPRequestHandler, HTTPServer

        captured = {}

        class Stub(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def do_POST(self):
                length = int(self.headers.get("Content-Length") or 0)
                captured["auth"] = self.headers.get("Authorization")
                captured["payload"] = json.loads(self.rfile.read(length).decode())
                if "fail" in self.path:
                    body = json.dumps({"error": {"message": "model overload"}}).encode()
                    self.send_response(500)
                else:
                    art = ("# How Index Funds Actually Behave In A Rate Cycle\n\n"
                           "meta description: A data-led look at index fund behaviour when rates move, using measured demand signals.\n\n"
                           "An index fund is a mechanical bet. " * 12 +
                           "\n\n## Why it matters\n\nBecause the data table below shows the cluster.\n\n"
                           "| Keyword | Volume | Difficulty |\n|---|---|---|\n| index fund | 1200 | 40 |\n\n"
                           "## FAQ\n\n**Do fees compound?**\n\nYes - a 0.30% drag on a 30-year hold is material.\n\n"
                           "**Is timing relevant?**\n\nNot for a broad allocation; treat it as a rebalancing question.\n\n"
                           "## Sources\n\n- [Wikipedia](https://en.wikipedia.org/wiki/Index_fund)\n")
                    body = json.dumps({"choices": [{"message": {"role": "assistant", "content": art}}]}).encode()
                    self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

        stub = HTTPServer(("127.0.0.1", 0), Stub)
        stub_port = stub.server_address[1]
        threading.Thread(target=stub.serve_forever, daemon=True).start()
        topic_for_llm = db.one("SELECT id FROM topics WHERE (SELECT COUNT(*) FROM drafts WHERE topic_id=topics.id)=0 LIMIT 1")
        if topic_for_llm:
            pipeline.set_settings({"llm": {"enabled": True, "api_key": "sk-test-1234567890",
                                           "api_base": f"http://127.0.0.1:{stub_port}/v1", "model": "stub-model"}})
            d_llm = pipeline.create_draft(topic_for_llm["id"])
            check("llm draft created", d_llm and d_llm["writer"] == "llm", (d_llm or {}).get("writer"))
            check("llm title parsed", d_llm and d_llm["title"] == "How Index Funds Actually Behave In A Rate Cycle",
                  (d_llm or {}).get("title"))
            check("llm meta parsed", d_llm and "data-led" in d_llm["meta_description"], (d_llm or {}).get("meta_description"))
            pl = captured.get("payload") or {}
            check("llm payload carries brief", pl.get("model") == "stub-model" and pl.get("messages", [{}])[0]["content"].startswith("You are an SEO editor")
                  and "opportunity" in pl["messages"][1]["content"] and "DATA" in pl["messages"][1]["content"],
                  json.dumps(pl)[:200])
            check("auth header sent", captured["auth"] == "Bearer sk-test-1234567890", captured["auth"])
            check("llm audit still runs", d_llm and len(json.loads(d_llm["audit"])) == 13)
            check("llm faq schema parsed", d_llm and faq_ok(d_llm))
            # failure path -> must fall back to the offline composer, not error out
            pipeline.set_settings({"llm": {"api_base": f"http://127.0.0.1:{stub_port}/v1-fail"}})
            nxt = db.one("SELECT id FROM topics WHERE (SELECT COUNT(*) FROM drafts WHERE topic_id=topics.id)=0 LIMIT 1")
            if nxt:
                d_fb = pipeline.create_draft(nxt["id"])
                check("llm outage falls back to offline writer", d_fb and d_fb["writer"] == "offline",
                      (d_fb or {}).get("writer"))
            pipeline.set_settings({"llm": {"enabled": False, "api_key": ""}})
        stub.shutdown()

        # ---------- 7. HTTP layer over a real server
        srv = api.create_server("127.0.0.1", 0)
        port = srv.server_address[1]
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        base = f"http://127.0.0.1:{port}"

        def get(path, method="GET", payload=None):
            req = urllib.request.Request(base + path, method=method,
                                        data=json.dumps(payload).encode() if payload is not None else None,
                                        headers={"Content-Type": "application/json"})
            try:
                r = urllib.request.urlopen(req, timeout=30)
            except urllib.error.HTTPError as err:
                raw = err.read().decode()
                return err.code, raw
            with r:
                raw = r.read().decode()
                return r.status, (json.loads(raw) if r.headers.get("Content-Type", "").startswith("application/json") else raw)

        st, state = get("/api/state")
        check("GET /api/state", st == 200 and state["stats"]["topics"] >= 8)
        check("api_key never echoed back", state["settings"]["llm"]["api_key"] == "", state["settings"]["llm"].get("api_key"))
        st, body = get(f"/api/topics/{d['topic_id']}")
        check("GET /api/topics/{id} deep", st == 200 and "signals" in body and "keywords" in body)
        st, body = get(f"/api/drafts/{d['id']}")
        check("GET /api/drafts/{id}", st == 200 and body["markdown"].startswith("# "))
        st, body = get(f"/api/drafts/{d['id']}", "PATCH", {"title": "A hand-edited headline for testing",
                                                           "markdown": md + "\n\n## Editor note\n\nAdded by the regression test.\n"})
        check("PATCH re-audits on save", st == 200 and body["draft"]["title"].startswith("A hand-edited"))
        check("PATCH updated word count", body["draft"]["word_count"] > d["word_count"], body["draft"]["word_count"])
        st, body = get(f"/api/export/{d['id']}.md")
        check("export markdown", st == 200 and body.startswith("#"))
        st, body = get(f"/api/export/{d['id']}.json")
        check("export json bundle", st == 200 and "@graph" in json.dumps(body))
        st, body = get("/api/feed.xml")
        check("rss feed lists published post", st == 200 and "<item>" in body and "preview" in body)
        st, body = get("/api/nope")
        check("unknown api route 404s", st == 404)
        st, body = get("/")
        check("dashboard html served", st == 200 and "TrendWriter" in body and 'src="/app.js"' in body)
        st, body = get("/app.js")
        check("app.js served", st == 200 and "api.get" in body)
        st, body = get("/api/search?keyword=index%20funds")
        check("keyword intel endpoint", st == 200 and body["difficulty"] >= 0 and "longtails" in body)
        st, body = get("/api/niches", "POST", {"name": "Test Niche", "seed_keywords": ["test seeds"]})
        new_id = (body.get("niche") or {}).get("id")
        check("niche created", st == 201 and new_id)
        st, body = get(f"/api/niches/{new_id}", "PUT", {"min_opportunity": 40, "enabled": False})
        check("niche updated", st == 200 and body["niche"]["min_opportunity"] == 40 and not body["niche"]["enabled"])
        st, body = get(f"/api/niches/{new_id}", "DELETE")
        check("niche deleted", st == 200)
        st, body = get("/api/scheduler", "POST", {"action": "pause"})
        check("scheduler pause accepted", st == 200 and body["enabled"] is False)
        st, body = get("/api/scheduler", "POST", {"action": "resume"})
        check("scheduler resume accepted", st == 200 and body["enabled"] is True)
        st, body = get("/api/drafts", "POST", {})
        check("draft without topic rejected", st == 400)
        srv.shutdown()

        # ---------- 8. settings persistence round-trip
        pipeline.set_settings({"cadence_min": 47, "stale_days": 9,
                               "llm": {"model": "some-model", "enabled": True, "api_base": "https://api.openai.com/v1"}})
        st2 = pipeline.get_settings()
        check("settings merge nested", st2["cadence_min"] == 47 and st2["stale_days"] == 9
              and st2["llm"]["enabled"] is True and st2["llm"]["api_base"] == "https://api.openai.com/v1"
              and st2["llm"]["temperature"] == 0.6, st2["llm"])
        check("unspecified settings survive", st2["max_topics_per_scan"] == 6 and st2["regions"] == ["US"]
              and st2["fallback_to_sim"] is True, st2["regions"])
        return CHECKS
    finally:
        shutil.rmtree(TMP, ignore_errors=True)
        db._ready = False


if __name__ == "__main__":
    failed = 0
    try:
        main()
    except SystemExit:
        raise
    except Exception as exc:  # noqa: BLE001
        import traceback

        CHECKS.append(("harness crashed", False, traceback.format_exc()[-500:]))
    for name, ok, detail in CHECKS:
        if not ok:
            failed += 1
        print(("  PASS  " if ok else "  FAIL  ") + name + (f"   [{detail}]" if (detail and not ok) else ""))
    print(f"\n{len(CHECKS) - failed}/{len(CHECKS)} checks passed")
    raise SystemExit(1 if failed else 0)
