# TrendWriter — trend monitor → keyword intel → drafted SEO posts

An automated web app that continuously watches a set of niches for topics that are gaining search
demand, scores each one for **estimated volume**, **keyword difficulty** and **opportunity**, then
**drafts, formats and audits a publish-ready SEO article** and pushes it into a review queue.

Everything runs on the Python standard library — no `pip install`, no build step, no API key needed
to get value. Live signals come from public endpoints (Google Trends, Google News, Wikipedia
pageviews, Hacker News, GitHub, Google Autocomplete).

```
 ┌─────────────┐   every N min   ┌──────────────────┐    ┌──────────────────────┐
 │ scheduler   │ ───────────────▶│ sources          │───▶│ candidate mining     │
 │ (thread)    │                 │ trends/news/wiki │    │ n-grams + relevance  │
 └─────────────┘                 │ hn/github/suggest│    └──────────┬───────────┘
        ▲                       └──────────────────┘               ▼
        │                                        ┌───────────────────────────────┐
        │                                        │ keyword intel per topic       │
   ┌────┴────────┐                               │ autocomplete space, wiki hit, │
   │ REST API    │◀──────────── dashboard ───────│ authority share, coverage age │
   │ + dashboard │                               └───────────────┬───────────────┘
   └────┬────────┘                                               ▼
        │                          ┌──────────────────────────────────────────────┐
        ├── /api/topics            │ metrics: volume model · difficulty 0-100 ·   │
        ├── /api/search  ──────────│ velocity · opportunity · intent · clusters   │
        ├── /api/drafts            └───────────────┬──────────────────────────────┘
        └── /api/export/*.{md,html,json}           ▼
                                        ┌──────────────────────┐   thresholds per niche
                                        │ writer (offline |LLM)│ ─────────────────────┐
                                        │ compose + audit +    │                      ▼
                                        │ schema + html        │        ┌───────────────────────────┐
                                        └──────────────────────┘        │ SQLite: topics, keywords, │
                                                                        │ drafts, scans, events     │
                                                                        └───────────┬───────────────┘
                                                                                    ▼
                                                                        published/{slug}.{md,html,json}
                                                                        /api/feed.xml (RSS of live posts)
```

## Run it

```bash
cd trendwriter
python3 run.py                     # http://localhost:8000  (dashboard + auto-scan every 30 min)
python3 run.py --port 9000         # different port
python3 run.py --no-scheduler      # dashboard only, scan on demand
python3 run.py --once              # single scan, print a summary, exit — good for cron
python3 run.py --once --simulated  # same, without touching the network
python3 tools/test_pipeline.py     # 65-check end-to-end regression test
python3 tools/test_pipeline.py     # (already run above) exits non-zero on any failure
python3 tools/dump_fixtures.py     # snapshot live API responses into tools/fixtures/
node tools/ui_smoke.js             # headless render test of every dashboard view
```

Optional container run:

```bash
docker build -t trendwriter . && docker run -p 8000:8000 -v "$PWD/data:/app/data" trendwriter
```

## What each tab does

| Tab | Contents |
|---|---|
| **Overview** | KPI strip, opportunity map (difficulty × volume, bubble = opportunity), per-niche cards, source health, event log |
| **Trending topics** | Every tracked keyword with volume / difficulty / opportunity / velocity / intent; row click opens the full breakdown (difficulty components, demand blend, keyword cluster, evidence links, cluster siblings) |
| **Keyword intel** | On-demand analysis of any phrase — live autocomplete space, volume blend, difficulty parts, pageview series — plus *Track & draft* |
| **Draft queue** | Every generated article: rendered preview, editable title/slug/meta/markdown with re-audit, 13-point on-page checklist, JSON-LD, exports, publish |
| **Automation** | Cadence, source toggles, geo regions, thresholds per niche, writer engine (offline vs LLM), site metadata, data reset |

Publishing writes `published/<slug>.md` (with front matter), `<slug>.html` (a complete standalone
page with meta tags, Open Graph and Article + FAQPage JSON-LD) and `<slug>.json` (bundle for a CMS
import), and the item appears in `/api/feed.xml`.

## How the numbers are produced

They are **pipeline estimates**, not paid-tool exports — and every one is explainable in the UI.

**Estimated monthly volume** — each signal source contributes a daily figure (Google Trends bucket,
Wikipedia daily pageviews, article time series, news-coverage count). They are blended by weight,
recency-decayed, then widened for the query family:

```
monthly = Σ(daily_src × w)/Σw  × 30.4 × peak_decay × (1 + 0.18·log2(1 + autocomplete_variants))
          × (1 + min(0.25, coverage × 0.04))
```

News-intent spikes get a 0.30 decay because a Trends peak is a one-day event, not a monthly average.
Long-tails inherit `head × 0.34^gap × jitter`, which keeps the cluster internally consistent.

**Keyword difficulty (0-100)** — additive parts, all shown in the drawer:

```
30 base + content supply + authority load + head-term tax − long-tail relief
  + intent adjust + freshness gap ± competitor depth
```

*content supply* counts how many fresh items already target the phrase, *authority load* is the share
of coverage from domains a small site cannot outrank, *long-tail relief* rewards terms with a rich
question space, *freshness gap* rewards SERPs nobody has refreshed lately.

**Opportunity (0-100)** = `0.34·demand + 0.28·rankability + 0.22·velocity + 0.16·query_depth`,
weighted by intent (commercial 1.14 → news 0.70). ≥74 "Momentum pick", ≥58 "Quick win",
≥42 "Needs an angle", else "Pass for now". Auto-drafting only fires when a topic clears the niche's
own `min_opportunity`, `min_volume` and `max_difficulty`.

**Velocity** — slope of the Wikipedia daily series plus the delta between successive scans of our
own estimate, so the first scan establishes a baseline and every later scan has a real growth number.

## Automation contract

Per scan (`/api/scan` or the scheduler thread):

1. fetch all enabled sources, per region, guarded — a dead source is recorded as health data, never an exception
2. mine phrases from headlines, score them against each niche's seed/include/exclude vocabulary
3. enrich the top `max_topics_per_scan` per niche (autocomplete, Wikipedia search, DuckDuckGo, pageview series)
4. compute metrics, upsert topics (dedupe by sorted-token key so *"singapore vs paraguay"* and
   *"paraguay vs singapore"* merge), refresh keyword rows, rebuild clusters
5. auto-draft anything above threshold, mark unseen topics stale after `stale_days`
6. write a `scans` record with duration, counts and per-source status

## Writer engine

* **Offline composer (default)** — builds the article from the measured brief only: intro with the
  keyword up front, "why it's trending" with dated citations, the keyword-cluster table, a
  reader-specific angle, numbered steps, one section per question long-tail, mistakes, FAQ, takeaways,
  sources, plus a finance/health disclaimer where relevant. It never invents a statistic: any number
  in the post came from the scan that produced it.
* **LLM mode** — set `llm.enabled`, `api_base`, `model` and `api_key` in Automation (any
  OpenAI-compatible `/chat/completions` endpoint). The model receives the same data brief with an
  anti-fabrication contract; its output is still put through the formatter, 13-point audit and
  schema builder. If the call fails, the draft falls back to the offline composer automatically.

The on-page audit checks focus keyword in title/opening, meta length, keyphrase density and stuffing,
word count, heading structure, readability, outbound citations, internal links to already-published
posts in the same niche, a data table, an FAQ block and title length — and the resulting score gates
nothing, it just tells the editor what to fix.

## REST API

```
GET  /api/state                       dashboard payload: stats, settings, niches, top topics, last scan
GET  /api/topics?niche=&status=&sort=&q=&deep=1
GET  /api/topics/{id}                 metrics + signals + keywords + evidence + cluster + draft
POST /api/topics/{id}/status          {"status":"dismissed"}
POST /api/scan                        {"niche_ids":[1,2]} optional; 202 + background run
GET  /api/scans?limit=                run history with per-source health
GET  /api/search?keyword=&niche=      on-demand keyword intel
POST /api/search/draft                {"keyword":"…","niche_id":n} track + draft in one call
GET  /api/drafts?status=&niche=       queue
POST /api/drafts                      {"topic_id":n} draft a tracked topic now
GET  /api/drafts/{id}                 full article, audit, schema
PATCH /api/drafts/{id}                title/slug/meta/markdown/status → re-audit on save
POST /api/drafts/{id}/regenerate      rebuild from fresher data
POST /api/drafts/{id}/publish         write files, mark live, update RSS
GET  /api/export/{id}.md|.html|.json  downloads
GET  /api/preview/{id}                standalone rendered page
GET  /api/feed.xml                    RSS of published posts
GET  /api/niches · POST /api/niches · PUT/DELETE /api/niches/{id}
GET/POST /api/settings                cadence, sources, thresholds, llm, site
POST /api/scheduler                   {"action":"pause"|"resume"|"trigger"}
POST /api/sources/test                probe each fetcher, report latency + item counts
GET  /api/logs?limit=                 event log
POST /api/reset                       clear topics/drafts/scans (keeps niches + settings)
```

Data lives in `data/app.db` (SQLite, WAL). Override with `TRENDWRITER_DATA=/path`, published files
with `TRENDWRITER_PUB=/path`.

## Extending it

* **Add a source** — one function in `trendwriter/sources.py` returning
  `{term,title,source,published,age_hours,score_raw,evidence}` + a line in `run_scan`. Nothing else changes.
* **Add a niche** — from the UI, or `POST /api/niches` with `name` + `seed_keywords`.
* **Swap the volume model** — `metrics.estimate_volume` is the only place that turns signals into a
  number; wire a DataForSEO/Semrush/Ahrefs call there and the rest of the app (queue, scoring, drafts)
  inherits it, including the SERP-backed difficulty if you pass real results into
  `metrics.keyword_difficulty`.
* **Publish destination** — `pipeline.publish_draft` writes the three files; replace its body with a
  POST to your CMS and the queue UI keeps working.

## Known limits (stated plainly)

* Volumes and difficulty are model estimates from public signals; they are internally consistent and
  explainable, not calibrated against a paid index. Re-scan before publishing anything important.
* Google News evidence links use `news.google.com` redirect URLs — they open the publisher article in
  a browser, which is what the draft intends.
* Reddit blocks unauthenticated bots (HTTP 403), so it ships disabled; the toggle exists for when you
  add a proxy or OAuth creds.
* One process, single-user by design — no auth layer. Put it behind your reverse proxy's auth if it is
  exposed publicly, and set the LLM key in the UI (it is stored locally and never returned by the API).
