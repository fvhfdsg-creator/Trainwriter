/* TrendWriter dashboard - vanilla JS, no build step. */
const api = {
  async get(p) { const r = await fetch(p); if (!r.ok) throw new Error((await r.json()).error || r.status); return r.json(); },
  async send(p, m, b) {
    const r = await fetch(p, { method: m, headers: { 'Content-Type': 'application/json' }, body: b ? JSON.stringify(b) : undefined });
    const t = await r.text(); let d = null; try { d = t ? JSON.parse(t) : null; } catch (e) { d = { raw: t }; }
    if (!r.ok) throw new Error((d && d.error) || r.statusText); return d;
  },
  post: (p, b) => api.send(p, 'POST', b || {}),
  patch: (p, b) => api.send(p, 'PATCH', b),
  del: (p) => api.send(p, 'DELETE'),
};
const $ = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const n = (v) => (v == null ? '—' : Number(v).toLocaleString('en-US'));
const compact = (v) => (v == null ? '—' : v >= 1e6 ? (v / 1e6).toFixed(1).replace(/\.0$/, '') + 'M' : v >= 1e3 ? (v / 1e3).toFixed(1).replace(/\.0$/, '') + 'K' : String(Math.round(v)));
const ago = (iso) => { if (!iso) return '—'; const s = (Date.now() - new Date(iso).getTime()) / 1000; if (s < 60) return Math.max(1, s | 0) + 's'; if (s < 3600) return (s / 60 | 0) + 'm'; if (s < 86400) return (s / 3600 | 0) + 'h'; return (s / 86400 | 0) + 'd'; };
const rel = (t, v) => v == null ? '—' : (v > 0 ? '▲' : v < 0 ? '▼' : '·') + ' ' + Math.abs(v * 100).toFixed(0) + '%';
const toast = (msg, kind) => { const t = $('#toast'); t.textContent = msg; t.className = 'toast show ' + (kind || ''); setTimeout(() => t.className = 'toast', 3400); };
const kw = (o) => Object.entries(o).map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join('&');

const state = { view: 'overview', niche: '', status: 'any', sort: 'opportunity', q: '', topics: [], niches: [], settings: {}, drafts: [], draftFilter: '', selected: null, intel: null, timer: null, scanning: false };
const nicheColor = (id) => (state.niches.find(x => x.id === id) || {}).color || '#7c5cff';
const nicheName = (id) => (state.niches.find(x => x.id === id) || {}).name || '—';

/* ---------------------------------------------------------------- boot */
async function boot() {
  bind();
  await refresh();
  state.timer = setInterval(() => { if (!document.hidden && !state.scanning) refresh(true); }, 25000);
  setInterval(tickCountdown, 1000);
}

async function refresh(quiet) {
  try {
    const st = await api.get('/api/state');
    state.settings = st.settings; state.niches = st.niches; state.stats = st.stats; state.last_scan = st.last_scan; state.scheduler = st.scheduler;
    renderKPIs(st); renderNicheCards(st); renderScatter(st.top_topics); renderRecent(st.recent_drafts);
    renderScheduler(st); renderMonitorForm(); renderWriterForm(); renderNicheEditor();
    await Promise.all([loadTopics(), loadDrafts(), loadFeed()]);
    if (!quiet) toastLoaded();
  } catch (e) { console.error(e); if (!quiet) toast('Load failed: ' + e.message, 'bad'); }
}
const toastLoaded = () => { const el = $('#scan-note'); if (el && !state.scanning) el.textContent = 'synced ' + new Date().toLocaleTimeString(); };

function renderScheduler(st) {
  const on = st.scheduler && st.scheduler.enabled;
  $('#sched-dot').className = 'dot ' + (state.scanning ? 'run' : on ? 'live' : 'off');
  $('#sched-state').textContent = state.scanning ? 'scanning now' : on ? 'auto-scan on' : 'paused';
  const bs = $('#btn-sched'); if (bs) { bs.textContent = on ? '⏸ pause' : '▶ resume'; bs.dataset.on = on ? '1' : '0'; }
  state.nextRun = st.scheduler && st.scheduler.next_run ? st.scheduler.next_run * 1000 : null;
  tickCountdown();
  $('#scan-note').textContent = st.last_scan ? `last scan ${ago(st.last_scan.started_at)} ago · ${st.last_scan.topics_found || 0} candidates · ${st.last_scan.drafts_created || 0} drafted` : 'no scans yet';
  $('#scan-stats').textContent = st.last_scan && st.last_scan.duration_s ? `${st.last_scan.duration_s}s run · ${st.stats.scans} total` : '—';
  const health = ((st.last_scan || {}).source_health || []);
  $('#feed-health').innerHTML = `<div class="src-grid">` + (health.length ? health.map(h => `
      <div class="src ${h.ok ? 'ok' : 'err'}" title="${esc(h.error || '')}"><b>${esc(h.source)}</b>
        <span>${h.ok ? h.count + ' items' : 'down'}</span><i>${h.ms || 0}ms</i></div>`).join('')
    : '<div class="muted small">Run a scan to see per-source health.</div>') + `</div>
    <div class="events">${(st.recent_drafts || []).slice(0, 4).map(d => `<div class="ev"><span class="tick"></span>${esc(d.title)} <em>${d.seo_score}/100 SEO · ${d.status}</em></div>`).join('')}</div>`;
}
function tickCountdown() {
  const el = $('#sched-next'); if (!el) return;
  if (state.scanning) { el.textContent = 'fetching signals…'; return; }
  if (!state.nextRun) { el.textContent = 'auto-scan paused'; return; }
  const s = Math.max(0, Math.round((state.nextRun - Date.now()) / 1000));
  el.textContent = `next scan in ${(s / 60 | 0)}:${String(s % 60).padStart(2, '0')}`;
}
function renderKPIs(st) {
  const s = st.stats || {}, sum = (st.top_topics || []).reduce((a, t) => a + t.volume_month, 0);
  const items = [
    ['Topics tracked', n(s.topics), `${s.fresh || 0} new since last scan`, 'ok'],
    ['Qualifying', n(s.quick_wins), 'above niche opportunity bar', 'ok'],
    ['Est. demand', compact(s.reach), 'monthly searches across queue', 'ok'],
    ['Drafts ready', n(s.pending), `${n(s.published)} published to disk`, 'violet'],
  ];
  $('#kpis').innerHTML = items.map(([l, v, sub, tone]) => `<div class="kpi ${tone}"><span>${esc(l)}</span><b>${esc(v)}</b><small>${esc(sub)}</small></div>`).join('');
}
async function loadFeed() {
  try {
    const r = await api.get('/api/logs?limit=18');
    const box = $('#feed-health'); if (!box) return;
    const ev = (r.events || []).map(e => `<div class="ev"><span class="tick"></span><span>${esc(e.message)}</span><em>${esc(ago(e.t))}</em></div>`).join('');
    box.insertAdjacentHTML('beforeend', `<div class="mt">Event log</div><div class="events">${ev || '<span class="muted tiny">no events yet</span>'}</div>`);
  } catch (e) { /* non-fatal */ }
}
function renderNicheCards(st) {
  $('#intel-niche').innerHTML = '<option value="">auto-detect niche</option>' + (st.niches || []).map(x => `<option value="${x.slug}">${esc(x.name)}</option>`).join('');
  $('#niche-cards').innerHTML = (st.niches || []).map(x => {
    const pct = x.topic_count ? Math.round(100 * (x.qualifying_count || 0) / x.topic_count) : 0;
    return `<div class="ncard" style="--c:${x.color}">
      <div class="ncard-top"><b>${esc(x.name)}</b><span class="pill">${x.enabled ? 'live' : 'off'}</span></div>
      <div class="ncard-grid"><div><i>topics</i><b>${x.topic_count || 0}</b></div><div><i>qualifying</i><b>${x.qualifying_count || 0}</b></div>
        <div><i>drafts</i><b>${x.draft_count || 0}</b></div><div><i>live</i><b>${x.published_count || 0}</b></div></div>
      <div class="bar"><span style="width:${pct}%"></span></div>
      <div class="ncard-foot">${esc((x.seed_keywords || []).slice(0, 4).join(' · '))}</div>
      <button class="btn tiny" data-scan-niche="${x.id}">Scan now</button></div>`;
  }).join('');
}
function renderRecent(drafts) {
  $('#recent-drafts').innerHTML = (drafts && drafts.length) ? drafts.slice(0, 6).map(d => `
    <div class="drow" data-open-draft="${d.id}">
      <div class="score ${d.seo_score >= 80 ? 'hi' : d.seo_score >= 60 ? 'mid' : 'lo'}">${d.seo_score}</div>
      <div class="drow-main"><b>${esc(d.title)}</b><span>${esc(d.focus_keyword)} · ${d.word_count} words · ${d.status}</span></div>
      <a class="btn tiny" href="/api/export/${d.id}.md" download>md</a>
      <a class="btn tiny" href="/api/export/${d.id}.html" target="_blank">html</a></div>`).join('')
    : '<div class="empty small">No drafts yet — the writer runs automatically when a topic clears its niche thresholds.</div>';
}

/* ---------------------------------------------------------------- scatter */
function renderScatter(topics) {
  const svg = $('#scatter'); const W = 720, H = 360, P = { l: 48, r: 16, t: 14, b: 34 };
  const data = (topics || []).slice(0, 60);
  if (!data.length) { svg.innerHTML = `<text x="${W / 2}" y="${H / 2}" fill="#697091" font-size="13" text-anchor="middle">no data yet — run a scan</text>`; $('#scatter-legend').innerHTML = ''; return; }
  const maxV = Math.max(...data.map(d => d.volume_month), 1000);
  const x = (d) => P.l + (d.difficulty / 100) * (W - P.l - P.r);
  const y = (d) => H - P.b - (Math.log10(d.volume_month + 10) / Math.log10(maxV + 10)) * (H - P.t - P.b);
  const r = (d) => 3.5 + (d.opportunity / 100) * 9;
  let g = `<defs></defs>`;
  for (let i = 0; i <= 4; i++) {
    const gx = P.l + (i / 4) * (W - P.l - P.r);
    g += `<line x1="${gx}" y1="${P.t}" x2="${gx}" y2="${H - P.b}" class="grid"/><text x="${gx}" y="${H - 12}" class="axl" text-anchor="middle">${i * 25}</text>`;
    const gy = P.t + (i / 4) * (H - P.t - P.b);
    const val = Math.pow(10, Math.log10(maxV + 10) * (1 - i / 4)) - 10;
    g += `<line x1="${P.l}" y1="${gy}" x2="${W - P.r}" y2="${gy}" class="grid"/><text x="${P.l - 8}" y="${gy + 4}" class="axl" text-anchor="end">${compact(Math.max(0, val))}</text>`;
  }
  g += `<line x1="${P.l}" y1="${H - P.b}" x2="${W - P.r}" y2="${H - P.b}" class="axis"/><line x1="${P.l}" y1="${P.t}" x2="${P.l}" y2="${H - P.b}" class="axis"/>`;
  g += `<rect x="${P.l}" y="${P.t}" width="${(W - P.l - P.r) * 0.45}" height="${(H - P.t - P.b) * 0.55}" class="zone"/><text x="${P.l + 8}" y="${P.t + 16}" class="zone-lbl">sweet spot</text>`;
  g += data.map(d => `<circle cx="${x(d).toFixed(1)}" cy="${y(d).toFixed(1)}" r="${r(d).toFixed(1)}" fill="${nicheColor(d.niche_id)}"
      fill-opacity="${(0.28 + d.opportunity / 200).toFixed(2)}" stroke="${nicheColor(d.niche_id)}" stroke-width="1.1" data-topic="${d.id}"><title>${esc(d.term)} — vol ${n(d.volume_month)}, KD ${d.difficulty}, opp ${d.opportunity}</title></circle>`).join('');
  svg.innerHTML = g;
  $('#scatter-legend').innerHTML = state.niches.map(x2 => `<span><i style="background:${x2.color}"></i>${esc(x2.name)}</span>`).join('');
}

/* ---------------------------------------------------------------- topics */
async function loadTopics() {
  const q = { sort: state.sort, limit: 120 };
  if (state.niche) q.niche = state.niche;
  if (state.status && state.status !== 'any') q.status = state.status;
  if (state.q) q.q = state.q;
  const r = await api.get('/api/topics?' + kw(q));
  state.topics = r.topics;
  const chips = [['', 'all niches'], ...state.niches.map(x => [x.id, x.name])];
  $('#niche-chips').innerHTML = chips.map(([v, l]) => `<button class="chip ${String(state.niche) === String(v) || (!state.niche && v === '') ? 'on' : ''}" data-niche="${v}">${esc(l)}</button>`).join('');
  const st = [['any', 'any status'], ['new', 'new'], ['watching', 'watching'], ['drafted', 'drafted'], ['published', 'published'], ['dismissed', 'dismissed'], ['stale', 'stale']];
  $('#status-chips').innerHTML = st.map(([v, l]) => `<button class="chip ${state.status === v ? 'on' : ''}" data-status="${v}">${esc(l)}</button>`).join('');
  const rows = state.topics.map(t => {
    const drafted = !!t.draft_id;
    return `<tr data-topic="${t.id}" class="${t.opportunity >= 74 ? 'hot' : ''}">
      <td class="t-term"><b>${esc(t.term)}</b><span class="sub">${esc((t.sources || []).join(' + '))} · seen ${t.seen_count}× · ${ago(t.last_seen)} ago</span></td>
      <td><span class="niche" style="--c:${nicheColor(t.niche_id)}">${esc(nicheName(t.niche_id))}</span></td>
      <td class="num"><b>${compact(t.volume_month)}</b><span class="sub">${n(t.volume_daily)}/day</span></td>
      <td><div class="meter"><span style="width:${t.difficulty}%;background:${t.difficulty < 45 ? 'var(--good)' : t.difficulty < 68 ? 'var(--warn)' : 'var(--bad)'}"></span></div><i>${t.difficulty}</i></td>
      <td class="num"><span class="opp ${t.opportunity >= 74 ? 'hi' : t.opportunity >= 58 ? 'mid' : 'lo'}">${t.opportunity}</span></td>
      <td class="${t.velocity > 0.22 ? 'up' : t.velocity < -0.15 ? 'down' : ''}">${rel(null, t.velocity)} <em>${esc(t.label || '')}</em></td>
      <td><span class="tag">${esc((t.intent || '').slice(0, 13))}</span></td>
      <td><span class="pill ${t.status}">${esc(t.status)}</span></td>
      <td class="num acts"><button class="btn tiny" data-draft="${t.id}">${drafted ? 're-draft' : '✎ draft'}</button>
        <button class="btn tiny ghost" data-hide="${t.id}">hide</button></td></tr>`;
  }).join('');
  $('#topics-table tbody').innerHTML = rows;
  $('#topics-empty').classList.toggle('hidden', state.topics.length > 0);
}

async function openTopic(id) {
  try {
    const t = await api.get('/api/topics/' + id);
    const kd = t.kd || {}, sig = t.signals || {}, opp = t.opportunity_parts || sig.opportunity_parts || {};
    $('#drawer-inner').innerHTML = `
      <div class="drawer-head"><div><span class="niche" style="--c:${nicheColor(t.niche_id)}">${esc(nicheName(t.niche_id))}</span>
        <h2>${esc(t.term)}</h2><p class="muted">first seen ${esc((t.first_seen || '').slice(0, 16).replace('T', ' '))} · ${t.seen_count} sightings · ${esc(t.label || '')}</p></div>
        <button class="btn ghost" data-close>✕</button></div>
      <div class="drawer-stats">
        ${[['Est. volume', compact(t.volume_month) + '/mo'], ['Difficulty', t.difficulty + '/100 ' + (kd.tier || '')],
          ['Opportunity', t.opportunity + '/100'], ['CPC est.', '$' + (t.cpc || 0)], ['Intent', t.intent || '—'],
          ['Velocity', (t.velocity * 100).toFixed(0) + '%']].map(([l, v]) => `<div><i>${l}</i><b>${esc(v)}</b></div>`).join('')}
      </div>
      ${(t.series && t.series.length > 3) ? sparkline(t.series.map(s => s.v), 'Daily pageviews behind this term') : ''}
      <div class="drawer-cols">
        <div><h3>Why this score</h3>
          <table class="mini"><tbody>
            ${Object.entries(kd).filter(([k]) => k !== 'explain' && k !== 'tier').map(([k, v]) => `<tr><td>${esc(k.replace(/_/g, ' '))}</td><td class="num"><b>${v > 0 ? '+' : ''}${v}</b></td></tr>`).join('')}
            <tr class="tot"><td>keyword difficulty</td><td class="num">${t.difficulty}/100</td></tr></tbody></table>
          <p class="tiny muted">${esc(kd.explain || '')}</p>
          <h3>Demand model</h3>
          <table class="mini"><tbody>
            ${Object.entries(sig.volume_parts || {}).map(([k, v]) => `<tr><td>${esc(k.replace(/_/g, ' '))}</td><td class="num">${esc(typeof v === 'object' ? compact(v.daily) + '/d ×' + v.share : v)}</td></tr>`).join('')}
            <tr><td>query-family multiplier</td><td class="num">×${sig.query_family}</td></tr>
            <tr><td>coverage boost</td><td class="num">×${sig.coverage_boost}</td></tr>
            <tr class="tot"><td>estimated monthly volume</td><td class="num">${compact(t.volume_month)}</td></tr></tbody></table>
          <table class="mini"><tbody>${Object.entries(sig.opportunity_parts || {}).map(([k, v]) => `<tr><td>${esc(k.replace(/_/g, ' '))}</td><td class="num">${v}</td></tr>`).join('')}</tbody></table>
          <p class="tiny muted">${esc(sig.volume_formula || '')}</p>
          <h3>Matched because</h3><p class="tiny">${(sig.why_matched || []).map(w => `<span class="tag2">${esc(w)}</span>`).join(' ') || '—'}</p>
          <p class="tiny muted">${(sig.corroborating_sources || []).length} corroborating sources · wiki article hit: ${sig.wiki_exact ? 'yes' : 'no'} · ${n(sig.wiki_total_hits)} indexed pages ·
          ${((sig.authority_share || 0) * 100).toFixed(0)}% authority domains in the coverage set.</p>
        </div>
        <div><h3>Keyword cluster (${(t.keywords || []).length})</h3>
          <table class="mini kws"><thead><tr><th>keyword</th><th class="num">vol</th><th class="num">kd</th></tr></thead><tbody>
          ${(t.keywords || []).map(k => `<tr class="${k.kind}"><td>${esc(k.keyword)}<em>${esc(k.kind)}</em></td><td class="num">${compact(k.volume)}</td><td class="num">${k.difficulty}</td></tr>`).join('')}
          </tbody></table>
          <h3>Evidence</h3><ul class="ev">${(t.evidence || []).map(e => `<li><a href="${esc(e.url)}" target="_blank" rel="noopener">${esc(e.title)}</a><i>${esc(e.source)} · ${esc(e.metric || '')}</i></li>`).join('') || '<li class="muted">no external evidence captured</li>'}</ul>
        </div>
      </div>
      <div class="drawer-foot">
        <button class="btn primary" data-draft="${t.id}">✎ ${t.draft_id ? 'Regenerate draft' : 'Draft article now'}</button>
        ${t.draft_id ? `<button class="btn" data-open-draft="${t.draft_id}">Open draft</button>` : ''}
        <button class="btn" data-topic-status="${t.id}:dismissed">Dismiss topic</button>
        <button class="btn ghost" data-topic-status="${t.id}:watching">Back to watching</button>
      </div>
      ${t.cluster && t.cluster.length ? `<div class="cluster"><h4>Same cluster</h4>${t.cluster.map(c => `<span class="chip2" data-topic="${c.id}">${esc(c.term)} <b>${c.opportunity}</b></span>`).join('')}</div>` : ''}`;
    $('#drawer').classList.add('open');
  } catch (e) { toast('Topic load failed: ' + e.message, 'bad'); }
}

function sparkline(vals, label) {
  const W = 300, H = 62, max = Math.max(...vals, 1), min = Math.min(...vals);
  const pts = vals.map((v, i) => [4 + (i / (vals.length - 1)) * (W - 8), H - 6 - ((v - min) / (max - min || 1)) * (H - 14)]);
  const line = pts.map(p => p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ');
  return `<div class="spark"><h4>${esc(label)}</h4><svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none">
    <polyline points="${line}" fill="none" stroke="url(#sg)" stroke-width="2"/>
    <polygon points="4,${H - 4} ${line} ${W - 4},${H - 4}" fill="url(#sgf)" opacity=".45"/>
    <defs><linearGradient id="sg" x1="0" x2="1"><stop offset="0" stop-color="#6ee7ff"/><stop offset="1" stop-color="#a78bfa"/></linearGradient>
    <linearGradient id="sgf" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6ee7ff" stop-opacity=".5"/><stop offset="1" stop-color="#6ee7ff" stop-opacity="0"/></linearGradient></defs></svg></div>`;
}

/* ---------------------------------------------------------------- drafts */
async function loadDrafts() {
  const q = state.draftFilter ? { status: state.draftFilter } : {};
  const r = await api.get('/api/drafts?' + kw(q));
  state.drafts = r.drafts;
  $('#draft-list').innerHTML = r.drafts.length ? r.drafts.map(d => `
    <div class="dl ${state.selected === d.id ? 'on' : ''}" data-draft-id="${d.id}">
      <div class="score ${d.seo_score >= 80 ? 'hi' : d.seo_score >= 60 ? 'mid' : 'lo'}">${d.seo_score}</div>
      <div class="dl-main"><b>${esc(d.title)}</b>
        <span><i style="background:${(d.niche || {}).color || '#888'}"></i>${esc((d.niche || {}).name || '')} · ${d.word_count}w · ${d.reading_time} min</span>
        <em>${esc(d.status)} · ${d.writer === 'llm' ? esc(d.llm_model || 'llm') : 'offline composer'} · ${ago(d.updated_at)} ago</em></div>
    </div>`).join('') : '<div class="empty small">Nothing in the queue. Draft a topic from the Topics tab, or lower the niche threshold in Automation.</div>';
  if (state.selected) {
    const cur = r.drafts.find(d => d.id === state.selected);
    if (cur) { renderDraft(cur); }
    else { state.selected = null; $('#draft-detail').innerHTML = '<div class="empty">That draft is no longer in the queue.</div>'; }
  } else if (r.drafts.length) { state.selected = r.drafts[0].id; renderDraft(r.drafts[0]); }
}

async function renderDraft(cached) {
  const d = cached && cached.markdown ? cached : await api.get('/api/drafts/' + state.selected);
  if (!d) return;
  const audit = d.audit || [];
  const fails = audit.filter(a => !a.ok).length;
  $('#draft-detail').innerHTML = `
    <div class="dd-head">
      <div><span class="niche sm" style="--c:${(d.niche || {}).color || '#888'}">${esc((d.niche || {}).name || 'draft')}</span>
        <h2>${esc(d.title)}</h2>
        <p class="muted">${esc(d.slug)} · focus <b>${esc(d.focus_keyword)}</b> · ${d.writer === 'llm' ? 'LLM: ' + esc(d.llm_model || '') : 'offline composer'} · written ${ago(d.created_at)} ago</p></div>
      <div class="dd-score"><div class="ring" style="--p:${d.seo_score}"><b>${d.seo_score}</b></div><span>SEO score${fails ? ' · ' + fails + ' to fix' : ' · all clear'}</span></div>
    </div>
    <div class="dd-tabs"><button class="on" data-tab="article">Article</button><button data-tab="meta">Title &amp; meta</button>
      <button data-tab="seo">On-page audit</button><button data-tab="schema">Schema &amp; export</button><button data-tab="brief">Brief</button></div>
    <div class="dd-body" id="dd-body">
      <div class="pane on" data-pane="article"><iframe class="preview" srcdoc="${esc(previewDoc(d.html))}" title="article preview"></iframe></div>
      <div class="pane" data-pane="meta"><label class="fld"><span>SEO title <i id="tl">${(d.title || '').length}/60</i></span>
          <input id="f-title" value="${esc(d.title)}"></label>
        <label class="fld"><span>Slug</span><input id="f-slug" value="${esc(d.slug)}"></label>
        <label class="fld"><span>Meta description <i id="ml">${(d.meta_description || '').length}/160</i></span>
          <textarea id="f-meta" rows="3">${esc(d.meta_description)}</textarea></label>
        <label class="fld"><span>Markdown body (edit and re-audit)</span><textarea id="f-md" rows="18">${esc(d.markdown)}</textarea></label>
        <div class="row-btns"><button class="btn primary" id="save-draft">Save &amp; re-run audit</button>
          <button class="btn" id="regen-draft">↻ Regenerate from data</button></div></div>
      <div class="pane" data-pane="seo"><div class="audit">${audit.map(a => `<div class="${a.ok ? 'pass' : 'warn'}">
          <b>${a.ok ? '✓' : '!'}</b><span>${esc(a.check)}</span><i>${esc(a.detail || '')}</i></div>`).join('')}</div>
        <table class="mini"><tbody>
          <tr><td>word count</td><td class="num">${d.word_count}</td></tr>
          <tr><td>reading time</td><td class="num">${d.reading_time} min</td></tr>
          <tr><td>Flesch readability</td><td class="num">${d.readability}</td></tr>
          <tr><td>keyphrase density</td><td class="num">${d.keyword_density}%</td></tr>
          <tr><td>secondary keywords</td><td class="num">${(d.secondary || []).length}</td></tr></tbody></table></div>
      <div class="pane" data-pane="schema"><pre class="code">${esc(JSON.stringify(d.json_ld, null, 2))}</pre>
        <div class="row-btns"><a class="btn" href="/api/export/${d.id}.md" download>⤓ Markdown</a>
          <a class="btn" href="/api/export/${d.id}.html" download>⤓ HTML page</a>
          <a class="btn" href="/api/export/${d.id}.json" download>⤓ JSON bundle</a>
          <a class="btn" href="/api/preview/${d.id}" target="_blank">⧉ Full preview</a></div></div>
      <div class="pane" data-pane="brief"><table class="mini kws"><thead><tr><th>keyword</th><th class="num">vol</th><th class="num">kd</th><th class="num">cpc</th></tr></thead><tbody>
        ${(d.keywords || []).map(k => `<tr class="${k.kind}"><td>${esc(k.keyword)}<em>${esc(k.kind)}</em></td><td class="num">${compact(k.volume)}</td><td class="num">${k.difficulty}</td><td class="num">$${k.cpc}</td></tr>`).join('')}
        </tbody></table>${d.topic && d.topic.series ? sparkline(JSON.parse(d.topic.series || '[]').map(s => s.v), 'Daily pageviews feeding the trend signal') : ''}</div>
    </div>
    <div class="dd-foot">
      <select id="dd-status" class="sel">${['draft', 'reviewed', 'scheduled', 'archived'].map(s2 => `<option ${d.status === s2 ? 'selected' : ''}>${s2}</option>`).join('')}</select>
      <button class="btn primary" id="publish-draft">Publish to published/</button>
      <button class="btn" id="mark-reviewed">Mark reviewed</button>
      <button class="btn danger" id="del-draft">Delete</button>
      <span class="tiny muted">${d.file_md ? 'files written: ' + esc(d.file_md) : 'not published yet'}</span></div>`;
  bindDraft(d);
}
const previewDoc = (html) => html || '<p>no html</p>';

function bindDraft(d) {
  $$('#draft-detail .dd-tabs button').forEach(b => b.onclick = () => {
    $$('#draft-detail .dd-tabs button').forEach(x => x.classList.remove('on')); b.classList.add('on');
    $$('#dd-body .pane').forEach(p => p.classList.toggle('on', p.dataset.pane === b.dataset.tab));
  });
  const t = $('#f-title'), m = $('#f-meta');
  if (t) t.oninput = () => $('#tl').textContent = t.value.length + '/60';
  if (m) m.oninput = () => $('#ml').textContent = m.value.length + '/160';
  const save = $('#save-draft'); if (save) save.onclick = async () => {
    try {
      await api.patch('/api/drafts/' + d.id, { title: t.value, slug: $('#f-slug').value, meta_description: m.value, markdown: $('#f-md').value });
      toast('Saved · audit re-run', 'good'); await loadDrafts();
    } catch (e) { toast('Save failed: ' + e.message, 'bad'); }
  };
  const rg = $('#regen-draft'); if (rg) rg.onclick = async () => {
    try { toast('Regenerating…'); const r = await api.post(`/api/drafts/${d.id}/regenerate`); state.selected = r.draft.id; await loadDrafts(); toast('Draft rebuilt from live data', 'good'); }
    catch (e) { toast('Regenerate failed: ' + e.message, 'bad'); }
  };
  const pb = $('#publish-draft'); if (pb) pb.onclick = async () => {
    try { await api.post(`/api/drafts/${d.id}/publish`); toast('Published to published/ + /api/feed.xml', 'good'); await refresh(); }
    catch (e) { toast('Publish failed: ' + e.message, 'bad'); }
  };
  const rv = $('#mark-reviewed'); if (rv) rv.onclick = async () => { await api.patch('/api/drafts/' + d.id, { status: 'reviewed' }); toast('Marked reviewed', 'good'); await loadDrafts(); };
  const dl = $('#del-draft'); if (dl) dl.onclick = async () => { await api.del('/api/drafts/' + d.id); state.selected = null; toast('Deleted'); await refresh(); $('#draft-detail').innerHTML = '<div class="empty">Select a draft.</div>'; };
}

/* ---------------------------------------------------------------- intel */
async function runIntel() {
  const term = $('#intel-input').value.trim(); if (!term) return;
  $('#intel-out').innerHTML = '<div class="loading">probing autocomplete, news, Wikipedia and pageviews…</div>';
  try {
    const q = { keyword: term }; const nid = $('#intel-niche').value; if (nid) q.niche = nid;
    const r = await api.get('/api/search?' + kw(q));
    state.intel = r;
    const kd = r.kd_parts || {}, vol = r.volume_components || {};
    $('#intel-out').innerHTML = `
      <div class="intel-grid">
        <div class="intel-metrics">
          <div><i>est. monthly volume</i><b>${compact(r.volume_month)}</b><small>${n(r.volume_daily)} searches/day · CPC est $${r.cpc}</small></div>
          <div><i>keyword difficulty</i><b>${r.difficulty}<small>/${r.kd_tier}</small></b><small>${esc(r.explain || '')}</small></div>
          <div><i>opportunity</i><b>${r.opportunity}<small>/100</small></b><small>${esc(r.label || '')} · ${esc(r.intent || '')}</small></div>
          <div><i>velocity</i><b>${((r.velocity || 0) * 100).toFixed(0)}%</b><small>${esc(r.velocity_label || '')} · ${r.coverage_count} fresh competing items</small></div>
        </div>
        <div class="intel-parts"><h4>difficulty components</h4>${Object.entries(kd).map(([k, v]) => `
            <div class="part"><span>${esc(k.replace(/_/g, ' '))}</span><i style="width:${Math.min(100, Math.abs(v) * 3.2)}%"></i><b>${v > 0 ? '+' : ''}${v}</b></div>`).join('')}</div>
        <div class="intel-parts"><h4>volume blend</h4>${Object.keys(vol).length ? Object.entries(vol).map(([k, v]) => `
            <div class="part"><span>${esc(k.replace(/_/g, ' '))}</span><i style="width:${(v.share || 0) * 100}%"></i><b>${compact(v.daily)}/day ×${v.share != null ? v.share : 1}</b></div>`).join('')
          : '<p class="tiny muted">No direct volume source matched this term; estimate is derived from autocomplete breadth and coverage count.</p>'}</div>
      </div>
      <h4 class="mt">Query space (${(r.longtails || []).length} live autocomplete variants)</h4>
      <div class="lt">${(r.longtails || []).map(l => `<span class="ltchip ${l.kind}">${esc(l.kw)}<b>${l.kind === 'question' ? '?' : l.position}</b></span>`).join('') || '<span class="muted tiny">autocomplete returned nothing for this term</span>'}</div>
      ${(r.series || []).length > 3 ? sparkline(r.series.map(s => s.v), 'Wikipedia pageviews behind this term (daily)') : ''}
      <div class="row-btns"><button class="btn primary" id="intel-track">${r.topic_id ? 'Draft this tracked topic' : 'Track this keyword &amp; draft'}</button>
      ${r.topic_id ? `<button class="btn" data-topic="${r.topic_id}">Open topic</button>` : ''}</div>`;
    $('#intel-track').onclick = async () => {
      toast('Drafting…');
      try {
        const out = await api.post('/api/search/draft', { keyword: term, niche_id: nid || null });
        state.selected = out.draft.id; go('drafts'); await refresh(); toast('Draft created: ' + out.draft.title, 'good');
      } catch (e) { toast('Failed: ' + e.message, 'bad'); }
    };
  } catch (e) { $('#intel-out').innerHTML = `<div class="err">Lookup failed: ${esc(e.message)}<br><span class="tiny">Live sources are unreachable from this environment? Toggle Simulated mode in Automation.</span></div>`; }
}

/* ---------------------------------------------------------------- settings */
function fld(cfg) {
  const { key, label, type, hint, opts, min, max, step } = cfg;
  const v = cfg.value;
  let input;
  if (type === 'select') input = `<select data-key="${key}">${opts.map(o => `<option value="${o[0]}" ${String(o[0]) === String(v) ? 'selected' : ''}>${esc(o[1])}</option>`).join('')}</select>`;
  else if (type === 'toggle') input = `<label class="switch"><input type="checkbox" data-key="${key}" ${v ? 'checked' : ''}><span></span></label>`;
  else if (type === 'list') input = `<textarea data-key="${key}" rows="2" placeholder="one per line">${esc((v || []).join('\n'))}</textarea>`;
  else if (type === 'checks') input = `<div class="checks">${opts.map(o => `<label><input type="checkbox" data-multi="${key}" value="${o[0]}" ${(v || []).includes(o[0]) ? 'checked' : ''}> ${esc(o[1])}</label>`).join('')}</div>`;
  else input = `<input data-key="${key}" type="${type || 'text'}" value="${esc(v == null ? '' : v)}" ${min != null ? `min="${min}"` : ''} ${max != null ? `max="${max}"` : ''} ${step ? `step="${step}"` : ''}>`;
  return `<label class="fld ${type === 'toggle' ? 'inline' : ''}"><span>${esc(label)}${hint ? `<em>${esc(hint)}</em>` : ''}</span>${input}</label>`;
}
function collect(root) {
  const out = {};
  $$('[data-key]', root).forEach(el => {
    out[el.dataset.key] = el.type === 'checkbox' ? el.checked : (el.type === 'number' ? Number(el.value) : el.value);
  });
  const multi = {};
  $$('[data-multi]', root).forEach(el => { (multi[el.dataset.multi] = multi[el.dataset.multi] || []).push(el.value); });
  Object.entries(multi).forEach(([k, v]) => out[k] = v);
  $$('[data-key]', root).forEach(el => { if (el.tagName === 'TEXTAREA' && /\n|,/.test(el.value) && el.rows > 1) out[el.dataset.key] = el.value.split(/[\n,]/).map(s => s.trim()).filter(Boolean); });
  return out;
}
function renderMonitorForm() {
  const s = state.settings || {};
  $('#monitor-form').innerHTML = [
    fld({ key: 'enabled', label: 'Auto-scan enabled', type: 'toggle', value: s.enabled }),
    fld({ key: 'live_sources', label: 'Live public sources', hint: 'off = simulated dataset', type: 'toggle', value: s.live_sources }),
    fld({ key: 'cadence_min', label: 'Cadence (minutes)', type: 'number', min: 5, max: 1440, value: s.cadence_min }),
    fld({ key: 'max_topics_per_scan', label: 'Topics per niche / scan', type: 'number', min: 2, max: 20, value: s.max_topics_per_scan }),
    fld({ key: 'news_window_hours', label: 'Freshness window (h)', type: 'number', min: 6, max: 720, value: s.news_window_hours }),
    fld({ key: 'stale_days', label: 'Retire topic after (days)', type: 'number', min: 2, max: 60, value: s.stale_days }),
    fld({ key: 'regions', label: 'Geo regions', hint: 'comma or newline separated', type: 'list', value: s.regions }),
    fld({ key: 'sources', label: 'Sources', type: 'checks', value: s.sources, opts: [['google_trends', 'Google Trends'], ['google_news', 'Google News'], ['hackernews', 'Hacker News'], ['wikipedia_top', 'Wikipedia top views'], ['github', 'GitHub'], ['reddit', 'Reddit']] }),
  ].join('');
}
function renderWriterForm() {
  const s = state.settings || {}, l = s.llm || {};
  $('#writer-form').innerHTML = [
    fld({ key: 'llm.enabled', label: 'Use LLM writer', hint: 'offline composer is the fallback', type: 'toggle', value: l.enabled }),
    fld({ key: 'llm.api_base', label: 'API base URL', value: l.api_base }),
    fld({ key: 'llm.model', label: 'Model', value: l.model }),
    fld({ key: 'llm.api_key', label: 'API key', hint: l.api_key_set ? 'stored: ' + l.api_key_hint : 'not set', value: '', type: 'password' }),
    fld({ key: 'llm.temperature', label: 'Temperature', type: 'number', min: 0, max: 1.5, step: '0.05', value: l.temperature }),
    fld({ key: 'llm.max_tokens', label: 'Max tokens', type: 'number', min: 300, max: 8000, value: l.max_tokens }),
    fld({ key: 'site.name', label: 'Site name', value: (s.site || {}).name }),
    fld({ key: 'site.domain', label: 'Canonical domain', value: (s.site || {}).domain }),
  ].join('');
  $('#writer-note').textContent = l.enabled && l.api_key_set
    ? `Drafts will be written by ${l.model} using the data brief, then audited by the on-page checker.`
    : 'Offline composer active: every section, table and FAQ below is generated from measured signal data — no invented stats.';
}
function renderNicheEditor() {
  const note = $('#db-note');
  if (note) note.textContent = `SQLite at data/app.db · ${(state.stats || {}).topics || 0} topics · ${(state.stats || {}).drafts || 0} drafts · published/ holds ${document.querySelectorAll('.pill.published').length} live file sets`;
  $('#niche-editor').innerHTML = (state.niches || []).map(x => `
    <div class="nedit" style="--c:${x.color}" data-niche-id="${x.id}">
      <div class="nedit-top"><input class="n-name" value="${esc(x.name)}"><input class="n-color" type="color" value="${esc(x.color)}">
        <label class="switch"><input type="checkbox" class="n-enabled" ${x.enabled ? 'checked' : ''}><span></span></label>
        <button class="btn tiny" data-niche-save="${x.id}">Save</button><button class="btn tiny ghost" data-niche-del="${x.id}">Delete</button></div>
      <div class="nedit-grid">
        <label><span>Seed keywords <em>head terms the niche owns</em></span><textarea class="n-seeds" rows="2">${esc((x.seed_keywords || []).join('\n'))}</textarea></label>
        <label><span>Include terms <em>relevance vocabulary</em></span><textarea class="n-inc" rows="2">${esc((x.include_terms || []).join(' '))}</textarea></label>
        <label><span>Exclude terms</span><textarea class="n-exc" rows="1">${esc((x.exclude_terms || []).join(' '))}</textarea></label>
        <label><span>Sources <em>empty = all enabled</em></span><input class="n-src" value="${esc((x.sources || []).join(', '))}"></label>
      </div>
      <div class="nedit-slider">
        ${[['min_opportunity', 'Draft at opportunity ≥', 30, 95], ['max_difficulty', 'Only if difficulty ≤', 20, 95],
          ['min_volume', 'Min monthly volume', 50, 20000], ['word_target', 'Target word count', 400, 2500]].map(([k, l, mi, ma]) =>
            `<label><span>${l}</span><input type="number" class="n-${k}" min="${mi}" max="${ma}" value="${x[k] != null ? x[k] : ''}"></label>`).join('')}
        <label><span>Auto-draft</span><label class="switch"><input type="checkbox" class="n-auto" ${x.auto_draft ? 'checked' : ''}><span></span></label></label>
      </div></div>`).join('');
}

/* ---------------------------------------------------------------- nav + events */
function go(view) {
  state.view = view;
  $$('#nav button').forEach(b => b.classList.toggle('active', b.dataset.view === view));
  $$('.view').forEach(v => v.classList.toggle('hidden', v.id !== 'view-' + view));
  const titles = { overview: ['Overview', 'Watching every niche for search demand a small team can actually rank for.'],
    topics: ['Trending topics', 'Ranked by opportunity: demand × rankability × velocity × query depth.'],
    intel: ['Keyword intel', 'On-demand volume and difficulty for any phrase, with the live query space around it.'],
    drafts: ['Draft queue', 'SEO-formatted articles with meta, schema, internal links and an on-page audit.'],
    settings: ['Automation', 'Cadence, sources, thresholds and the writer engine.'] }[view];
  $('#view-title').textContent = titles[0]; $('#view-sub').textContent = titles[1];
  if (view === 'drafts' && state.selected) renderDraft();
}
async function scanNow(nicheId) {
  state.scanning = true; renderScheduler({ scheduler: state.scheduler, last_scan: state.last_scan, stats: state.stats, recent_drafts: [] });
  $('#scan-note').textContent = nicheId ? 'scanning one niche…' : 'scanning all sources…';
  try { await api.post('/api/scan', nicheId ? { niche_ids: [nicheId] } : {}); }
  catch (e) { toast(e.message, 'bad'); state.scanning = false; return; }
  for (let i = 0; i < 40; i++) {
    await new Promise(r => setTimeout(r, 2500));
    try {
      const s = await api.get('/api/scans?limit=1');
      const latest = s.scans[0];
      if (latest && latest.status !== 'running' && !s.running) break;
    } catch (e) { }
  }
  state.scanning = false; await refresh();
  const last = state.last_scan || {};
  toast(`Scan ${last.status}: ${last.topics_new || 0} new topics, ${last.drafts_created || 0} drafts`, last.error ? 'bad' : 'good');
}
function bind() {
  $('#nav').onclick = (e) => { const b = e.target.closest('button[data-view]'); if (b) go(b.dataset.view); };
  $('#btn-refresh').onclick = () => { refresh(); toast('Refreshed'); };
  $('#btn-scan').onclick = () => scanNow();
  $('#btn-sched').onclick = async () => {
    const next = state.settings.enabled ? 'pause' : 'resume';
    await api.post('/api/scheduler', { action: next });
    toast(next === 'pause' ? 'Auto-scan paused - the dashboard still works' : 'Auto-scan resumed', 'good');
    await refresh();
  };
  $('#global-search').oninput = (e) => { state.q = e.target.value.trim(); clearTimeout(state.qt); state.qt = setTimeout(loadTopics, 260); };
  $('#sort-by').onchange = (e) => { state.sort = e.target.value; loadTopics(); };
  document.addEventListener('click', async (e) => {
    const cl = (s) => e.target.closest(s);
    if (cl('[data-close]')) $('#drawer').classList.remove('open');
    if (cl('[data-jump]')) go(cl('[data-jump]').dataset.jump);
    if (cl('[data-niche]') && cl('.chip')) { state.niche = cl('[data-niche]').dataset.niche; loadTopics(); }
    if (cl('[data-status]') && cl('.chip')) { state.status = cl('[data-status]').dataset.status; loadTopics(); }
    if (cl('#draft-filter button')) { $$('#draft-filter button').forEach(b => b.classList.remove('on')); cl('#draft-filter button').classList.add('on'); state.draftFilter = cl('#draft-filter button').dataset.status; loadDrafts(); }
    if (cl('[data-scan-niche]')) { e.stopPropagation(); scanNow(Number(cl('[data-scan-niche]').dataset.scanNiche)); }
    if (cl('[data-draft]')) { e.stopPropagation(); const id = Number(cl('[data-draft]').dataset.draft); toast('Drafting…');
      try { const out = await api.post('/api/drafts', { topic_id: id }); state.selected = out.draft.id; go('drafts'); await loadDrafts(); toast('Draft ready · SEO ' + out.draft.seo_score + '/100', 'good'); }
      catch (err) { toast(err.message, 'bad'); } }
    if (cl('[data-hide]')) { e.stopPropagation(); await api.post(`/api/topics/${cl('[data-hide]').dataset.hide}/status`, { status: 'dismissed' }); loadTopics(); }
    if (cl('[data-topic-status]')) { const [id, st] = cl('[data-topic-status]').dataset.topicStatus.split(':'); await api.post(`/api/topics/${id}/status`, { status: st }); $('#drawer').classList.remove('open'); refresh(); }
    if (cl('[data-open-draft]')) { state.selected = Number(cl('[data-open-draft]').dataset.openDraft); go('drafts'); await loadDrafts(); }
    if (cl('[data-draft-id]')) { state.selected = Number(cl('[data-draft-id]').dataset.draftId); renderDraft(); $$('.dl').forEach(x => x.classList.toggle('on', Number(x.dataset.draftId) === state.selected)); }
    const row = cl('#topics-table tbody tr');
    if (row && !e.target.closest('button,a,select,input,textarea')) openTopic(Number(row.dataset.topic));
    const circ = cl('#scatter circle[data-topic]'); if (circ) { go('topics'); setTimeout(() => openTopic(Number(circ.dataset.topic)), 200); }
    const c2 = cl('.chip2[data-topic]'); if (c2) openTopic(Number(c2.dataset.topic));
    if (cl('#test-sources')) { $('#source-test-out').classList.remove('hidden'); $('#source-test-out').textContent = 'testing…';
      try { const r = await api.post('/api/sources/test'); $('#source-test-out').innerHTML = r.sources.map(s => `<div class="${s.ok ? 'pass' : 'warn'}"><b>${esc(s.source)}</b> ${s.ok ? s.count + ' items in ' + s.ms + 'ms' : esc(s.error)}</div>`).join('') + `<div class="pass"><b>google autocomplete</b> sample: ${esc((r.autocomplete_sample || []).slice(0, 3).join(' · '))}</div>`; }
      catch (e2) { $('#source-test-out').textContent = 'test failed: ' + e2.message; } }
    if (cl('#save-monitor')) { const p = collect($('#monitor-form')); await api.post('/api/settings', p); toast('Schedule saved', 'good'); await refresh(); }
    if (cl('#save-writer')) { const raw = collect($('#writer-form')); const p = { llm: {}, site: {} };
      Object.entries(raw).forEach(([k, v]) => { if (k.startsWith('llm.')) p.llm[k.slice(4)] = v; else if (k.startsWith('site.')) p.site[k.slice(5)] = v; });
      if (!p.llm.api_key) delete p.llm.api_key; await api.post('/api/settings', p); toast('Writer config saved', 'good'); await refresh(); }
    if (cl('[data-niche-save]')) { const id = cl('[data-niche-save]').dataset.nicheSave, box = $(`.nedit[data-niche-id="${id}"]`);
      const body = { name: $('.n-name', box).value, color: $('.n-color', box).value, enabled: $('.n-enabled', box).checked,
        seed_keywords: $('.n-seeds', box).value.split(/[\n,]/).map(s => s.trim()).filter(Boolean),
        include_terms: $('.n-inc', box).value.split(/[\s,]+/).map(s => s.trim()).filter(Boolean),
        exclude_terms: $('.n-exc', box).value.split(/[\s,]+/).map(s => s.trim()).filter(Boolean),
        sources: $('.n-src', box).value.split(/[\s,]+/).map(s => s.trim()).filter(Boolean),
        min_opportunity: Number($('.n-min_opportunity', box).value), max_difficulty: Number($('.n-max_difficulty', box).value),
        min_volume: Number($('.n-min_volume', box).value), word_target: Number($('.n-word_target', box).value),
        auto_draft: $('.n-auto', box).checked };
      try { await api.send('/api/niches/' + id, 'PUT', body); toast('Niche saved · rescanning', 'good'); await refresh(); } catch (e2) { toast(e2.message, 'bad'); } }
    if (cl('[data-niche-del]')) { if (!confirm('Delete this niche, its topics and drafts?')) return; await api.del('/api/niches/' + cl('[data-niche-del]').dataset.nicheDel); await refresh(); toast('Niche removed'); }
    if (cl('#btn-add-niche')) {
      const name = prompt('Niche name (e.g. Home & Garden)'); if (!name) return;
      const seeds = prompt('Seed keywords, comma separated (e.g. compost, raised beds)') || name.toLowerCase();
      const made = await api.post('/api/niches', { name, seed_keywords: seeds.split(',').map(s => s.trim()).filter(Boolean) });
      toast('Niche added - scanning it once', 'good'); await refresh(); if (made && made.niche) scanNow(made.niche.id); }
    if (cl('#btn-reset')) { if (!confirm('Delete all topics, drafts, scans and logs? Niches and settings stay.')) return; await api.post('/api/reset'); toast('Cleared'); await refresh(); }
    if (cl('#btn-export-all')) { const r = await api.get('/api/drafts?limit=300'); const blob = new Blob([JSON.stringify(r.drafts, null, 1)], { type: 'application/json' });
      const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'trendwriter-drafts.json'; a.click(); toast('Exported ' + r.drafts.length + ' drafts'); }
    if (cl('[data-topic]') && cl('#intel-out')) openTopic(Number(cl('[data-topic]').dataset.topic));
  });
  $('#intel-form').onsubmit = (e) => { e.preventDefault(); runIntel(); };
  $('#intel-draft').onclick = runIntel;
}

boot();
