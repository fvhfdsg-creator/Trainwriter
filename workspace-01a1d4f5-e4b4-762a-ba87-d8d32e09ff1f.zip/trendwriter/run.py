#!/usr/bin/env python3
"""TrendWriter entry point.

  python run.py                 # dashboard + scheduler on :8000
  python run.py --once          # single scan, no server (cron-friendly)
  python run.py --port 9000 --no-scheduler
"""
from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from trendwriter import api, db, pipeline  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description="Trend-driven SEO monitor and auto-drafter")
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=int(os.environ.get("PORT") or 8000))
    ap.add_argument("--once", action="store_true", help="run one scan, print a summary, exit")
    ap.add_argument("--no-scheduler", action="store_true", help="serve the dashboard without the background loop")
    ap.add_argument("--live/--simulated", dest="live", default=None, help="force source mode for this run")
    ap.add_argument("--niche", help="with --once: scan a single niche by slug")
    args = ap.parse_args()

    pipeline.ensure_defaults()
    if args.live is not None:
        pipeline.set_settings({"live_sources": bool(args.live)})

    if args.once:
        niche_ids = None
        if args.niche:
            row = db.one("SELECT id FROM niches WHERE slug=?", (args.niche,))
            niche_ids = [row["id"]] if row else None
        result = pipeline.run_scan(trigger="cli", niche_filter=niche_ids)
        print(f"scan #{result['id']}: {result['status']} in {result['duration_s']}s - "
              f"{result['topics_found']} candidates, {result['topics_new']} new topics, {result['drafts_created']} drafts")
        for h in db.rows("SELECT source_health FROM scans WHERE id=?", (result["id"],)):
            import json

            for s in json.loads(h["source_health"] or "[]"):
                print(f"  {s['source']:<28} {'ok ' if s['ok'] else 'ERR'} {s.get('count', 0):>3} items  {s.get('ms', 0)}ms"
                      + (f"  {s['error']}" if s.get("error") else ""))
        for t in db.rows("SELECT term, volume_month, difficulty, opportunity, score_label FROM topics "
                         "ORDER BY opportunity DESC LIMIT 10"):
            print(f"  [{t['opportunity']:>3}] {t['term'][:46]:<46} vol {t['volume_month']:>7} kd {t['difficulty']:>3}  {t['score_label']}")
        return 0 if result["status"] == "ok" else 1

    api.serve(args.host, args.port, start_scheduler=not args.no_scheduler)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
